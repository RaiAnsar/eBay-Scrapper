#!/usr/bin/env python3
"""
Find the right selector for eBay items
"""

import asyncio
from playwright.async_api import async_playwright

async def find_items():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
        print(f"Loading: {url}")
        await page.goto(url, wait_until='domcontentloaded')
        await page.wait_for_timeout(3000)
        
        # Find products using different methods
        result = await page.evaluate('''() => {
            const results = {};
            
            // Method 1: .s-item
            const sItems = document.querySelectorAll('.s-item');
            results.sItems = sItems.length;
            
            // Method 2: li with data-viewport
            const liViewport = document.querySelectorAll('li[data-viewport]');
            results.liViewport = liViewport.length;
            
            // Method 3: Links with /itm/
            const itmLinks = document.querySelectorAll('a[href*="/itm/"]');
            results.itmLinks = itmLinks.length;
            
            // Get first few items to analyze structure
            const samples = [];
            
            // Try li[data-viewport] first since we found 62 of them
            liViewport.forEach((item, idx) => {
                if (idx < 3) {
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (link) {
                        const title = item.querySelector('h3, .s-item__title, [role="heading"]');
                        const price = item.querySelector('.s-item__price, [class*="price"]');
                        samples.push({
                            index: idx,
                            hasLink: true,
                            linkHref: link.href,
                            title: title ? title.innerText.substring(0, 50) : 'no title',
                            price: price ? price.innerText : 'no price',
                            tagName: item.tagName,
                            className: item.className
                        });
                    }
                }
            });
            
            // Also check .s-item elements
            sItems.forEach((item, idx) => {
                if (idx < 2) {
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (link) {
                        const title = item.querySelector('h3, .s-item__title');
                        samples.push({
                            index: idx,
                            selector: '.s-item',
                            hasLink: true,
                            title: title ? title.innerText.substring(0, 50) : 'no title'
                        });
                    }
                }
            });
            
            return {counts: results, samples: samples};
        }''')
        
        print("\n📊 Element counts:")
        for key, value in result['counts'].items():
            print(f"  {key}: {value}")
        
        print("\n📦 Sample items found:")
        for sample in result['samples']:
            print(f"\n  Item {sample.get('index', '?')}:")
            for k, v in sample.items():
                if k != 'index':
                    print(f"    {k}: {v}")
        
        # Now let's try to scrape with the right selector
        products = await page.evaluate('''() => {
            const items = [];
            
            // Use li[data-viewport] since we found 62 of them
            const productElements = document.querySelectorAll('li[data-viewport]');
            
            productElements.forEach((item) => {
                try {
                    // Get the link
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    // Get title - multiple possible selectors
                    let title = '';
                    const titleSelectors = ['h3', '.s-item__title', '[role="heading"]', '.s-item__link span'];
                    for (let selector of titleSelectors) {
                        const elem = item.querySelector(selector);
                        if (elem && elem.innerText) {
                            title = elem.innerText.trim();
                            break;
                        }
                    }
                    
                    if (!title) return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price, [class*="price"]');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        itemNumber: itemMatch[1],
                        url: href
                    });
                } catch (e) {}
            });
            
            return items;
        }''')
        
        print(f"\n✅ Successfully extracted {len(products)} products")
        if products:
            print("\n📋 First 5 products:")
            for i, p in enumerate(products[:5], 1):
                print(f"  {i}. {p['title'][:60]}...")
                print(f"     Price: {p['price']}")
                print(f"     Item#: {p['itemNumber']}")
        
        await browser.close()

asyncio.run(find_items())