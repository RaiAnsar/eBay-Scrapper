#!/usr/bin/env python3
"""
TEST Enhanced eBay Scraper - Quick test with 200 items per page
"""

import asyncio
from enhanced_scraper import EnhancedEbayScraper

async def main():
    scraper = EnhancedEbayScraper()
    
    # Your search URL
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    print("\n🧪 TESTING ENHANCED SCRAPER WITH 200 ITEMS/PAGE")
    print("=" * 70)
    
    # Test with just 2 pages to see if it works
    products = await scraper.scrape_ebay_enhanced(
        search_url,
        max_pages=2,  # Just 2 pages = 400 products
        extract_ean=True,
        extract_description=True,
        items_per_page=200  # 200 items per page!
    )
    
    print(f"\n✅ Test complete: {len(products)} products scraped")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n⚠️ Test interrupted")
    except Exception as e:
        print(f"\n❌ Test error: {e}")