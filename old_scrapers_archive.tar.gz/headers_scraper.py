#!/usr/bin/env python3
"""
eBay Scraper with Proper Headers to Avoid Detection
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import random

async def scrape_ebay(search_url: str, max_pages: int = 2):
    """Scrape eBay with proper headers"""
    
    async with async_playwright() as p:
        # Launch with anti-detection
        browser = await p.chromium.launch(
            headless=False,
            args=['--disable-blink-features=AutomationControlled']
        )
        
        # Proper headers
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            extra_http_headers={
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-GB,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
        )
        
        # Anti-detection script
        await context.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        page = await context.new_page()
        
        # Go to eBay first
        await page.goto('https://www.ebay.co.uk', wait_until='networkidle')
        await page.wait_for_timeout(2000)
        
        all_products = []
        
        for page_num in range(1, max_pages + 1):
            print(f"\nPage {page_num}/{max_pages}")
            
            url = f"{search_url}&_pgn={page_num}" if page_num > 1 else search_url
            
            await page.goto(url, wait_until='networkidle')
            await page.wait_for_timeout(random.randint(2000, 4000))
            
            # Extract products
            products = await page.evaluate('''() => {
                const items = [];
                const elements = document.querySelectorAll('li[data-viewport]');
                
                elements.forEach(item => {
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const title = item.querySelector('h3, [role="heading"]');
                    if (!title || title.innerText === 'Shop on eBay') return;
                    
                    const href = link.href;
                    const match = href.match(/\\/itm\\/(\\d+)/);
                    if (!match) return;
                    
                    const price = item.querySelector('.s-item__price');
                    
                    items.push({
                        title: title.innerText.trim(),
                        price: price ? price.innerText.trim() : '',
                        item_number: match[1]
                    });
                });
                
                return items;
            }''')
            
            print(f"Found {len(products)} products")
            
            for p in products:
                all_products.append({
                    'Title': p['title'],
                    'Price': p['price'],
                    'Ebay_Item_Number': p['item_number'],
                    'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}"
                })
        
        await browser.close()
        
        return all_products

# Run test
if __name__ == "__main__":
    products = asyncio.run(scrape_ebay(
        "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray",
        max_pages=2
    ))
    
    if products:
        df = pd.DataFrame(products)
        filename = f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        df.to_excel(filename, index=False)
        print(f"\n✅ Saved {len(products)} products to {filename}")