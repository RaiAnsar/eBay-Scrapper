#!/usr/bin/env python3
"""
Quick test to verify scraping works
"""

import asyncio
from playwright.async_api import async_playwright
from datetime import datetime

async def quick_test():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0'
        )
        page = await context.new_page()
        
        url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
        print(f"Loading: {url}")
        
        await page.goto(url, wait_until='domcontentloaded', timeout=15000)
        await page.wait_for_timeout(3000)
        
        # Extract products
        products = await page.evaluate('''() => {
            const items = [];
            
            // Use li[data-viewport] for eBay UK
            const productElements = document.querySelectorAll('li[data-viewport]');
            console.log('Found elements:', productElements.length);
            
            productElements.forEach((item) => {
                try {
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    // Get title
                    let title = '';
                    const titleElem = item.querySelector('h3, [role="heading"], .s-item__title');
                    if (titleElem) {
                        title = titleElem.innerText.trim();
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price, [class*="price"]');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemMatch[1]
                    });
                } catch (e) {
                    console.error('Error:', e);
                }
            });
            
            return items;
        }''')
        
        print(f"✅ Found {len(products)} products")
        
        if products:
            print("\nFirst 3 products:")
            for i, p in enumerate(products[:3], 1):
                print(f"{i}. {p['title'][:60]}...")
                print(f"   Price: {p['price']}")
                print(f"   Item#: {p['item_number']}")
            
            # Now test EAN extraction for first product
            if products:
                item_num = products[0]['item_number']
                print(f"\n📊 Testing EAN extraction for item {item_num}...")
                
                detail_page = await context.new_page()
                product_url = f"https://www.ebay.co.uk/itm/{item_num}"
                
                await detail_page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
                await detail_page.wait_for_timeout(2000)
                
                # Extract EAN
                ean_data = await detail_page.evaluate('''() => {
                    let ean = '';
                    
                    // Look for EAN in various places
                    const allText = document.body.innerText || '';
                    const eanMatch = allText.match(/EAN[:\\s]*(\\d{8,13})/i);
                    if (eanMatch) {
                        ean = eanMatch[1];
                    }
                    
                    // Also check item specifics
                    const rows = document.querySelectorAll('.ux-layout-section__row, tr');
                    for (let row of rows) {
                        const text = row.innerText || '';
                        if (text.includes('EAN') && text.match(/\\d{8,13}/)) {
                            const match = text.match(/\\d{8,13}/);
                            if (match) {
                                ean = match[0];
                                break;
                            }
                        }
                    }
                    
                    return ean;
                }''')
                
                print(f"   EAN found: {ean_data if ean_data else 'Not found'}")
                
                await detail_page.close()
        
        await browser.close()

asyncio.run(quick_test())