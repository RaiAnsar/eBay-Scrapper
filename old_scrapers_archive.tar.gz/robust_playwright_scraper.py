#!/usr/bin/env python3
"""
Robust Playwright eBay Scraper - Handles timeouts and modern eBay pages
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import re

class RobustPlaywrightScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        self.context = None
    
    async def scrape_url(self, search_url, max_pages=1, extract_details=False, progress_callback=None):
        """Main scraping function with optional detail extraction"""
        self.start_time = datetime.now()
        
        print("\n" + "="*70)
        print("🛒 Robust eBay Scraper with Playwright")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        
        async with async_playwright() as p:
            # Launch browser with better settings
            print("🌐 Launching browser...")
            browser = await p.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
            
            # Create context with user agent
            context = await browser.new_context(
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            self.context = context
            
            page = await context.new_page()
            
            # Set extra headers
            await page.set_extra_http_headers({
                'Accept-Language': 'en-GB,en;q=0.9'
            })
            
            for page_num in range(1, max_pages + 1):
                print(f"\n📄 Processing Page {page_num}/{max_pages}")
                print("-" * 40)
                
                # Update progress at start of page
                if progress_callback:
                    await progress_callback(page_num, self.products_scraped)
                
                # Construct URL for page
                if page_num == 1:
                    url = search_url
                else:
                    if '?' in search_url:
                        url = f"{search_url}&_pgn={page_num}"
                    else:
                        url = f"{search_url}?_pgn={page_num}"
                
                try:
                    # Navigate with shorter timeout and domcontentloaded
                    print(f"   Loading: {url[:80]}...")
                    await page.goto(url, wait_until='domcontentloaded', timeout=15000)
                    
                    # Wait a bit for dynamic content
                    await page.wait_for_timeout(2000)
                    
                    # Try to wait for products to load
                    try:
                        await page.wait_for_selector('[data-gr4]', timeout=5000)
                    except:
                        # If data-gr4 doesn't exist, try other selectors
                        try:
                            await page.wait_for_selector('.srp-results', timeout=3000)
                        except:
                            pass
                    
                    # Extract products using JavaScript
                    products = await self.extract_products(page)
                    
                    # Filter out duplicates and optionally extract details
                    new_products = []
                    for product in products:
                        item_num = product.get('Ebay_Item_Number', '')
                        if item_num and item_num not in self.seen_items:
                            self.seen_items.add(item_num)
                            
                            # Extract EAN and description if requested
                            if extract_details and item_num:
                                print(f"   📊 Fetching EAN for item {item_num}...")
                                product['EAN'] = await self.extract_ean_from_product_page(item_num)
                                print(f"   📝 Fetching description for item {item_num}...")
                                product['Description'] = await self.extract_product_description(item_num)
                            
                            new_products.append(product)
                            self.products_scraped += 1
                    
                    all_products.extend(new_products)
                    
                    print(f"✅ Found: {len(products)} items ({len(new_products)} new)")
                    
                    # Update progress callback if provided
                    if progress_callback:
                        await progress_callback(page_num, len(all_products))
                    
                    # Show some product titles
                    for i, p in enumerate(new_products[:3], 1):
                        print(f"   {i}. {p['Title'][:60]}...")
                    
                except Exception as e:
                    print(f"❌ Error on page {page_num}: {e}")
                
                # Rate limiting between pages
                if page_num < max_pages:
                    await page.wait_for_timeout(1500)
            
            await browser.close()
        
        # Final report
        self.show_final_report(all_products)
        
        return all_products
    
    async def extract_ean_from_product_page(self, item_number: str) -> str:
        """Extract EAN from individual product page"""
        try:
            page = await self.context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1000)
            
            # Extract EAN using multiple methods
            ean = await page.evaluate('''() => {
                // Method 1: Look in item specifics
                const specifics = document.querySelectorAll('.ux-layout-section__item');
                for (let spec of specifics) {
                    const text = spec.innerText;
                    if (text.includes('EAN') || text.includes('UPC') || text.includes('ISBN')) {
                        const match = text.match(/\\d{8,13}/);
                        if (match) return match[0];
                    }
                }
                
                // Method 2: Look in description
                const description = document.querySelector('.vim-description-content');
                if (description) {
                    const eanMatch = description.innerText.match(/EAN[:\\s]*(\\d{8,13})/i);
                    if (eanMatch) return eanMatch[1];
                    
                    const upcMatch = description.innerText.match(/UPC[:\\s]*(\\d{8,13})/i);
                    if (upcMatch) return upcMatch[1];
                }
                
                // Method 3: Check structured data
                const scripts = document.querySelectorAll('script[type="application/ld+json"]');
                for (let script of scripts) {
                    try {
                        const data = JSON.parse(script.innerText);
                        if (data.gtin13) return data.gtin13;
                        if (data.gtin) return data.gtin;
                    } catch {}
                }
                
                return '';
            }''')
            
            await page.close()
            return ean or ''
            
        except Exception as e:
            print(f"   ⚠️ Could not extract EAN: {e}")
            return ''
    
    async def extract_product_description(self, item_number: str) -> str:
        """Extract and clean product description from product page"""
        try:
            page = await self.context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1500)
            
            # Extract and clean description
            description = await page.evaluate('''() => {
                // Try multiple selectors for description
                let descText = '';
                
                // Method 1: iframe description
                const iframe = document.querySelector('iframe#desc_ifr');
                if (iframe) {
                    try {
                        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                        descText = iframeDoc.body.innerText || iframeDoc.body.textContent || '';
                    } catch (e) {
                        // Cross-origin iframe, try to get src
                        const src = iframe.src;
                        if (src) {
                            // We'll handle this differently
                        }
                    }
                }
                
                // Method 2: Direct description div
                if (!descText) {
                    const descDiv = document.querySelector('.vim-description-content, .vim-d-description, .d-item-description');
                    if (descDiv) {
                        descText = descDiv.innerText || descDiv.textContent || '';
                    }
                }
                
                // Method 3: Tab panel description
                if (!descText) {
                    const tabPanel = document.querySelector('[role="tabpanel"][aria-labelledby*="description"]');
                    if (tabPanel) {
                        descText = tabPanel.innerText || '';
                    }
                }
                
                // Clean the text
                if (descText) {
                    // Remove excessive whitespace but preserve paragraph breaks
                    descText = descText
                        .replace(/[\r\n]+/g, '\n\n')  // Normalize line breaks to double
                        .replace(/[ \t]+/g, ' ')       // Replace multiple spaces/tabs with single space
                        .replace(/\n{3,}/g, '\n\n')    // Max 2 consecutive line breaks
                        .trim();
                    
                    // Remove common boilerplate text and seller policies
                    const boilerplates = [
                        // Date/time patterns like [28/08/2025, 6:26:20 AM]
                        /\\[\\d{1,2}\\/\\d{1,2}\\/\\d{4},\\s*\\d{1,2}:\\d{2}:\\d{2}\\s*[AP]M\\]/gi,
                        // Seller usernames with timestamps
                        /\\[.*?\\]\\s*[A-Za-z0-9\\s]+(?:UK|US|USA|EU)?:/gi,
                        // eBay specific
                        /eBay item number[:\\s]*\\d+/gi,
                        /Seller assumes all responsibility.*/gi,
                        /This item will ship to.*/gi,
                        /May not ship to.*/gi,
                        // Shipping policies
                        /Shipping and handling.*/gi,
                        /(?:International|Domestic)\\s+shipping.*/gi,
                        /Shipping cost.*/gi,
                        /Ships to:.*/gi,
                        /Excludes:.*/gi,
                        /Delivery time.*/gi,
                        /Estimated delivery.*/gi,
                        /Standard delivery.*/gi,
                        /Express delivery.*/gi,
                        /Economy delivery.*/gi,
                        // Return policies
                        /Returns?.*/gi,
                        /Refund.*/gi,
                        /Money back guarantee.*/gi,
                        /Return policy.*/gi,
                        /30 day returns?.*/gi,
                        /60 day returns?.*/gi,
                        /14 day returns?.*/gi,
                        /Buyer pays return.*/gi,
                        // Payment policies
                        /Payment method.*/gi,
                        /PayPal.*/gi,
                        /Immediate payment.*/gi,
                        /Payment must be.*/gi,
                        // Seller policies
                        /Seller's payment instructions.*/gi,
                        /Please read our.*/gi,
                        /Terms and conditions.*/gi,
                        /Business seller information.*/gi,
                        /VAT number.*/gi,
                        /Registered as.*/gi,
                        /Company number.*/gi,
                        // Contact/support
                        /Contact seller.*/gi,
                        /Ask a question.*/gi,
                        /Message the seller.*/gi,
                        /Customer service.*/gi,
                        /Please contact us.*/gi,
                        /Feel free to contact.*/gi,
                        /If you have any questions.*/gi,
                        // Feedback
                        /Please leave feedback.*/gi,
                        /Feedback is important.*/gi,
                        /We appreciate your feedback.*/gi,
                        // Condition notes that are too generic
                        /Condition is.*/gi,
                        /See photos for.*/gi,
                        /Please see photos.*/gi,
                        /Photos are of actual.*/gi,
                        // Business hours
                        /(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\\s*-\\s*(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday).*/gi,
                        /Business hours.*/gi,
                        /Office hours.*/gi,
                        // Dispatch time
                        /Dispatched within.*/gi,
                        /Will be dispatched.*/gi,
                        /Same day dispatch.*/gi,
                        /Next day dispatch.*/gi,
                        // Tracking
                        /Tracking number.*/gi,
                        /Tracked delivery.*/gi,
                        // Legal disclaimers
                        /Copyright.*/gi,
                        /All rights reserved.*/gi,
                        /Trademark.*/gi,
                        // eBay store promotions
                        /Visit my eBay store.*/gi,
                        /Check out my other items.*/gi,
                        /Add me to your favorite.*/gi,
                        /Sign up for newsletter.*/gi,
                        // Multiple line breaks (cleanup)
                        /\\n{4,}/g
                    ];
                    
                    for (let pattern of boilerplates) {
                        descText = descText.replace(pattern, '');
                    }
                    
                    // Additional cleanup for sections
                    // Remove sections that start with these headers
                    const sectionHeaders = [
                        'Shipping:',
                        'Shipping Policy:',
                        'Payment:',
                        'Returns:',
                        'Refunds:',
                        'About Us:',
                        'Feedback:',
                        'Contact:',
                        'Terms:',
                        'Conditions:',
                        'Postage:',
                        'Delivery:',
                        'Dispatch:'
                    ];
                    
                    for (let header of sectionHeaders) {
                        const regex = new RegExp(header + '[\\s\\S]*?(?=\\n\\n|$)', 'gi');
                        descText = descText.replace(regex, '');
                    }
                    
                    // Final cleanup - remove extra whitespace and empty lines
                    descText = descText
                        .replace(/\\n{3,}/g, '\\n\\n')  // Max 2 line breaks
                        .replace(/^\\s*\\n/gm, '')       // Remove empty lines
                        .trim();
                }
                
                return descText;
            }''')
            
            await page.close()
            
            # If description is empty or very short, it might be in an iframe
            if not description or len(description) < 50:
                # Try alternative approach - get the description frame URL
                page = await self.context.new_page()
                await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
                
                frame_url = await page.evaluate('''() => {
                    const iframe = document.querySelector('iframe#desc_ifr');
                    return iframe ? iframe.src : null;
                }''')
                
                if frame_url:
                    await page.goto(frame_url, wait_until='domcontentloaded', timeout=10000)
                    description = await page.evaluate('''() => {
                        const bodyText = document.body.innerText || document.body.textContent || '';
                        return bodyText
                            .replace(/[\r\n]+/g, '\n\n')
                            .replace(/[ \t]+/g, ' ')
                            .replace(/\n{3,}/g, '\n\n')
                            .trim();
                    }''')
                
                await page.close()
            
            return description or ''
            
        except Exception as e:
            return ''
    
    async def extract_products(self, page):
        """Extract products from the page using JavaScript"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // Try multiple selectors
            let productElements = document.querySelectorAll('li[data-viewport]');
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('.s-item');
            }
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('li[id*="item"]');
            }
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('[data-gr4]');
            }
            
            console.log('Found elements:', productElements.length);
            
            productElements.forEach((item) => {
                try {
                    // Skip if it contains sponsored or shop text
                    const itemText = item.innerText || '';
                    if (itemText.includes('SPONSORED') || itemText.includes('Shop on eBay')) {
                        return;
                    }
                    
                    // Find the link
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    const itemNumber = itemMatch[1];
                    
                    // Get title - try multiple selectors
                    let title = '';
                    const h3 = item.querySelector('h3');
                    if (h3) {
                        title = h3.innerText.trim();
                    } else {
                        const titleElem = item.querySelector('.s-item__title');
                        if (titleElem) {
                            title = titleElem.innerText.trim();
                        } else {
                            // Try to find any element with a long text that could be title
                            const spans = item.querySelectorAll('span');
                            for (let span of spans) {
                                const text = span.innerText.trim();
                                if (text.length > 20 && !text.startsWith('£')) {
                                    title = text;
                                    break;
                                }
                            }
                        }
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    } else {
                        // Look for any text with £
                        const priceMatch = itemText.match(/£[\\d,]+\\.?\\d*/);
                        if (priceMatch) {
                            price = priceMatch[0];
                        }
                    }
                    
                    // Get image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    // Get condition
                    let condition = '';
                    const conditionElem = item.querySelector('.SECONDARY_INFO');
                    if (conditionElem) {
                        condition = conditionElem.innerText.trim();
                    }
                    
                    // Get shipping
                    let shipping = '';
                    const shippingElem = item.querySelector('.s-item__shipping');
                    if (shippingElem) {
                        shipping = shippingElem.innerText.trim();
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemNumber,
                        url: 'https://www.ebay.co.uk/itm/' + itemNumber,
                        image: image,
                        condition: condition,
                        shipping: shipping
                    });
                    
                } catch (e) {
                    console.error('Error extracting item:', e);
                }
            });
            
            return items;
        }''')
        
        # Convert to our format
        formatted_products = []
        for p in products:
            formatted_products.append({
                'Title': p.get('title', ''),
                'Price': p.get('price', ''),
                'Ebay_Item_Number': p.get('item_number', ''),
                'EAN': '',
                'Description': '',  # Will be filled if extract_details is True
                'Image_URL_1': p.get('image', ''),
                'Image_URL_2': '',
                'Image_URL_3': '',
                'Image_URL_4': '',
                'Condition': p.get('condition', ''),
                'Shipping': p.get('shipping', ''),
                'URL': p.get('url', ''),
                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
        
        return formatted_products
    
    def show_final_report(self, products):
        """Show final scraping report"""
        elapsed = datetime.now() - self.start_time
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {len(products)}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"⏱️  Total time: {str(elapsed).split('.')[0]}")
        print(f"⚡ Average rate: {len(products)/(elapsed.total_seconds()/60):.1f} products/minute")
        print("="*70 + "\n")
    
    def save_to_excel(self, products, filename=None):
        """Save products to Excel"""
        if not products:
            print("❌ No products to save")
            return None
        
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_results_{timestamp}.xlsx"
        
        df = pd.DataFrame(products)
        df.to_excel(filename, index=False)
        
        print(f"💾 Saved {len(products)} products to: {filename}")
        
        return filename


async def main():
    """Test the scraper"""
    scraper = RobustPlaywrightScraper()
    
    # Your URL
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0"
    
    # Scrape 2 pages
    products = await scraper.scrape_url(url, max_pages=2)
    
    # Save results
    if products:
        scraper.save_to_excel(products)
        
        # Show sample
        print("\n📋 Sample results:")
        for i, product in enumerate(products[:5], 1):
            print(f"\n{i}. {product['Title'][:60]}...")
            print(f"   💰 {product['Price']}")
            print(f"   🔢 Item: {product['Ebay_Item_Number']}")
    else:
        print("❌ No products found. Please check the URL or try again.")


if __name__ == "__main__":
    asyncio.run(main())