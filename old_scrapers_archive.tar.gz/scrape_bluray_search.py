#!/usr/bin/env python3
"""
Scrape Blu-ray search results from eBay
"""

from simple_ebay_scraper import SimpleEbayScraper
import time

def main():
    print("\n" + "="*60)
    print("Scraping eBay Blu-ray Search Results")
    print("="*60 + "\n")
    
    scraper = SimpleEbayScraper()
    
    # Search for "blu ray" - this matches your URL
    search_query = "blu ray"
    
    print(f"🔍 Searching for: {search_query}")
    print("📄 Pages to scrape: 3 (you can adjust this)\n")
    
    # Get product URLs from search results
    urls = scraper.search_products(search_query, max_pages=3)
    
    print(f"\n✅ Found {len(urls)} products")
    
    if urls:
        print(f"📦 Now scraping product details for all {len(urls)} items...\n")
        
        # Scrape all products
        results = scraper.scrape_multiple(urls, delay=1)
        
        # Save to Excel
        filename = f"bluray_products_{time.strftime('%Y%m%d_%H%M%S')}.xlsx"
        scraper.save_to_excel(results, filename)
        
        # Show summary
        print(f"\n" + "="*60)
        print(f"✨ Scraping Complete!")
        print(f"📊 Products scraped: {len(results)}")
        print(f"📁 Saved to: {filename}")
        print("="*60)
        
        # Display sample results
        if results:
            print("\n📋 Sample Results:")
            for i, product in enumerate(results[:5], 1):
                print(f"\n{i}. {product['title'][:60]}...")
                print(f"   💰 Price: {product['price']}")
                print(f"   📦 Condition: {product['condition']}")
                print(f"   🔗 Item #: {product['item_number']}")

if __name__ == "__main__":
    main()