#!/usr/bin/env node

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());

async function testLocation() {
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });
    
    console.log('🌍 Testing eBay Location Detection\n');
    console.log('='.repeat(50));
    
    // First check what eBay thinks our location is
    await page.goto('https://www.ebay.co.uk', { waitUntil: 'networkidle2' });
    
    const ebayLocation = await page.evaluate(() => {
        // Check for location indicators
        const shipToText = document.querySelector('[data-testid="ship-to-location"]')?.innerText || 
                          document.querySelector('.gh-shipto-label')?.innerText || 
                          'Not found';
        
        // Check if redirected to different domain
        const currentDomain = window.location.hostname;
        
        // Look for country selector
        const countrySelector = document.querySelector('select[name="countryId"]')?.value || 
                               document.querySelector('[aria-label*="country"]')?.innerText || 
                               'Not found';
        
        return {
            shipTo: shipToText,
            domain: currentDomain,
            countryIndicator: countrySelector,
            url: window.location.href
        };
    });
    
    console.log('\n📍 eBay Location Detection:');
    console.log('  Domain:', ebayLocation.domain);
    console.log('  Ship To:', ebayLocation.shipTo);
    console.log('  URL:', ebayLocation.url);
    
    // Now test the actual search
    const searchUrl = 'https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0&_from=R40&LH_PrefLoc=1&LH_ItemCondition=1000&LH_BIN=1&LH_FS=1&Format=DVD%7C4K%2520UHD%2520Blu%252Dray%7CBlu%252Dray%7CBlu%252Dray%25203D&rt=nc&Genre=Horror&_dcat=617';
    
    console.log('\n🔍 Testing Search Results:');
    await page.goto(searchUrl, { waitUntil: 'networkidle2' });
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const searchResults = await page.evaluate(() => {
        const heading = document.querySelector('h1.srp-controls__count-heading');
        const noResultsMsg = document.querySelector('.srp-save-null-search__heading');
        const intlSellersMsg = Array.from(document.querySelectorAll('h2, h3')).find(el => 
            el.innerText.includes('international sellers') || 
            el.innerText.includes('sellers who ship to')
        );
        
        // Check URL for country code
        const urlParams = new URLSearchParams(window.location.search);
        const countryId = urlParams.get('_fcid');
        
        return {
            resultsHeading: heading?.innerText || 'No heading',
            noResultsMessage: noResultsMsg?.innerText || null,
            internationalMessage: intlSellersMsg?.innerText || null,
            countryIdParam: countryId,
            currentURL: window.location.href
        };
    });
    
    console.log('  Results heading:', searchResults.resultsHeading);
    console.log('  Country ID in URL:', searchResults.countryIdParam);
    if (searchResults.noResultsMessage) {
        console.log('  No results message:', searchResults.noResultsMessage);
    }
    if (searchResults.internationalMessage) {
        console.log('  International sellers:', searchResults.internationalMessage);
    }
    
    // Get IP location check
    console.log('\n🌐 IP Location Check:');
    await page.goto('https://ipapi.co/json/', { waitUntil: 'networkidle2' });
    const ipInfo = await page.evaluate(() => {
        return JSON.parse(document.body.innerText);
    });
    
    console.log('  Your IP:', ipInfo.ip);
    console.log('  Country:', ipInfo.country_name);
    console.log('  City:', ipInfo.city);
    console.log('  ISP:', ipInfo.org);
    
    console.log('\n' + '='.repeat(50));
    console.log('📋 DIAGNOSIS:');
    if (searchResults.countryIdParam === '3') {
        console.log('❌ eBay detected location as Pakistan (fcid=3)');
        console.log('   This is why you see "0 results" for UK-only items');
    } else if (searchResults.countryIdParam === '77') {
        console.log('✅ eBay detected location as UK (fcid=77)');
    }
    
    console.log('\n💡 SOLUTION:');
    console.log('   When your client runs this from a UK server:');
    console.log('   - eBay will detect UK location automatically');
    console.log('   - Will show 26,000+ UK seller results');
    console.log('   - No international sellers section');
    
    await browser.close();
}

testLocation().catch(console.error);