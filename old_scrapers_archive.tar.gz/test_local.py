#!/usr/bin/env python3
"""
Simple local test for eBay scraper without heavy dependencies
"""

import asyncio
import json
import sys
from typing import List, Dict
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup

class SimpleEBayScraper:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    async def search_ebay(self, query: str, max_pages: int = 2) -> List[Dict]:
        """Simple eBay search without heavy dependencies"""
        results = []
        
        for page in range(1, max_pages + 1):
            try:
                url = f"https://www.ebay.com/sch/i.html?_nkw={urllib.parse.quote(query)}&_pgn={page}"
                
                req = urllib.request.Request(url, headers=self.headers)
                with urllib.request.urlopen(req, timeout=10) as response:
                    html = response.read()
                
                soup = BeautifulSoup(html, 'html.parser')
                items = soup.find_all('div', class_='s-item__info')
                
                for item in items[:5]:  # Limit for testing
                    title_elem = item.find('h3', class_='s-item__title')
                    price_elem = item.find('span', class_='s-item__price')
                    link_elem = item.find('a', class_='s-item__link')
                    
                    if title_elem and price_elem and link_elem:
                        result = {
                            'title': title_elem.get_text(strip=True),
                            'price': price_elem.get_text(strip=True),
                            'url': link_elem.get('href', ''),
                            'page': page
                        }
                        results.append(result)
                        
                print(f"Page {page}: Found {len(results)} items")
                
            except Exception as e:
                print(f"Error on page {page}: {e}")
                continue
                
            await asyncio.sleep(1)  # Rate limiting
        
        return results

async def test_scraper():
    """Test the scraper with a simple query"""
    print("🧪 Testing eBay scraper locally...")
    
    scraper = SimpleEBayScraper()
    
    try:
        results = await scraper.search_ebay("blu ray", max_pages=1)
        
        print(f"\n✅ Test successful! Found {len(results)} items")
        
        if results:
            print("\n📊 Sample results:")
            for i, item in enumerate(results[:3], 1):
                print(f"{i}. {item['title'][:50]}... - {item['price']}")
        
        # Save results
        with open('test_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n💾 Results saved to test_results.json")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = asyncio.run(test_scraper())
    if success:
        print("\n🎉 Local test completed successfully!")
        print("\nNext steps:")
        print("1. Install dependencies: pip install aiohttp beautifulsoup4 fastapi uvicorn")
        print("2. Run full scraper: python ebay_scraper_optimized.py")
        print("3. Open browser: http://localhost:8000")
    else:
        sys.exit(1)