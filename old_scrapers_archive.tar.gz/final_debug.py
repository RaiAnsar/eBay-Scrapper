#!/usr/bin/env python3
"""
Final debug to see what's in the HTML
"""

import requests
from bs4 import BeautifulSoup
import re

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
})

url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
print(f"Fetching: {url}")
response = session.get(url, timeout=30)
print(f"Status: {response.status_code}")
print(f"URL after redirects: {response.url}")

soup = BeautifulSoup(response.text, 'html.parser')

# Check what we're actually getting
items = soup.find_all('li', {'data-viewport': True})
print(f"\nTotal items with data-viewport: {len(items)}")

# Let's look at items 3-8 (skip first 2)
test_items = items[2:8] if len(items) > 2 else items[:5]

for i, item in enumerate(test_items, 1):
    print(f"\n{'='*60}")
    print(f"Item {i}:")
    
    # Check what classes this item has
    classes = item.get('class', [])
    print(f"Classes: {classes}")
    
    # Look for ANY link with /itm/
    all_links = item.find_all('a', href=True)
    itm_links = [a for a in all_links if '/itm/' in a.get('href', '')]
    
    print(f"Links with /itm/: {len(itm_links)}")
    
    if itm_links:
        for link in itm_links[:1]:  # Just check first link
            href = link.get('href', '')
            print(f"Link: {href[:100]}...")
            
            # What's inside this link?
            # Check for title
            heading = link.find('span', {'role': 'heading'})
            if heading:
                print(f"Title in span[role=heading]: {heading.get_text(strip=True)[:50]}")
            
            h3 = link.find('h3')
            if h3:
                print(f"Title in h3: {h3.get_text(strip=True)[:50]}")
            
            div_title = link.find('div', class_='s-item__title')
            if div_title:
                print(f"Title in div.s-item__title: {div_title.get_text(strip=True)[:50]}")
    else:
        # No /itm/ links, let's see what's there
        print("No /itm/ links found!")
        # Show first 500 chars of HTML
        html_str = str(item)[:500]
        print(f"HTML snippet: {html_str}")

# Save full HTML for inspection
with open('ebay_page.html', 'w', encoding='utf-8') as f:
    f.write(response.text)
print(f"\n📁 Full HTML saved to ebay_page.html for inspection")