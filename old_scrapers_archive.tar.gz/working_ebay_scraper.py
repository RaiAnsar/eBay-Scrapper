#!/usr/bin/env python3
"""
WORKING eBay Scraper - Properly extracts all data including EAN and descriptions
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import json
import random
from typing import Dict, List, Set
import os

class WorkingEbayScraper:
    def __init__(self):
        self.products: List[Dict] = []
        self.seen_items: Set[str] = set()
        self.checkpoint_file = 'ebay_scraping_checkpoint.json'
        self.ean_cache = {}
        self.failed_ean_items = set()
        
    def load_checkpoint(self):
        """Load previous scraping progress"""
        if os.path.exists(self.checkpoint_file):
            try:
                with open(self.checkpoint_file, 'r') as f:
                    data = json.load(f)
                    self.products = data.get('products', [])
                    self.seen_items = set(data.get('seen_items', []))
                    self.ean_cache = data.get('ean_cache', {})
                    print(f"✅ Loaded checkpoint: {len(self.products)} products, {len(self.seen_items)} seen items")
                    return data.get('last_page', 0)
            except:
                print("⚠️ Could not load checkpoint, starting fresh")
        return 0
    
    def save_checkpoint(self, current_page: int):
        """Save current progress"""
        checkpoint_data = {
            'products': self.products,
            'seen_items': list(self.seen_items),
            'ean_cache': self.ean_cache,
            'last_page': current_page,
            'timestamp': datetime.now().isoformat()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint_data, f, indent=2)
        print(f"💾 Checkpoint saved: Page {current_page}, {len(self.products)} products")
    
    async def extract_ean_from_page(self, page, item_url: str, item_number: str) -> str:
        """Extract EAN from product page with multiple strategies"""
        
        # Check cache first
        if item_number in self.ean_cache:
            return self.ean_cache[item_number]
        
        # Skip if previously failed
        if item_number in self.failed_ean_items:
            return ''
        
        try:
            # Navigate to product page
            await page.goto(item_url, wait_until='domcontentloaded', timeout=20000)
            await page.wait_for_timeout(1500)
            
            # Strategy 1: Look for EAN in item specifics table
            ean = await page.evaluate('''() => {
                // Check item specifics table
                const rows = document.querySelectorAll('.ux-labels-values__labels');
                for(let row of rows) {
                    const text = row.textContent || '';
                    if(text.includes('EAN') || text.includes('UPC') || text.includes('ISBN')) {
                        const valueCell = row.nextElementSibling;
                        if(valueCell) {
                            const value = valueCell.textContent.trim();
                            if(value && value.match(/^[0-9]{8,13}$/)) {
                                return value;
                            }
                        }
                    }
                }
                
                // Strategy 2: Look in description for EAN patterns
                const desc = document.querySelector('.d-item-description') || 
                            document.querySelector('[data-testid="item-description"]') ||
                            document.querySelector('.vi-desc-maincntr');
                if(desc) {
                    const text = desc.textContent || '';
                    // Look for EAN: followed by numbers
                    const eanMatch = text.match(/EAN[:\s]+([0-9]{8,13})/i);
                    if(eanMatch) return eanMatch[1];
                    
                    // Look for UPC
                    const upcMatch = text.match(/UPC[:\s]+([0-9]{10,12})/i);
                    if(upcMatch) return upcMatch[1];
                    
                    // Look for ISBN
                    const isbnMatch = text.match(/ISBN[:\s]+([0-9]{10,13})/i);
                    if(isbnMatch) return isbnMatch[1];
                }
                
                // Strategy 3: Check structured data
                const ldJson = document.querySelector('script[type="application/ld+json"]');
                if(ldJson) {
                    try {
                        const data = JSON.parse(ldJson.textContent);
                        if(data.gtin13) return data.gtin13;
                        if(data.gtin) return data.gtin;
                        if(data.isbn) return data.isbn;
                    } catch(e) {}
                }
                
                return '';
            }''')
            
            if ean:
                self.ean_cache[item_number] = ean
                return ean
            else:
                self.failed_ean_items.add(item_number)
                return ''
                
        except Exception as e:
            print(f"      ⚠️ EAN extraction failed: {str(e)[:50]}")
            self.failed_ean_items.add(item_number)
            return ''
    
    async def extract_description_from_page(self, page, item_url: str) -> str:
        """Extract description from product page"""
        try:
            # Navigate if not already there
            if page.url != item_url:
                await page.goto(item_url, wait_until='domcontentloaded', timeout=20000)
                await page.wait_for_timeout(1500)
            
            description = await page.evaluate('''() => {
                // Try multiple selectors for description
                const descElements = [
                    document.querySelector('.d-item-description'),
                    document.querySelector('[data-testid="item-description"]'),
                    document.querySelector('.vi-desc-maincntr'),
                    document.querySelector('#viTabs_0_panel div')
                ];
                
                for(let elem of descElements) {
                    if(elem) {
                        let text = elem.innerText || elem.textContent || '';
                        // Clean up the text
                        text = text.replace(/\\s+/g, ' ').trim();
                        if(text.length > 50) {
                            return text.substring(0, 1000); // Limit to 1000 chars
                        }
                    }
                }
                
                return '';
            }''')
            
            return description
            
        except Exception:
            return ''
    
    async def scrape_ebay(self, search_term: str, max_pages: int = 5, extract_details: bool = True):
        """Main scraping function"""
        
        print("\n" + "="*70)
        print("🚀 WORKING eBay Scraper")
        print("="*70)
        print(f"🔍 Search: {search_term}")
        print(f"📄 Max pages: {max_pages}")
        print(f"📊 Extract EAN/Description: {extract_details}")
        print("="*70 + "\n")
        
        # Load checkpoint
        start_page = self.load_checkpoint() + 1
        
        async with async_playwright() as p:
            # Launch browser (visible for debugging)
            browser = await p.chromium.launch(
                headless=True,  # Set to False to see the browser
                args=['--disable-blink-features=AutomationControlled']
            )
            
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
            # Anti-detection
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
            """)
            
            page = await context.new_page()
            
            # Create second page for EAN/description extraction
            detail_page = await context.new_page() if extract_details else None
            
            # Establish session
            print("🌐 Establishing session...")
            await page.goto('https://www.ebay.co.uk')
            await page.wait_for_timeout(2000)
            
            # Accept cookies
            try:
                await page.click('#gdpr-banner-accept', timeout=2000)
                print("✅ Cookies accepted")
            except:
                pass
            
            # Main scraping loop
            for page_num in range(start_page, max_pages + 1):
                print(f"\n📄 Page {page_num}/{max_pages}")
                print("-" * 40)
                
                # Build search URL with 200 items per page
                search_url = f"https://www.ebay.co.uk/sch/i.html?_nkw={search_term.replace(' ', '+')}&_ipg=200"
                if page_num > 1:
                    search_url += f"&_pgn={page_num}"
                
                try:
                    # Navigate to search page
                    print(f"🔍 Loading: {search_url}")
                    await page.goto(search_url, wait_until='domcontentloaded', timeout=60000)
                    await page.wait_for_timeout(random.randint(2000, 3000))
                    
                    # Scroll to load lazy content
                    await page.evaluate('window.scrollTo(0, document.body.scrollHeight/2)')
                    await page.wait_for_timeout(1000)
                    
                    # Extract products from listing page
                    products = await page.evaluate('''() => {
                        const items = [];
                        const elements = document.querySelectorAll('li[data-viewport]');
                        
                        // Skip first 2 "Shop on eBay" items
                        for(let i = 2; i < elements.length; i++) {
                            const item = elements[i];
                            
                            // Get link
                            const link = item.querySelector('a[href*="/itm/"]');
                            if(!link) continue;
                            
                            const href = link.href;
                            const match = href.match(/\\/itm\\/(\\d+)/);
                            if(!match) continue;
                            
                            // Get title
                            let title = '';
                            const titleElem = item.querySelector('div[role="heading"] span') ||
                                            item.querySelector('.s-item__title') ||
                                            item.querySelector('h3');
                            if(titleElem) {
                                title = titleElem.innerText || titleElem.textContent || '';
                                title = title.trim();
                            }
                            
                            // Skip if no real title
                            if(!title || title === 'Shop on eBay' || title === 'New Listing') continue;
                            
                            // Get price - try multiple selectors
                            let price = '';
                            const priceElem = item.querySelector('.s-item__price') ||
                                            item.querySelector('[class*="price"]');
                            if(priceElem) {
                                price = priceElem.innerText || priceElem.textContent || '';
                                price = price.trim();
                            }
                            
                            // Get condition
                            let condition = '';
                            const condElem = item.querySelector('.SECONDARY_INFO') ||
                                           item.querySelector('[class*="condition"]');
                            if(condElem) {
                                condition = condElem.innerText || condElem.textContent || '';
                                condition = condition.trim();
                            }
                            
                            // Get shipping
                            let shipping = '';
                            const shipElem = item.querySelector('.s-item__shipping') ||
                                           item.querySelector('[class*="shipping"]');
                            if(shipElem) {
                                shipping = shipElem.innerText || shipElem.textContent || '';
                                shipping = shipping.trim();
                            }
                            
                            // Get image
                            let image = '';
                            const imgElem = item.querySelector('img');
                            if(imgElem) {
                                image = imgElem.src || imgElem.dataset.src || '';
                            }
                            
                            items.push({
                                item_number: match[1],
                                title: title,
                                price: price,
                                condition: condition,
                                shipping: shipping,
                                image: image,
                                url: href
                            });
                        }
                        
                        return items;
                    }''')
                    
                    print(f"📦 Found {len(products)} products on page")
                    
                    # Process products
                    new_products = 0
                    for idx, product in enumerate(products):
                        if product['item_number'] in self.seen_items:
                            continue
                        
                        self.seen_items.add(product['item_number'])
                        new_products += 1
                        
                        # Extract EAN and description if requested
                        ean = ''
                        description = ''
                        
                        if extract_details and detail_page and idx < 3:  # Limit to 3 per page to avoid burning resources
                            print(f"   🔍 Extracting details for: {product['title'][:50]}...")
                            ean = await self.extract_ean_from_page(detail_page, product['url'], product['item_number'])
                            description = await self.extract_description_from_page(detail_page, product['url'])
                            
                            if ean:
                                print(f"      ✅ EAN: {ean}")
                            if description:
                                print(f"      ✅ Description: {description[:50]}...")
                        
                        # Add to products list
                        self.products.append({
                            'Item_Number': product['item_number'],
                            'Title': product['title'],
                            'Price': product['price'],
                            'EAN': ean,
                            'Description': description[:500] if description else '',  # Limit description length
                            'Condition': product['condition'],
                            'Shipping': product['shipping'],
                            'Image_URL': product['image'],
                            'URL': product['url'],
                            'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                    
                    print(f"✅ Added {new_products} new products (Total: {len(self.products)})")
                    
                    # Save checkpoint every page
                    self.save_checkpoint(page_num)
                    
                    # Sample products display
                    if new_products > 0:
                        print("📋 Sample products:")
                        for p in self.products[-min(3, new_products):]:
                            print(f"   • {p['Title'][:60]}...")
                            if p['EAN']:
                                print(f"     EAN: {p['EAN']}")
                    
                except Exception as e:
                    print(f"❌ Error on page {page_num}: {str(e)}")
                    continue
                
                # Human-like delay between pages
                if page_num < max_pages:
                    delay = random.randint(3, 5)
                    print(f"⏳ Waiting {delay} seconds...")
                    await asyncio.sleep(delay)
            
            await browser.close()
        
        # Save results to Excel
        if self.products:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            excel_file = f'ebay_products_{timestamp}.xlsx'
            csv_file = f'ebay_products_{timestamp}.csv'
            
            df = pd.DataFrame(self.products)
            
            # Save Excel
            with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Products', index=False)
                
                # Auto-adjust column widths
                worksheet = writer.sheets['Products']
                for column in df:
                    column_width = max(df[column].astype(str).map(len).max(), len(column))
                    column_width = min(column_width, 50)  # Cap at 50 chars
                    col_idx = df.columns.get_loc(column)
                    worksheet.column_dimensions[chr(65 + col_idx)].width = column_width
            
            # Save CSV as backup
            df.to_csv(csv_file, index=False)
            
            print(f"\n" + "="*70)
            print("📊 SCRAPING COMPLETE")
            print("="*70)
            print(f"✅ Total products: {len(self.products)}")
            print(f"✅ Products with EAN: {sum(1 for p in self.products if p.get('EAN'))}")
            print(f"✅ Products with Description: {sum(1 for p in self.products if p.get('Description'))}")
            print(f"📁 Excel saved: {excel_file}")
            print(f"📁 CSV saved: {csv_file}")
            print("="*70)
            
            return self.products
        else:
            print("\n❌ No products scraped")
            return []

async def main():
    """Main function"""
    scraper = WorkingEbayScraper()
    
    # Scrape eBay for blu ray products
    products = await scraper.scrape_ebay(
        search_term="blu ray",
        max_pages=3,  # Start with 3 pages for testing
        extract_details=True  # Set to False for faster scraping without EAN/description
    )
    
    print(f"\n✅ Complete! Scraped {len(products)} products")

if __name__ == "__main__":
    print("\n🚀 Starting Working eBay Scraper...")
    print("📌 This scraper properly extracts all data including EAN and descriptions")
    print("📌 It saves checkpoints so you can resume if interrupted\n")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️ Scraping interrupted by user")
        print("📌 Progress has been saved. Run again to resume.")
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        print("📌 Progress has been saved. Run again to resume.")