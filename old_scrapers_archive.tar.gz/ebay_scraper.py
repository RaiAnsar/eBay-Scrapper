#!/usr/bin/env python3
"""
eBay Product Scraper - Alternative to Octoparse
Extracts product data from eBay listings efficiently and cost-effectively
"""

import asyncio
import json
import re
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Optional, Dict
from urllib.parse import urlparse, parse_qs
import logging

import pandas as pd
import requests
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
import sqlite3

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class eBayProduct:
    """Data structure for eBay product information"""
    page_url: str
    title: str
    price: str
    ean: Optional[str] = None
    main_image: Optional[str] = None
    gallery_images: Optional[str] = None
    key_points: Optional[str] = None
    description_html: Optional[str] = None
    seller: Optional[str] = None
    condition: Optional[str] = None
    shipping: Optional[str] = None
    availability: Optional[str] = None
    item_number: Optional[str] = None
    category: Optional[str] = None
    brand: Optional[str] = None
    mpn: Optional[str] = None
    scraped_at: str = ""

class eBayScraper:
    def __init__(self, use_proxy: bool = False, headless: bool = True):
        self.use_proxy = use_proxy
        self.headless = headless
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
    async def scrape_with_playwright(self, url: str) -> Optional[eBayProduct]:
        """Scrape eBay listing using Playwright for JavaScript-rendered content"""
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.headless)
            page = await browser.new_page()
            
            try:
                await page.goto(url, wait_until='networkidle', timeout=30000)
                await page.wait_for_selector('[data-testid="x-item-title"]', timeout=10000)
                
                # Extract product data
                product = await self._extract_product_data(page, url)
                
                await browser.close()
                return product
                
            except Exception as e:
                logger.error(f"Error scraping {url}: {e}")
                await browser.close()
                return None
    
    async def _extract_product_data(self, page, url: str) -> eBayProduct:
        """Extract product data from page"""
        
        # Title
        title = await page.evaluate('''() => {
            const el = document.querySelector('[data-testid="x-item-title"] span') || 
                       document.querySelector('h1.it-ttl') || 
                       document.querySelector('h1');
            return el ? el.innerText : '';
        }''')
        
        # Price
        price = await page.evaluate('''() => {
            const el = document.querySelector('[data-testid="x-price-primary"] span') || 
                       document.querySelector('.x-price-primary') ||
                       document.querySelector('[itemprop="price"]');
            return el ? el.innerText : '';
        }''')
        
        # Main Image
        main_image = await page.evaluate('''() => {
            const el = document.querySelector('.ux-image-magnify__container img') || 
                       document.querySelector('[data-testid="primary-image"] img');
            return el ? el.src : '';
        }''')
        
        # Gallery Images
        gallery_images = await page.evaluate('''() => {
            const images = document.querySelectorAll('.ux-image-filmstrip img, .ux-image-carousel img');
            return Array.from(images).map(img => img.src).join(',');
        }''')
        
        # EAN/UPC
        ean = await page.evaluate('''() => {
            const rows = document.querySelectorAll('.ux-layout-section__row');
            for(let row of rows) {
                if(row.innerText.includes('EAN') || row.innerText.includes('UPC')) {
                    const value = row.querySelector('.ux-textspans--BOLD');
                    return value ? value.innerText : '';
                }
            }
            return '';
        }''')
        
        # Item Number
        item_number = await page.evaluate('''() => {
            const el = document.querySelector('[data-testid="x-item-number"]') ||
                       document.querySelector('.vi-acc-num');
            return el ? el.innerText.replace('Item number: ', '') : '';
        }''')
        
        # Seller
        seller = await page.evaluate('''() => {
            const el = document.querySelector('[data-testid="str-title"] a') ||
                       document.querySelector('.si-inner .mbg-nw');
            return el ? el.innerText : '';
        }''')
        
        # Condition
        condition = await page.evaluate('''() => {
            const el = document.querySelector('[data-testid="x-item-condition-value"] span') ||
                       document.querySelector('.u-flL.condText');
            return el ? el.innerText : '';
        }''')
        
        # Key Points
        key_points = await page.evaluate('''() => {
            const points = document.querySelectorAll('[data-testid="x-item-features"] li');
            return Array.from(points).map(p => p.innerText).join(' | ');
        }''')
        
        # Description HTML
        description_html = await page.evaluate('''() => {
            const iframe = document.querySelector('#desc_ifr');
            if(iframe) {
                return iframe.outerHTML;
            }
            const desc = document.querySelector('[data-testid="x-item-description"]');
            return desc ? desc.innerHTML : '';
        }''')
        
        # Category
        category = await page.evaluate('''() => {
            const breadcrumb = document.querySelector('.vi-VR-brumb-lnkLst');
            return breadcrumb ? breadcrumb.innerText.replace(/\\n/g, ' > ') : '';
        }''')
        
        # Brand
        brand = await page.evaluate('''() => {
            const rows = document.querySelectorAll('.ux-layout-section__row');
            for(let row of rows) {
                if(row.innerText.includes('Brand')) {
                    const value = row.querySelector('.ux-textspans--BOLD');
                    return value ? value.innerText : '';
                }
            }
            return '';
        }''')
        
        # MPN
        mpn = await page.evaluate('''() => {
            const rows = document.querySelectorAll('.ux-layout-section__row');
            for(let row of rows) {
                if(row.innerText.includes('MPN')) {
                    const value = row.querySelector('.ux-textspans--BOLD');
                    return value ? value.innerText : '';
                }
            }
            return '';
        }''')
        
        return eBayProduct(
            page_url=url,
            title=title.strip(),
            price=price.strip(),
            ean=ean.strip() if ean else None,
            main_image=main_image,
            gallery_images=gallery_images,
            key_points=key_points,
            description_html=description_html,
            seller=seller.strip() if seller else None,
            condition=condition.strip() if condition else None,
            item_number=item_number.strip() if item_number else None,
            category=category.strip() if category else None,
            brand=brand.strip() if brand else None,
            mpn=mpn.strip() if mpn else None,
            scraped_at=datetime.now().isoformat()
        )
    
    def scrape_with_requests(self, url: str) -> Optional[eBayProduct]:
        """Lightweight scraping using requests and BeautifulSoup"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract item number from URL
            item_match = re.search(r'/itm/(\d+)', url)
            item_number = item_match.group(1) if item_match else None
            
            # Title
            title_elem = soup.select_one('h1.it-ttl') or soup.select_one('h1')
            title = title_elem.get_text(strip=True) if title_elem else ""
            
            # Price
            price_elem = soup.select_one('[itemprop="price"]') or soup.select_one('.x-price-primary')
            price = price_elem.get('content') if price_elem and price_elem.has_attr('content') else ""
            if not price and price_elem:
                price = price_elem.get_text(strip=True)
            
            # Main Image
            img_elem = soup.select_one('[itemprop="image"]') or soup.select_one('#icImg')
            main_image = img_elem.get('src') if img_elem else ""
            
            # EAN/UPC
            ean = None
            for row in soup.select('.ux-layout-section__row'):
                if 'EAN' in row.get_text() or 'UPC' in row.get_text():
                    value_elem = row.select_one('.ux-textspans--BOLD')
                    if value_elem:
                        ean = value_elem.get_text(strip=True)
                        break
            
            # Seller
            seller_elem = soup.select_one('.si-inner .mbg-nw')
            seller = seller_elem.get_text(strip=True) if seller_elem else None
            
            # Condition
            condition_elem = soup.select_one('.u-flL.condText')
            condition = condition_elem.get_text(strip=True) if condition_elem else None
            
            return eBayProduct(
                page_url=url,
                title=title,
                price=price,
                ean=ean,
                main_image=main_image,
                item_number=item_number,
                seller=seller,
                condition=condition,
                scraped_at=datetime.now().isoformat()
            )
            
        except Exception as e:
            logger.error(f"Error scraping {url} with requests: {e}")
            return None
    
    async def scrape_search_results(self, search_query: str, max_pages: int = 1) -> List[str]:
        """Scrape search results to get product URLs"""
        urls = []
        base_url = "https://www.ebay.co.uk/sch/i.html"
        
        for page in range(1, max_pages + 1):
            params = {
                '_nkw': search_query,
                '_pgn': page,
                'LH_ItemCondition': '4'  # Used condition
            }
            
            try:
                response = self.session.get(base_url, params=params, timeout=10)
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Find all product links
                for link in soup.select('.s-item__link'):
                    href = link.get('href')
                    if href and '/itm/' in href:
                        urls.append(href.split('?')[0])  # Clean URL
                
                logger.info(f"Found {len(urls)} products on page {page}")
                await asyncio.sleep(1)  # Be respectful
                
            except Exception as e:
                logger.error(f"Error scraping search page {page}: {e}")
        
        return urls
    
    async def scrape_multiple(self, urls: List[str], use_playwright: bool = True) -> List[eBayProduct]:
        """Scrape multiple URLs"""
        products = []
        
        for i, url in enumerate(urls, 1):
            logger.info(f"Scraping {i}/{len(urls)}: {url}")
            
            if use_playwright:
                product = await self.scrape_with_playwright(url)
            else:
                product = self.scrape_with_requests(url)
            
            if product:
                products.append(product)
            
            # Rate limiting
            await asyncio.sleep(2)
        
        return products
    
    def save_to_excel(self, products: List[eBayProduct], filename: str = "ebay_products.xlsx"):
        """Save products to Excel file"""
        df = pd.DataFrame([asdict(p) for p in products])
        df.to_excel(filename, index=False)
        logger.info(f"Saved {len(products)} products to {filename}")
    
    def save_to_csv(self, products: List[eBayProduct], filename: str = "ebay_products.csv"):
        """Save products to CSV file"""
        df = pd.DataFrame([asdict(p) for p in products])
        df.to_csv(filename, index=False)
        logger.info(f"Saved {len(products)} products to {filename}")
    
    def save_to_database(self, products: List[eBayProduct], db_path: str = "ebay_products.db"):
        """Save products to SQLite database"""
        conn = sqlite3.connect(db_path)
        df = pd.DataFrame([asdict(p) for p in products])
        df.to_sql('products', conn, if_exists='append', index=False)
        conn.close()
        logger.info(f"Saved {len(products)} products to database")

async def main():
    """Main function to demonstrate scraper usage"""
    scraper = eBayScraper(headless=True)
    
    # Example 1: Scrape search results
    logger.info("Searching for Blu-ray products...")
    urls = await scraper.scrape_search_results("blu ray musicmagpie", max_pages=1)
    
    # Example 2: Scrape individual products
    if urls:
        logger.info(f"Scraping {len(urls[:5])} products...")
        products = await scraper.scrape_multiple(urls[:5], use_playwright=True)
        
        # Save results
        if products:
            scraper.save_to_excel(products, "ebay_bluray_products.xlsx")
            scraper.save_to_csv(products, "ebay_bluray_products.csv")
            scraper.save_to_database(products, "ebay_products.db")
    
    # Example 3: Scrape specific URLs (from your sample)
    sample_urls = [
        "https://www.ebay.co.uk/itm/296667726490",
        "https://www.ebay.co.uk/itm/386978552699",
        "https://www.ebay.co.uk/itm/306029555289"
    ]
    
    logger.info("Scraping sample URLs...")
    sample_products = await scraper.scrape_multiple(sample_urls[:1], use_playwright=True)
    
    if sample_products:
        scraper.save_to_excel(sample_products, "sample_products.xlsx")

if __name__ == "__main__":
    asyncio.run(main())