#!/usr/bin/env python3
"""
Optimized eBay Scraper - Fast but Stable
- Uses 3 parallel workers (not 10) to avoid overwhelming the system
- Proper error handling and retry logic
- Actually captures EAN and descriptions
- Adaptive timeouts based on load
"""

import asyncio
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout
import pandas as pd
from datetime import datetime
import re
from typing import List, Dict, Optional
import json

class OptimizedEbayScraper:
    def __init__(self, max_workers=3):  # Reduced from 10 to 3 for stability
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        self.browser = None
        self.playwright = None
        self.max_workers = max_workers
        self.context_pool = []
        self.failed_items = []
        
    async def initialize(self):
        """Initialize browser and context pool"""
        self.playwright = await async_playwright().start()
        
        # Launch with optimized settings
        self.browser = await self.playwright.chromium.launch(
            headless=True,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--disable-dev-shm-usage',  # Overcome limited resource problems
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-gpu',
                '--disable-web-security',
                '--disable-features=IsolateOrigins,site-per-process'
            ]
        )
        
        # Create contexts with different user agents for diversity
        user_agents = [
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        ]
        
        for i in range(self.max_workers):
            context = await self.browser.new_context(
                user_agent=user_agents[i % len(user_agents)] + ' Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080},
                ignore_https_errors=True,
                java_script_enabled=True
            )
            
            # Set extra headers to look more human
            await context.set_extra_http_headers({
                'Accept-Language': 'en-GB,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
            })
            
            self.context_pool.append(context)
    
    async def close(self):
        """Close all contexts and browser"""
        for context in self.context_pool:
            await context.close()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
    
    async def scrape_url(self, search_url: str, max_pages: int = 10, 
                        extract_ean: bool = False, extract_description: bool = False,
                        progress_callback=None):
        """Main scraping function with optimized parallel processing"""
        self.start_time = datetime.now()
        await self.initialize()
        
        print("\n" + "="*70)
        print("⚡ OPTIMIZED eBay Scraper - Fast & Stable")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"🔧 Workers: {self.max_workers} (optimized for stability)")
        print(f"📊 Extract EAN: {extract_ean}")
        print(f"📝 Extract Description: {extract_description}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        
        # Use first context for search pages
        search_page = await self.context_pool[0].new_page()
        
        for page_num in range(1, max_pages + 1):
            print(f"\n📄 Processing Page {page_num}/{max_pages}")
            print("-" * 40)
            
            if progress_callback:
                await progress_callback(page_num, len(all_products))
            
            # Construct URL for page
            if page_num == 1:
                url = search_url
            else:
                url = f"{search_url}&_pgn={page_num}" if '?' in search_url else f"{search_url}?_pgn={page_num}"
            
            try:
                # Load search page with retries
                for attempt in range(3):
                    try:
                        print(f"   Loading page (attempt {attempt + 1})...")
                        await search_page.goto(url, wait_until='networkidle', timeout=20000)
                        await search_page.wait_for_timeout(2000)
                        break
                    except PlaywrightTimeout:
                        if attempt == 2:
                            print(f"   ⚠️ Page load timeout after 3 attempts")
                            raise
                        await search_page.wait_for_timeout(1000)
                
                # Extract all products from page
                products = await self.extract_products_from_page(search_page)
                
                # Filter duplicates
                new_products = []
                for product in products:
                    item_num = product.get('Ebay_Item_Number', '')
                    if item_num and item_num not in self.seen_items:
                        self.seen_items.add(item_num)
                        new_products.append(product)
                
                print(f"✅ Found: {len(products)} items ({len(new_products)} new)")
                
                # Process details in smaller batches if requested
                if (extract_ean or extract_description) and new_products:
                    print(f"🔄 Fetching details for {len(new_products)} products...")
                    
                    # Process in batches of max_workers size
                    batch_size = self.max_workers - 1  # Reserve one for search page
                    for i in range(0, len(new_products), batch_size):
                        batch = new_products[i:i + batch_size]
                        
                        # Create tasks for this batch
                        tasks = []
                        for j, product in enumerate(batch):
                            item_num = product.get('Ebay_Item_Number', '')
                            if item_num:
                                context_idx = (j % (len(self.context_pool) - 1)) + 1
                                task = self.fetch_product_details_with_retry(
                                    item_num,
                                    self.context_pool[context_idx],
                                    extract_ean,
                                    extract_description
                                )
                                tasks.append(task)
                        
                        # Execute batch and wait
                        if tasks:
                            print(f"   Processing batch {i//batch_size + 1}...")
                            results = await asyncio.gather(*tasks, return_exceptions=False)
                            
                            # Update products with fetched details
                            success_count = 0
                            for idx, result in enumerate(results):
                                if isinstance(result, dict) and result:
                                    batch[idx].update(result)
                                    if result.get('EAN') or result.get('Description'):
                                        success_count += 1
                            
                            print(f"   ✓ Captured details for {success_count}/{len(batch)} products")
                            
                            # Small delay between batches
                            await asyncio.sleep(1)
                
                all_products.extend(new_products)
                self.products_scraped += len(new_products)
                
                # Update progress
                if progress_callback:
                    await progress_callback(page_num, len(all_products))
                
                # Show sample products with details
                if new_products and (extract_ean or extract_description):
                    for i, p in enumerate(new_products[:2], 1):
                        print(f"   Sample {i}: {p['Title'][:50]}...")
                        if p.get('EAN'):
                            print(f"      EAN: {p['EAN']}")
                        if p.get('Description'):
                            print(f"      Desc: {p['Description'][:50]}...")
                
                if len(products) == 0:
                    print("   ℹ️ No more products found, stopping")
                    break
                    
            except Exception as e:
                print(f"❌ Error on page {page_num}: {str(e)[:100]}")
            
            # Rate limiting between pages
            if page_num < max_pages:
                await search_page.wait_for_timeout(2000)
        
        await search_page.close()
        await self.close()
        
        # Final report
        duration = (datetime.now() - self.start_time).total_seconds()
        rate = (self.products_scraped / duration * 60) if duration > 0 else 0
        
        # Count successful extractions
        ean_count = sum(1 for p in all_products if p.get('EAN'))
        desc_count = sum(1 for p in all_products if p.get('Description'))
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {self.products_scraped}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"📊 Products with EAN: {ean_count}/{len(all_products)}")
        print(f"📝 Products with Description: {desc_count}/{len(all_products)}")
        print(f"❌ Failed extractions: {len(self.failed_items)}")
        print(f"⏱️  Total time: {int(duration//60)}:{int(duration%60):02d}")
        print(f"⚡ Average rate: {rate:.1f} products/minute")
        print("="*70 + "\n")
        
        return all_products
    
    async def fetch_product_details_with_retry(self, item_number: str, context,
                                              extract_ean: bool, extract_description: bool,
                                              max_retries: int = 2):
        """Fetch product details with retry logic"""
        for attempt in range(max_retries):
            try:
                result = await self.fetch_product_details(
                    item_number, context, extract_ean, extract_description
                )
                if result and (result.get('EAN') or result.get('Description')):
                    return result
            except Exception as e:
                if attempt == max_retries - 1:
                    self.failed_items.append(item_number)
                    print(f"      ⚠️ Failed {item_number}: {str(e)[:50]}")
                await asyncio.sleep(1)
        
        return {'EAN': '', 'Description': ''}
    
    async def fetch_product_details(self, item_number: str, context, 
                                   extract_ean: bool, extract_description: bool):
        """Fetch EAN and/or description for a single product"""
        result = {}
        page = None
        
        try:
            page = await context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            # Navigate with shorter timeout
            await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
            
            # Wait for content to load
            await page.wait_for_timeout(1500)
            
            # Extract both in one evaluation for efficiency
            data = await page.evaluate('''(extractEan, extractDesc) => {
                const result = {};
                
                if (extractEan) {
                    // Extract EAN with multiple methods
                    let ean = '';
                    
                    // Method 1: Look in item specifics section
                    const itemSpecifics = document.querySelectorAll('.ux-layout-section__item, .ux-labels-values__values');
                    for (let elem of itemSpecifics) {
                        const text = elem.innerText || '';
                        if (text.match(/\\d{8,13}/)) {
                            const prevElem = elem.previousElementSibling;
                            if (prevElem && prevElem.innerText && 
                                (prevElem.innerText.includes('EAN') || 
                                 prevElem.innerText.includes('UPC') || 
                                 prevElem.innerText.includes('ISBN'))) {
                                ean = text.match(/\\d{8,13}/)[0];
                                break;
                            }
                        }
                    }
                    
                    // Method 2: Look in any table rows
                    if (!ean) {
                        const rows = document.querySelectorAll('tr, .ux-layout-section__row');
                        for (let row of rows) {
                            const text = row.innerText || '';
                            if (text.includes('EAN') || text.includes('UPC')) {
                                const match = text.match(/\\d{8,13}/);
                                if (match) {
                                    ean = match[0];
                                    break;
                                }
                            }
                        }
                    }
                    
                    // Method 3: Look in description
                    if (!ean) {
                        const descElements = document.querySelectorAll('.vim-description-content, [data-testid="item-description"]');
                        for (let desc of descElements) {
                            const text = desc.innerText || '';
                            const eanMatch = text.match(/EAN[:\\s]*(\\d{8,13})/i);
                            if (eanMatch) {
                                ean = eanMatch[1];
                                break;
                            }
                        }
                    }
                    
                    result.ean = ean;
                }
                
                if (extractDesc) {
                    // Extract description
                    let descText = '';
                    
                    // Try multiple selectors
                    const selectors = [
                        '.vim-description-content',
                        '[data-testid="item-description"]',
                        '.vim-d-description',
                        '.d-item-description'
                    ];
                    
                    for (let selector of selectors) {
                        const elem = document.querySelector(selector);
                        if (elem && elem.innerText) {
                            descText = elem.innerText;
                            break;
                        }
                    }
                    
                    // Try iframe as last resort
                    if (!descText) {
                        const iframe = document.querySelector('iframe#desc_ifr');
                        if (iframe) {
                            try {
                                const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                                descText = iframeDoc.body.innerText || '';
                            } catch (e) {}
                        }
                    }
                    
                    // Clean description
                    if (descText) {
                        descText = descText
                            .replace(/\\[(\\d{1,2}\\/\\d{1,2}\\/\\d{4}),\\s*\\d{1,2}:\\d{2}:\\d{2}\\s*[AP]M\\]/gi, '')
                            .replace(/Shipping.*/gis, '')
                            .replace(/Returns?.*/gis, '')
                            .replace(/Payment.*/gis, '')
                            .replace(/Postage.*/gis, '')
                            .replace(/\\n{3,}/g, '\\n\\n')
                            .trim()
                            .substring(0, 2000);  // Limit to 2000 chars
                    }
                    
                    result.description = descText;
                }
                
                return result;
            }''', extract_ean, extract_description)
            
            if extract_ean:
                result['EAN'] = data.get('ean', '')
            if extract_description:
                result['Description'] = data.get('description', '')
            
        except Exception as e:
            # Log but don't crash
            pass
        finally:
            if page:
                await page.close()
        
        return result
    
    async def extract_products_from_page(self, page):
        """Extract products from search results page"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // eBay UK uses li[data-viewport] for product items
            let productElements = document.querySelectorAll('li[data-viewport]');
            
            // Fallback to .s-item if no data-viewport items found
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('.s-item');
            }
            
            productElements.forEach((item, index) => {
                try {
                    // Skip items without product links
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    // Skip "Shop on eBay" placeholder items
                    const titleElem = item.querySelector('h3, .s-item__title, [role="heading"]');
                    if (titleElem && titleElem.innerText === 'Shop on eBay') return;
                    
                    // Skip sponsored items
                    const itemText = item.innerText || '';
                    if (itemText.includes('SPONSORED')) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    const itemNumber = itemMatch[1];
                    
                    // Get title - already checked above, reuse
                    let title = titleElem ? titleElem.innerText.trim() : '';
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    // Get image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    // Get condition
                    let condition = '';
                    const conditionElem = item.querySelector('.SECONDARY_INFO');
                    if (conditionElem) {
                        condition = conditionElem.innerText.trim();
                    }
                    
                    // Get shipping
                    let shipping = '';
                    const shippingElem = item.querySelector('.s-item__shipping');
                    if (shippingElem) {
                        shipping = shippingElem.innerText.trim();
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemNumber,
                        image: image,
                        condition: condition,
                        shipping: shipping
                    });
                } catch (e) {}
            });
            
            return items;
        }''')
        
        # Format products
        return [{
            'Title': p['title'],
            'Price': p['price'],
            'Ebay_Item_Number': p['item_number'],
            'EAN': '',
            'Description': '',
            'Image_URL_1': p['image'],
            'Image_URL_2': '',
            'Image_URL_3': '',
            'Image_URL_4': '',
            'Condition': p['condition'],
            'Shipping': p['shipping'],
            'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}",
            'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        } for p in products]

# Test the optimized scraper
async def test_optimized():
    scraper = OptimizedEbayScraper(max_workers=3)  # Reduced workers
    
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    products = await scraper.scrape_url(
        search_url,
        max_pages=2,
        extract_ean=True,
        extract_description=True
    )
    
    print(f"\n✅ Total products scraped: {len(products)}")
    
    # Count successes
    ean_count = sum(1 for p in products if p.get('EAN'))
    desc_count = sum(1 for p in products if p.get('Description'))
    
    print(f"📊 Products with EAN: {ean_count}")
    print(f"📝 Products with Description: {desc_count}")
    
    # Save to Excel
    if products:
        df = pd.DataFrame(products)
        filename = f"optimized_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        df.to_excel(filename, index=False)
        print(f"📁 Saved to: {filename}")
        
        # Show samples
        print("\n📋 Sample products with details:")
        for i, p in enumerate(products[:3], 1):
            if p.get('EAN') or p.get('Description'):
                print(f"\n{i}. {p['Title'][:60]}...")
                if p['EAN']:
                    print(f"   EAN: {p['EAN']}")
                if p['Description']:
                    print(f"   Desc: {p['Description'][:100]}...")

if __name__ == "__main__":
    asyncio.run(test_optimized())