#!/usr/bin/env python3
"""
ENHANCED eBay Scraper - Incorporating best practices from GitHub repos
- Uses 200 items per page (from bilalahhmedd's scraper)
- Tracks product IDs to avoid duplicates
- Better selectors from real scrapers
- Incremental saving with checkpoints
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import random
import json
import os
from typing import Set, List, Dict

class EnhancedEbayScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items: Set[str] = set()
        self.checkpoint_file = 'ebay_checkpoint.json'
        self.data_dir = 'ebay_data'
        
        # Create data directory
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
    
    def save_checkpoint(self, page_num: int):
        """Save progress checkpoint"""
        checkpoint = {
            'last_page': page_num,
            'seen_items': list(self.seen_items),
            'products_count': self.products_scraped,
            'timestamp': datetime.now().isoformat()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint, f, indent=2)
    
    def load_checkpoint(self) -> int:
        """Load previous checkpoint"""
        if os.path.exists(self.checkpoint_file):
            with open(self.checkpoint_file, 'r') as f:
                checkpoint = json.load(f)
                self.seen_items = set(checkpoint['seen_items'])
                self.products_scraped = checkpoint['products_count']
                print(f"📚 Resuming from page {checkpoint['last_page']+1}")
                print(f"   Already scraped: {self.products_scraped} products")
                return checkpoint['last_page']
        return 0
    
    async def scrape_ebay_enhanced(self, search_url: str, max_pages: int = 100,
                                  extract_ean: bool = True, 
                                  extract_description: bool = True,
                                  items_per_page: int = 200):  # 200 items per page!
        """Enhanced scraping with techniques from GitHub repos"""
        
        print("\n" + "="*70)
        print("🚀 ENHANCED eBay Scraper - Best of GitHub")
        print("="*70)
        print(f"📍 URL: {search_url}")
        print(f"📄 Max pages: {max_pages}")
        print(f"📦 Items per page: {items_per_page} (3x more than default!)")
        print(f"📊 Extract EAN: {extract_ean}")
        print(f"📝 Extract Description: {extract_description}")
        print("="*70 + "\n")
        
        # Load checkpoint
        start_page = self.load_checkpoint()
        
        all_products = []
        
        async with async_playwright() as p:
            # Launch browser (visible to avoid detection)
            browser = await p.chromium.launch(
                headless=False,  # Visible browser
                args=[
                    '--disable-blink-features=AutomationControlled',
                    '--disable-extensions',  # From Puppeteer repo
                    '--start-maximized'
                ]
            )
            
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
            # Anti-detection
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                window.chrome = {runtime: {}};
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1,2,3,4,5]
                });
            """)
            
            page = await context.new_page()
            
            # Go to eBay first
            print("🌐 Establishing session...")
            await page.goto('https://www.ebay.co.uk')
            await page.wait_for_timeout(3000)
            
            # Accept cookies
            try:
                await page.click('#gdpr-banner-accept', timeout=2000)
            except:
                pass
            
            # Main scraping loop
            for page_num in range(start_page + 1, start_page + max_pages + 1):
                print(f"\n📄 Page {page_num} ({items_per_page} items per page)")
                print("-" * 40)
                
                # Build URL with 200 items per page (from Scrapy repo)
                if page_num == 1:
                    url = f"{search_url}&_ipg={items_per_page}"
                else:
                    url = f"{search_url}&_ipg={items_per_page}&_pgn={page_num}"
                
                try:
                    # Navigate
                    await page.goto(url, wait_until='networkidle', timeout=30000)
                    await page.wait_for_timeout(random.randint(3000, 5000))
                    
                    # Scroll to load lazy images
                    for i in range(3):
                        await page.evaluate(f'window.scrollTo(0, document.body.scrollHeight * {i/3})')
                        await page.wait_for_timeout(500)
                    
                    # Extract products using multiple selectors (combined from repos)
                    products = await page.evaluate('''() => {
                        const items = [];
                        
                        // Try multiple selectors from different repos
                        let productElements = document.querySelectorAll('li[data-viewport]');
                        
                        if (productElements.length === 0) {
                            productElements = document.querySelectorAll('div[class="s-item__wrapper clearfix"]');
                        }
                        
                        if (productElements.length === 0) {
                            productElements = document.querySelectorAll('.s-item');
                        }
                        
                        productElements.forEach((item, index) => {
                            try {
                                // Skip sponsored
                                if (item.innerText && item.innerText.includes('SPONSORED')) return;
                                
                                // Get link
                                const link = item.querySelector('a[href*="/itm/"]');
                                if (!link) return;
                                
                                const href = link.href;
                                const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                                if (!itemMatch) return;
                                
                                // Get title (multiple selectors)
                                let title = '';
                                const titleSelectors = [
                                    'h3.s-item__title',
                                    'h3',
                                    '.s-item__title',
                                    '[role="heading"]'
                                ];
                                
                                for (let sel of titleSelectors) {
                                    const elem = item.querySelector(sel);
                                    if (elem && elem.innerText) {
                                        title = elem.innerText.trim();
                                        break;
                                    }
                                }
                                
                                if (!title || title === 'Shop on eBay' || title === 'New Listing') return;
                                
                                // Get price
                                const priceElem = item.querySelector('.s-item__price');
                                const price = priceElem ? priceElem.innerText.trim() : '';
                                
                                // Get image (with size modification from Scrapy repo)
                                let image = '';
                                const imgElem = item.querySelector('img, .s-item__image-img');
                                if (imgElem) {
                                    image = imgElem.src || imgElem.dataset.src || '';
                                    // Replace with larger image
                                    if (image.includes('s-l64')) {
                                        image = image.replace('s-l64', 's-l500');
                                    } else if (image.includes('s-l140')) {
                                        image = image.replace('s-l140', 's-l500');
                                    }
                                }
                                
                                // Get condition
                                const condElem = item.querySelector('.SECONDARY_INFO');
                                const condition = condElem ? condElem.innerText.trim() : '';
                                
                                // Get seller info (from Scrapy repo)
                                const sellerElem = item.querySelector('.s-item__etrs-text');
                                const sellerLevel = sellerElem ? sellerElem.innerText.trim() : '';
                                
                                // Get location
                                const locElem = item.querySelector('.s-item__location');
                                const location = locElem ? locElem.innerText.trim() : '';
                                
                                items.push({
                                    item_number: itemMatch[1],
                                    title: title,
                                    price: price,
                                    image: image,
                                    condition: condition,
                                    seller_level: sellerLevel,
                                    location: location,
                                    url: href
                                });
                            } catch (e) {}
                        });
                        
                        return items;
                    }''')
                    
                    print(f"📦 Found {len(products)} products on page")
                    
                    # Process new products only (duplicate check from Scrapy repo)
                    new_products = []
                    for p in products:
                        if p['item_number'] not in self.seen_items:
                            self.seen_items.add(p['item_number'])
                            
                            product = {
                                'Ebay_Item_Number': p['item_number'],
                                'Title': p['title'],
                                'Price': p['price'],
                                'Condition': p['condition'],
                                'Seller_Level': p['seller_level'],
                                'Location': p['location'],
                                'Image_URL': p['image'],
                                'URL': p['url'],
                                'EAN': '',
                                'UPC': '',
                                'Description': '',
                                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            }
                            new_products.append(product)
                    
                    print(f"✅ {len(new_products)} new products (skipped {len(products)-len(new_products)} duplicates)")
                    
                    # Extract details for a sample (limit to avoid detection)
                    if (extract_ean or extract_description) and new_products:
                        sample_size = min(5, len(new_products))
                        print(f"🔍 Extracting details from {sample_size} products...")
                        
                        for i, product in enumerate(new_products[:sample_size], 1):
                            print(f"   [{i}/{sample_size}] {product['Title'][:40]}...")
                            
                            try:
                                detail_page = await context.new_page()
                                await detail_page.wait_for_timeout(random.randint(2000, 3000))
                                
                                await detail_page.goto(product['URL'], wait_until='networkidle', timeout=20000)
                                await detail_page.wait_for_timeout(random.randint(2000, 4000))
                                
                                # Extract details
                                details = await detail_page.evaluate('''() => {
                                    const result = {};
                                    
                                    // Look for EAN/UPC (from Scrapy repo logic)
                                    const upcElem = document.querySelector('h2[itemprop="gtin13"]');
                                    if (upcElem) result.upc = upcElem.innerText;
                                    
                                    // Look for EAN in item specifics
                                    const specifics = document.querySelectorAll('.ux-layout-section__row, tr');
                                    for (let row of specifics) {
                                        const text = row.innerText || '';
                                        if (text.includes('EAN')) {
                                            const match = text.match(/\\d{13}/);
                                            if (match) result.ean = match[0];
                                        }
                                        if (text.includes('UPC')) {
                                            const match = text.match(/\\d{12}/);
                                            if (match) result.upc = match[0];
                                        }
                                    }
                                    
                                    // Get description
                                    const descElem = document.querySelector('.vim-description-content, [data-testid="item-description"]');
                                    if (descElem) {
                                        result.description = descElem.innerText.substring(0, 1000);
                                    }
                                    
                                    return result;
                                }''')
                                
                                if details.get('ean'):
                                    product['EAN'] = details['ean']
                                    print(f"      ✅ EAN: {details['ean']}")
                                
                                if details.get('upc'):
                                    product['UPC'] = details['upc']
                                    print(f"      ✅ UPC: {details['upc']}")
                                
                                if details.get('description'):
                                    product['Description'] = details['description']
                                    print(f"      ✅ Desc: {len(details['description'])} chars")
                                
                                await detail_page.close()
                                
                            except Exception as e:
                                print(f"      ❌ Error: {str(e)[:50]}")
                            
                            await asyncio.sleep(random.uniform(2, 4))
                    
                    all_products.extend(new_products)
                    self.products_scraped += len(new_products)
                    
                    # Save checkpoint every 3 pages
                    if page_num % 3 == 0:
                        self.save_checkpoint(page_num)
                        
                        # Save data
                        df = pd.DataFrame(all_products)
                        filename = os.path.join(self.data_dir, f'ebay_page_{page_num}.xlsx')
                        df.to_excel(filename, index=False)
                        print(f"💾 Saved to {filename}")
                    
                    if len(products) == 0:
                        print("📭 No more products")
                        break
                    
                except Exception as e:
                    print(f"❌ Error on page {page_num}: {str(e)}")
                
                # Random delay between pages
                if page_num < start_page + max_pages:
                    delay = random.randint(5000, 8000)
                    print(f"⏳ Waiting {delay/1000}s...")
                    await page.wait_for_timeout(delay)
            
            await browser.close()
        
        # Final save
        if all_products:
            df = pd.DataFrame(all_products)
            final_file = f'ebay_final_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            df.to_excel(final_file, index=False)
            print(f"\n📁 Final results: {final_file}")
            
            # Stats
            ean_count = sum(1 for p in all_products if p.get('EAN'))
            upc_count = sum(1 for p in all_products if p.get('UPC'))
            desc_count = sum(1 for p in all_products if p.get('Description'))
            
            print(f"\n📊 Results:")
            print(f"   Total: {len(all_products)} products")
            print(f"   With EAN: {ean_count}")
            print(f"   With UPC: {upc_count}")
            print(f"   With Description: {desc_count}")
        
        return all_products

# Run the enhanced scraper
if __name__ == "__main__":
    async def main():
        scraper = EnhancedEbayScraper()
        
        # Your search URL
        search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
        
        # Note: 740,000 results / 200 per page = 3,700 pages
        # At 10 seconds per page = 10 hours of scraping
        
        products = await scraper.scrape_ebay_enhanced(
            search_url,
            max_pages=5,  # Test with 5 pages = 1000 products
            extract_ean=True,
            extract_description=True,
            items_per_page=200  # 200 items per page!
        )
        
        print(f"\n✅ Total scraped: {len(products)} products")
    
    print("\n🚀 ENHANCED eBay Scraper")
    print("📌 Using 200 items per page (3x faster!)")
    print("📌 Duplicate detection")
    print("📌 Better selectors from GitHub repos")
    print("📌 Checkpoint saving every 3 pages\n")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n⚠️ Interrupted - progress saved")
    except Exception as e:
        print(f"\n❌ Error: {e}")