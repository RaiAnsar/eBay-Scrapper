#!/usr/bin/env python3
"""
Production Web Interface for eBay Scraper
Features:
- Auto-detects total pages for each search
- Runs separate tasks for bulk URLs
- Optional EAN extraction from product pages
- Real-time progress updates
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional
import asyncio
from datetime import datetime
import pandas as pd
import os
import uuid
from pathlib import Path
import re

# Import our stealth scraper - bypasses detection and captures data
from stealth_scraper import StealthEbayScraper

# Create app
app = FastAPI(title="eBay Scraper Pro", version="3.0")

# Storage for tasks
tasks = {}
results_dir = Path("scraping_results")
results_dir.mkdir(exist_ok=True)

class ScrapeRequest(BaseModel):
    urls: List[str]  # Can be search URLs or keywords
    auto_detect_pages: bool = True
    max_pages_override: Optional[int] = None
    extract_ean: bool = False
    extract_description: bool = False
    
class TaskStatus(BaseModel):
    task_id: str
    status: str  # pending, running, completed, failed
    started_at: datetime
    completed_at: Optional[datetime] = None
    current_url: int = 0
    total_urls: int = 0
    current_page: int = 0
    total_pages: int = 0
    total_products: int = 0
    products_per_minute: float = 0
    error_message: Optional[str] = None
    results: List[dict] = []

async def scrape_single_url_task(task_id: str, url: str, url_index: int, total_urls: int, auto_detect: bool, max_pages_override: Optional[int], extract_ean: bool, extract_description: bool):
    """Background task to scrape a single URL"""
    
    # Update task status
    tasks[task_id]['current_url'] = url_index
    tasks[task_id]['status'] = 'running'
    tasks[task_id]['current_url_text'] = url[:50] + '...'
    
    try:
        scraper = StealthEbayScraper(max_workers=2)  # Stealth: 2 workers to avoid detection + capture EAN/desc
        
        # Process URL - detect if it's a keyword or actual URL
        if not url.startswith('http'):
            # It's keywords - build URL
            keywords = url.replace(' ', '+')
            search_url = f"https://www.ebay.co.uk/sch/i.html?_nkw={keywords}&_sacat=0"
        else:
            search_url = url
        
        # Auto-detect pages if enabled
        if auto_detect and not max_pages_override:
            # Quick page detection
            detected_pages = await detect_total_pages_quick(search_url)
            tasks[task_id]['total_pages'] = detected_pages
            print(f"Auto-detected {detected_pages} pages for: {search_url[:50]}...")
            max_pages = detected_pages
        else:
            max_pages = max_pages_override or 10
            tasks[task_id]['total_pages'] = max_pages
        
        # Update task with page info
        tasks[task_id]['current_page'] = 0
        
        # Run scraper with progress callback
        async def progress_callback(current_page, products_found):
            tasks[task_id]['current_page'] = current_page
            tasks[task_id]['products_on_current_page'] = products_found
        
        # Scrape the URL with turbo speed
        products = await scraper.scrape_url(
            search_url, 
            max_pages, 
            extract_ean=extract_ean,
            extract_description=extract_description,
            progress_callback=progress_callback
        )
        
        # Save results
        if products:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_{task_id}_url{url_index}_{timestamp}.xlsx"
            filepath = results_dir / filename
            
            df = pd.DataFrame(products)
            df.to_excel(filepath, index=False)
            
            # Store result
            result = {
                'url': search_url,
                'products_count': len(products),
                'excel_file': filename,
                'sample_products': products[:3]
            }
            
            tasks[task_id]['results'].append(result)
            tasks[task_id]['total_products'] += len(products)
        
    except Exception as e:
        tasks[task_id]['error_message'] = str(e)

async def scrape_multiple_urls_task(task_id: str, urls: List[str], auto_detect: bool, max_pages_override: Optional[int], extract_ean: bool, extract_description: bool):
    """Main background task to coordinate multiple URL scraping"""
    
    task = tasks[task_id]
    task['status'] = 'running'
    task['started_at'] = datetime.now()
    task['total_urls'] = len(urls)
    
    try:
        # Process each URL as a separate sub-task
        for i, url in enumerate(urls, 1):
            await scrape_single_url_task(
                task_id, url, i, len(urls),
                auto_detect, max_pages_override, extract_ean, extract_description
            )
            
            # Small delay between URLs
            if i < len(urls):
                await asyncio.sleep(2)
        
        # Calculate final stats
        elapsed = datetime.now() - task['started_at']
        minutes = elapsed.total_seconds() / 60
        
        task['products_per_minute'] = task['total_products'] / minutes if minutes > 0 else 0
        task['status'] = 'completed'
        task['completed_at'] = datetime.now()
        
        # Create combined Excel file if multiple URLs
        if len(urls) > 1 and task['results']:
            all_products = []
            for result in task['results']:
                # Read the individual Excel file
                filepath = results_dir / result['excel_file']
                if filepath.exists():
                    df = pd.read_excel(filepath)
                    df['Source_URL'] = result['url']
                    all_products.append(df)
            
            if all_products:
                combined_df = pd.concat(all_products, ignore_index=True)
                combined_filename = f"ebay_{task_id}_combined_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                combined_filepath = results_dir / combined_filename
                combined_df.to_excel(combined_filepath, index=False)
                task['combined_file'] = combined_filename
        
    except Exception as e:
        task['status'] = 'failed'
        task['error_message'] = str(e)
        task['completed_at'] = datetime.now()

async def detect_total_pages_quick(url: str) -> int:
    """Quick detection of total pages without full browser"""
    try:
        from playwright.async_api import async_playwright
        
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            
            await page.goto(url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1000)
            
            total_pages = await page.evaluate('''() => {
                // Look for result count
                const countElem = document.querySelector('.srp-controls__count-heading');
                if (countElem) {
                    const match = countElem.innerText.match(/([\\d,]+)\\+?\\s+results/i);
                    if (match) {
                        const total = parseInt(match[1].replace(/,/g, ''));
                        // eBay shows max 60 items per page, cap at 50 pages
                        return Math.min(Math.ceil(total / 60), 50);
                    }
                }
                
                // Look for pagination
                const paginationItems = document.querySelectorAll('.pagination__item');
                if (paginationItems.length > 0) {
                    const numbers = Array.from(paginationItems)
                        .map(el => parseInt(el.innerText))
                        .filter(n => !isNaN(n));
                    if (numbers.length > 0) {
                        return Math.min(Math.max(...numbers), 50);
                    }
                }
                
                return 10; // Default
            }''')
            
            await browser.close()
            return total_pages
            
    except:
        return 10  # Default if detection fails

@app.get("/", response_class=HTMLResponse)
async def home():
    """Serve the main page"""
    html = """
<!DOCTYPE html>
<html>
<head>
    <title>eBay Scraper Pro 3.0</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 48px;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .header p {
            font-size: 18px;
            opacity: 0.9;
        }
        .features {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
            color: white;
        }
        .feature {
            padding: 10px 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            font-size: 14px;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Courier New', monospace;
            min-height: 150px;
            resize: vertical;
        }
        textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        .checkbox-group {
            display: flex;
            gap: 30px;
            margin: 20px 0;
        }
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        input[type="number"] {
            width: 100px;
            padding: 8px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
        }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 14px 40px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        .status {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .status.running {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        .status.completed {
            background: #d1f2eb;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .status.failed {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .progress-container {
            margin: 20px 0;
        }
        .progress-bar {
            width: 100%;
            height: 30px;
            background: #e0e0e0;
            border-radius: 15px;
            overflow: hidden;
            position: relative;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 15px;
            transition: width 0.5s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
        .results-list {
            margin-top: 20px;
        }
        .result-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .result-info h4 {
            color: #333;
            margin-bottom: 5px;
        }
        .result-stats {
            color: #666;
            font-size: 14px;
        }
        .download-btn {
            background: #28a745;
            color: white;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.2s;
        }
        .download-btn:hover {
            background: #218838;
        }
        .loader {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .warning {
            background: #ffeaa7;
            color: #d63031;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛒 eBay Scraper Pro 3.0</h1>
            <p>Advanced scraping with auto page detection & EAN extraction</p>
        </div>
        
        <div class="features">
            <div class="feature">✨ Auto-detects total pages</div>
            <div class="feature">📊 EAN extraction available</div>
            <div class="feature">🚀 Bulk URL processing</div>
            <div class="feature">⚡ High-speed scraping</div>
        </div>
        
        <div class="card">
            <h2>Configure Scraping Tasks</h2>
            
            <div class="form-group">
                <label>Enter eBay URLs or Keywords (one per line):</label>
                <textarea id="urlInput" placeholder="Example:
https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray
https://www.ebay.co.uk/sch/i.html?_nkw=playstation+5
xbox series x
nintendo switch"></textarea>
            </div>
            
            <div class="checkbox-group">
                <div class="checkbox-item">
                    <input type="checkbox" id="autoDetect" checked>
                    <label for="autoDetect">Auto-detect total pages for each search</label>
                </div>
                <div class="checkbox-item">
                    <input type="checkbox" id="extractEan">
                    <label for="extractEan">Extract EAN numbers (slower)</label>
                </div>
                <div class="checkbox-item">
                    <input type="checkbox" id="extractDescription">
                    <label for="extractDescription">Extract descriptions (formatted text)</label>
                </div>
            </div>
            
            <div class="form-group" id="maxPagesGroup" style="display:none;">
                <label>Maximum pages to scrape (per URL):</label>
                <input type="number" id="maxPages" value="10" min="1" max="100">
            </div>
            
            <div class="warning" id="detailWarning" style="display:none;">
                ⚠️ Extracting EAN numbers and/or descriptions visits each product page individually. This significantly increases scraping time but provides complete product data.
            </div>
            
            <button class="btn" onclick="startScraping()" id="startBtn">🚀 Start Scraping</button>
            
            <div id="status" class="status" style="display:none;"></div>
        </div>
        
        <div class="card" id="progressCard" style="display:none;">
            <h2>Scraping Progress</h2>
            
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressBar" style="width: 0%">0%</div>
                </div>
            </div>
            
            <div class="stats-grid" id="statsGrid"></div>
            
            <div class="results-list" id="resultsList"></div>
        </div>
    </div>
    
    <script>
        let currentTaskId = null;
        let monitorInterval = null;
        
        // Toggle max pages input based on auto-detect
        document.getElementById('autoDetect').addEventListener('change', function() {
            document.getElementById('maxPagesGroup').style.display = this.checked ? 'none' : 'block';
        });
        
        // Show detail warning
        document.getElementById('extractEan').addEventListener('change', function() {
            updateDetailWarning();
        });
        
        document.getElementById('extractDescription').addEventListener('change', function() {
            updateDetailWarning();
        });
        
        function updateDetailWarning() {
            const eanChecked = document.getElementById('extractEan').checked;
            const descChecked = document.getElementById('extractDescription').checked;
            document.getElementById('detailWarning').style.display = 
                (eanChecked || descChecked) ? 'block' : 'none';
        }
        
        async function startScraping() {
            const urlInput = document.getElementById('urlInput').value.trim();
            if (!urlInput) {
                alert('Please enter at least one eBay URL or search keyword');
                return;
            }
            
            // Parse URLs/keywords
            const urls = urlInput.split('\\n').filter(line => line.trim());
            
            // Get options
            const autoDetect = document.getElementById('autoDetect').checked;
            const extractEan = document.getElementById('extractEan').checked;
            const extractDescription = document.getElementById('extractDescription').checked;
            const maxPages = autoDetect ? null : parseInt(document.getElementById('maxPages').value);
            
            // Disable button
            document.getElementById('startBtn').disabled = true;
            
            // Show status
            const statusDiv = document.getElementById('status');
            statusDiv.style.display = 'block';
            statusDiv.className = 'status running';
            statusDiv.innerHTML = `<span class="loader"></span> Starting ${urls.length} scraping task${urls.length > 1 ? 's' : ''}...`;
            
            // Show progress card
            document.getElementById('progressCard').style.display = 'block';
            
            // Start the scraping
            const response = await fetch('/scrape', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    urls: urls,
                    auto_detect_pages: autoDetect,
                    max_pages_override: maxPages,
                    extract_ean: extractEan,
                    extract_description: extractDescription
                })
            });
            
            const data = await response.json();
            currentTaskId = data.task_id;
            
            // Start monitoring
            monitorProgress();
        }
        
        async function monitorProgress() {
            if (!currentTaskId) return;
            
            const response = await fetch(`/status/${currentTaskId}`);
            const task = await response.json();
            
            updateUI(task);
            
            if (task.status === 'running' || task.status === 'pending') {
                monitorInterval = setTimeout(monitorProgress, 2000);
            } else {
                document.getElementById('startBtn').disabled = false;
            }
        }
        
        function updateUI(task) {
            // Update status
            const statusDiv = document.getElementById('status');
            statusDiv.className = `status ${task.status}`;
            
            if (task.status === 'running') {
                statusDiv.innerHTML = `<span class="loader"></span> Processing URL ${task.current_url}/${task.total_urls} - Page ${task.current_page}/${task.total_pages}...`;
            } else if (task.status === 'completed') {
                statusDiv.innerHTML = `✅ Scraping completed! ${task.total_products} products from ${task.total_urls} URL${task.total_urls > 1 ? 's' : ''}`;
            } else if (task.status === 'failed') {
                statusDiv.innerHTML = `❌ Error: ${task.error_message}`;
            }
            
            // Update progress bar
            let progress = 0;
            if (task.total_urls > 0) {
                const urlProgress = (task.current_url - 1) / task.total_urls;
                const pageProgress = task.total_pages > 0 ? task.current_page / task.total_pages / task.total_urls : 0;
                progress = (urlProgress + pageProgress) * 100;
            }
            
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressBar').innerText = Math.round(progress) + '%';
            
            // Update stats
            document.getElementById('statsGrid').innerHTML = `
                <div class="stat-card">
                    <div class="stat-value">${task.current_url}/${task.total_urls}</div>
                    <div class="stat-label">URLs Processed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.total_products}</div>
                    <div class="stat-label">Total Products</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.products_per_minute.toFixed(1)}</div>
                    <div class="stat-label">Products/Minute</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.current_page}/${task.total_pages}</div>
                    <div class="stat-label">Current Page</div>
                </div>
            `;
            
            // Update results list
            if (task.results && task.results.length > 0) {
                let resultsHtml = '<h3>Results:</h3>';
                task.results.forEach(result => {
                    resultsHtml += `
                        <div class="result-item">
                            <div class="result-info">
                                <h4>${result.url.substring(0, 60)}...</h4>
                                <div class="result-stats">
                                    📦 ${result.products_count} products scraped
                                </div>
                            </div>
                            <a href="/download/${result.excel_file}" class="download-btn">
                                📥 Download
                            </a>
                        </div>
                    `;
                });
                
                // Add combined file if available
                if (task.combined_file) {
                    resultsHtml += `
                        <div class="result-item" style="background: #d1f2eb;">
                            <div class="result-info">
                                <h4>🎯 Combined Results (All URLs)</h4>
                                <div class="result-stats">
                                    📦 ${task.total_products} total products
                                </div>
                            </div>
                            <a href="/download/${task.combined_file}" class="download-btn" style="background: #007bff;">
                                📥 Download All
                            </a>
                        </div>
                    `;
                }
                
                document.getElementById('resultsList').innerHTML = resultsHtml;
            }
        }
    </script>
</body>
</html>
"""
    return html

@app.post("/scrape")
async def create_scrape_task(request: ScrapeRequest, background_tasks: BackgroundTasks):
    """Create a new scraping task"""
    
    # Create task
    task_id = str(uuid.uuid4())[:8]
    tasks[task_id] = {
        'task_id': task_id,
        'status': 'pending',
        'started_at': datetime.now(),
        'completed_at': None,
        'current_url': 0,
        'total_urls': len(request.urls),
        'current_page': 0,
        'total_pages': 0,
        'total_products': 0,
        'products_per_minute': 0,
        'error_message': None,
        'results': []
    }
    
    # Start background task
    background_tasks.add_task(
        scrape_multiple_urls_task,
        task_id,
        request.urls,
        request.auto_detect_pages,
        request.max_pages_override,
        request.extract_ean,
        request.extract_description
    )
    
    return {"task_id": task_id, "message": f"Started processing {len(request.urls)} URL(s)"}

@app.get("/status/{task_id}")
async def get_task_status(task_id: str):
    """Get status of a scraping task"""
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return tasks[task_id]

@app.get("/download/{filename}")
async def download_file(filename: str):
    """Download Excel file"""
    filepath = results_dir / filename
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=filepath,
        filename=filename,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("🚀 eBay Scraper Pro 3.0 - Production Interface")
    print("="*60)
    print("✅ Server starting at http://localhost:8003")
    print("📊 Features:")
    print("   • Auto-detects total pages for each search")
    print("   • Processes multiple URLs as separate tasks")
    print("   • Optional EAN extraction from product pages")
    print("   • Real-time progress tracking")
    print("="*60 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8003)