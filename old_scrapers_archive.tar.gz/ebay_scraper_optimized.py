#!/usr/bin/env python3
"""
Optimized eBay Scraper - Lightweight & Efficient
Features:
- Real eBay scraping with proper pagination
- Efficient resource management (CPU/RAM)
- EAN and description extraction
- Configurable rate limiting
- VPS-optimized deployment
"""

import asyncio
import aiohttp
import pandas as pd
from bs4 import BeautifulSoup
import re
import time
import json
import os
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import logging
from datetime import datetime
import random
import gc
import resource
from contextlib import asynccontextmanager

# Configure logging for production
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ebay_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ResourceManager:
    """Manage system resources efficiently"""
    
    @staticmethod
    def set_limits():
        """Set conservative resource limits for VPS"""
        try:
            # Limit memory to 1GB for VPS
            resource.setrlimit(resource.RLIMIT_AS, (1024*1024*1024, 1024*1024*1024))
        except:
            pass  # Skip on systems that don't support this
    
    @staticmethod
    def cleanup():
        """Force garbage collection"""
        gc.collect()

class RateLimiter:
    """Intelligent rate limiting to prevent blocking"""
    
    def __init__(self, requests_per_second: float = 2.0):
        self.min_interval = 1.0 / requests_per_second
        self.last_request = 0
    
    async def wait(self):
        """Wait appropriate time between requests"""
        now = time.time()
        time_since_last = now - self.last_request
        if time_since_last < self.min_interval:
            await asyncio.sleep(self.min_interval - time_since_last)
        self.last_request = time.time()

class EbayScraperOptimized:
    """Optimized eBay scraper with resource management"""
    
    def __init__(self, 
                 max_concurrent: int = 5,
                 requests_per_second: float = 2.0,
                 max_pages: int = None,  # No limit by default
                 session_timeout: int = 30):
        self.max_concurrent = max_concurrent
        self.rate_limiter = RateLimiter(requests_per_second)
        self.max_pages = max_pages if max_pages else 99999  # Effectively unlimited
        self.session_timeout = session_timeout
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
    @asynccontextmanager
    async def get_session(self):
        """Create and manage aiohttp session with timeouts"""
        timeout = aiohttp.ClientTimeout(total=self.session_timeout)
        connector = aiohttp.TCPConnector(limit=self.max_concurrent, limit_per_host=self.max_concurrent)
        
        async with aiohttp.ClientSession(
            timeout=timeout,
            connector=connector,
            headers=self.headers
        ) as session:
            yield session
    
    async def get_total_pages(self, session: aiohttp.ClientSession, url: str) -> int:
        """Get total number of pages efficiently"""
        try:
            await self.rate_limiter.wait()
            async with session.get(url) as response:
                if response.status != 200:
                    return 10  # Default fallback
                
                content = await response.text()
                soup = BeautifulSoup(content, 'html.parser')
                
                # Method 1: Look for result count
                count_elem = soup.find('h1', class_=re.compile(r'srp-controls.*count.*'))
                if count_elem:
                    text = count_elem.get_text()
                    match = re.search(r'(\d+(?:,\d+)*)\+?\s*results?', text, re.IGNORECASE)
                    if match:
                        total_results = int(match.group(1).replace(',', ''))
                        # Calculate pages based on 60 items per page (eBay default)
                        # Or 200 if using _ipg=200 parameter
                        items_per_page = 200 if '_ipg=200' in url else 60
                        pages = (total_results + items_per_page - 1) // items_per_page
                        
                        # eBay caps visible results at around 10,000 items (~167 pages at 60/page)
                        # or ~50 pages at 200/page
                        max_ebay_pages = 50 if '_ipg=200' in url else 167
                        pages = min(pages, max_ebay_pages)
                        
                        if self.max_pages:
                            pages = min(pages, self.max_pages)
                        
                        logger.info(f"Detected {total_results:,} total results = {pages} pages")
                        return pages
                
                # Method 2: Look for pagination
                pagination = soup.find('ol', class_='pagination__items')
                if pagination:
                    page_links = pagination.find_all('a')
                    if page_links:
                        last_page = 1
                        for link in page_links:
                            text = link.get_text().strip()
                            if text.isdigit():
                                last_page = max(last_page, int(text))
                        # Don't limit by max_pages if we detected pagination
                        if self.max_pages:
                            return min(last_page, self.max_pages)
                        return last_page
                
                # If can't detect, check if there's a next page button
                next_button = soup.find('a', {'aria-label': re.compile(r'Go to next.*page', re.I)})
                if next_button:
                    # There are more pages, return a higher number to continue
                    logger.info("Next page button found, continuing pagination...")
                    return 50  # Continue for at least 50 pages
                
                return 10  # Default only if no pagination detected
                
        except Exception as e:
            logger.warning(f"Error detecting pages: {e}")
            # Return higher default to not stop prematurely
            return 50
    
    async def scrape_search_page(self, session: aiohttp.ClientSession, url: str, page: int) -> List[Dict]:
        """Scrape a single search page"""
        try:
            page_url = f"{url}&_pgn={page}"
            await self.rate_limiter.wait()
            
            async with session.get(page_url) as response:
                if response.status != 200:
                    return []
                
                content = await response.text()
                soup = BeautifulSoup(content, 'html.parser')
                
                products = []
                items = soup.find_all('div', class_=re.compile(r's-item__wrapper'))
                
                for item in items:
                    try:
                        product = await self.extract_product_basic(item)
                        if product:
                            products.append(product)
                    except Exception as e:
                        logger.debug(f"Error extracting product: {e}")
                        continue
                
                return products
                
        except Exception as e:
            logger.error(f"Error scraping page {page}: {e}")
            return []
    
    async def extract_product_basic(self, item) -> Optional[Dict]:
        """Extract basic product information"""
        try:
            # Title
            title_elem = item.find('h3', class_=re.compile(r's-item__title'))
            title = title_elem.get_text(strip=True) if title_elem else "N/A"
            
            # Skip sponsored items
            if 'sponsored' in title.lower():
                return None
            
            # Price
            price_elem = item.find('span', class_=re.compile(r's-item__price'))
            price = price_elem.get_text(strip=True) if price_elem else "N/A"
            
            # Clean price
            price_match = re.search(r'[\d.,]+', price)
            clean_price = price_match.group() if price_match else "0"
            
            # URL
            link_elem = item.find('a', class_=re.compile(r's-item__link'))
            url = link_elem.get('href', '') if link_elem else ""
            
            # Image
            img_elem = item.find('img', class_=re.compile(r's-item__image-img'))
            image_url = img_elem.get('src', '') if img_elem else ""
            
            # Item ID from URL
            ebay_id = ""
            if url:
                match = re.search(r'/itm/(\d+)', url)
                ebay_id = match.group(1) if match else ""
            
            return {
                'title': title,
                'price': clean_price,
                'currency': 'GBP' if '£' in price else 'USD',
                'ebay_id': ebay_id,
                'url': url,
                'image_url': image_url,
                'ean': None,  # Will be filled if extraction enabled
                'description': None,  # Will be filled if extraction enabled
                'scraped_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.debug(f"Error in basic extraction: {e}")
            return None
    
    async def extract_product_details(self, session: aiohttp.ClientSession, product: Dict) -> Dict:
        """Extract EAN and description from product page"""
        try:
            if not product['url']:
                return product
            
            await self.rate_limiter.wait()
            async with session.get(product['url']) as response:
                if response.status != 200:
                    return product
                
                content = await response.text()
                soup = BeautifulSoup(content, 'html.parser')
                
                # Extract EAN
                ean_patterns = [
                    r'EAN\s*:?\s*([\d-]+)',
                    r'ISBN\s*:?\s*([\d-]+)',
                    r'UPC\s*:?\s*([\d-]+)',
                    r'\b\d{13}\b'  # 13-digit EAN
                ]
                
                for pattern in ean_patterns:
                    matches = re.findall(pattern, str(soup), re.IGNORECASE)
                    if matches:
                        product['ean'] = matches[0].replace('-', '')
                        break
                
                # Extract description
                desc_elem = soup.find('div', id='viTabs_0_is')
                if desc_elem:
                    product['description'] = desc_elem.get_text(strip=True)[:1000]
                else:
                    # Try other description selectors
                    desc_selectors = [
                        '[data-testid="x-item-description-label"]',
                        '.item-description',
                        '.vi-desc-text'
                    ]
                    for selector in desc_selectors:
                        elem = soup.select_one(selector)
                        if elem:
                            product['description'] = elem.get_text(strip=True)[:1000]
                            break
                
                return product
                
        except Exception as e:
            logger.debug(f"Error extracting details: {e}")
            return product
    
    async def scrape_url_with_continuation(self, url: str, extract_details: bool = False, continue_on_empty: bool = True) -> Dict:
        """Scrape URL with intelligent continuation beyond visible pages"""
        all_products = []
        page = 1
        consecutive_empty = 0
        max_consecutive_empty = 3
        
        start_time = time.time()
        
        async with self.get_session() as session:
            # First detect initial pages
            detected_pages = await self.get_total_pages(session, url)
            logger.info(f"Initial detection: {detected_pages} pages")
            
            while True:
                page_url = f"{url}&_pgn={page}" if page > 1 else url
                
                try:
                    products = await self.scrape_search_page(session, url, page)
                    
                    if products:
                        all_products.extend(products)
                        consecutive_empty = 0
                        logger.info(f"Page {page}: Found {len(products)} products (Total: {len(all_products)})")
                    else:
                        consecutive_empty += 1
                        logger.info(f"Page {page}: No products found (consecutive empty: {consecutive_empty})")
                        
                        # If we've hit multiple empty pages, check if there's more
                        if consecutive_empty >= max_consecutive_empty:
                            if not continue_on_empty or page > detected_pages + 10:
                                logger.info("Stopping - reached empty page threshold")
                                break
                    
                    # Check if we should continue beyond detected pages
                    if page >= detected_pages:
                        # Try to detect if there are more pages
                        check_url = f"{url}&_pgn={page + 1}"
                        await self.rate_limiter.wait()
                        async with session.get(check_url) as response:
                            if response.status == 200:
                                content = await response.text()
                                soup = BeautifulSoup(content, 'html.parser')
                                items = soup.find_all('div', class_=re.compile(r's-item__wrapper'))
                                if items:
                                    logger.info(f"Found more pages beyond initial detection!")
                                    detected_pages = page + 10  # Continue for at least 10 more pages
                    
                    page += 1
                    
                    # Safety limit
                    if page > 500:  # eBay typically doesn't show more than this
                        logger.info("Reached maximum page limit")
                        break
                        
                    # Clean up periodically
                    if page % 10 == 0:
                        ResourceManager.cleanup()
                        
                except Exception as e:
                    logger.error(f"Error on page {page}: {e}")
                    consecutive_empty += 1
                    if consecutive_empty >= max_consecutive_empty:
                        break
                    page += 1
            
            # Extract details if needed
            if extract_details and all_products:
                logger.info(f"Extracting details for {len(all_products)} products...")
                # Use existing batch processing logic
                batch_size = 10
                for i in range(0, len(all_products), batch_size):
                    batch = all_products[i:i+batch_size]
                    detail_tasks = [self.extract_product_details(session, product) for product in batch]
                    batch_results = await asyncio.gather(*detail_tasks, return_exceptions=True)
                    
                    for j, result in enumerate(batch_results):
                        if isinstance(result, dict):
                            all_products[i+j] = result
                    
                    if (i + batch_size) % 100 == 0:
                        logger.info(f"Processed details for {min(i + batch_size, len(all_products))}/{len(all_products)} products")
                    
                    await asyncio.sleep(0.5)
            
            elapsed = time.time() - start_time
            return {
                'url': url,
                'products': all_products,
                'total_products': len(all_products),
                'pages_scraped': page - 1,
                'time_elapsed': elapsed
            }
    
    async def scrape_url(self, url: str, extract_details: bool = False) -> Dict:
        """Scrape a complete eBay search URL"""
        start_time = time.time()
        
        try:
            async with self.get_session() as session:
                # Get total pages
                total_pages = await self.get_total_pages(session, url)
                logger.info(f"Scraping {total_pages} pages from {url}")
                
                all_products = []
                
                # Process pages in batches
                semaphore = asyncio.Semaphore(self.max_concurrent)
                
                async def process_page(page):
                    async with semaphore:
                        return await self.scrape_search_page(session, url, page)
                
                # Process pages
                for batch_start in range(1, total_pages + 1, self.max_concurrent):
                    batch_end = min(batch_start + self.max_concurrent, total_pages + 1)
                    tasks = [process_page(p) for p in range(batch_start, batch_end)]
                    
                    batch_results = await asyncio.gather(*tasks, return_exceptions=True)
                    
                    for result in batch_results:
                        if isinstance(result, list):
                            all_products.extend(result)
                    
                    # Cleanup between batches
                    ResourceManager.cleanup()
                    
                    # Progress logging
                    if batch_start % 10 == 0:
                        logger.info(f"Processed {batch_start}/{total_pages} pages, {len(all_products)} products found")
                
                # Extract details if requested
                if extract_details and all_products:
                    logger.info(f"Extracting product details for {len(all_products)} products...")
                    
                    # Process in smaller batches to avoid resource exhaustion
                    batch_size = 10
                    for i in range(0, len(all_products), batch_size):
                        batch = all_products[i:i+batch_size]
                        detail_tasks = [self.extract_product_details(session, product) for product in batch]
                        
                        batch_results = await asyncio.gather(*detail_tasks, return_exceptions=True)
                        
                        # Update products in place
                        for j, result in enumerate(batch_results):
                            if isinstance(result, dict):
                                all_products[i+j] = result
                        
                        # Progress update
                        if (i + batch_size) % 100 == 0:
                            logger.info(f"Processed details for {min(i + batch_size, len(all_products))}/{len(all_products)} products")
                        
                        # Small delay between batches to prevent overload
                        await asyncio.sleep(0.5)
                
                # Final cleanup
                ResourceManager.cleanup()
                
                elapsed = time.time() - start_time
                logger.info(f"Scraped {len(all_products)} products in {elapsed:.2f}s")
                
                return {
                    'url': url,
                    'products': all_products,
                    'total_products': len(all_products),
                    'pages_scraped': total_pages,
                    'time_elapsed': elapsed
                }
                
        except Exception as e:
            logger.error(f"Error scraping URL {url}: {e}")
            return {
                'url': url,
                'products': [],
                'total_products': 0,
                'pages_scraped': 0,
                'time_elapsed': time.time() - start_time,
                'error': str(e)
            }

    async def scrape_large_dataset(self, base_search: str, use_segmentation: bool = True) -> Dict:
        """Scrape large datasets (700K+ products) using segmentation strategies"""
        all_products = []
        segments_processed = []
        
        if not use_segmentation:
            # Just try to get as many as possible from single search
            return await self.scrape_url_with_continuation(f"https://www.ebay.co.uk/sch/i.html?_nkw={base_search.replace(' ', '+')}&_ipg=200", extract_details=False)
        
        # Strategy 1: Use price ranges to segment the search
        price_ranges = [
            (0, 5), (5, 10), (10, 15), (15, 20), (20, 30),
            (30, 50), (50, 75), (75, 100), (100, 150), (150, 200),
            (200, 300), (300, 500), (500, 1000), (1000, 99999)
        ]
        
        logger.info(f"Starting segmented scraping for '{base_search}' with {len(price_ranges)} price segments")
        
        async with self.get_session() as session:
            for min_price, max_price in price_ranges:
                segment_url = f"https://www.ebay.co.uk/sch/i.html?_nkw={base_search.replace(' ', '+')}&_udlo={min_price}&_udhi={max_price}&_ipg=200"
                
                logger.info(f"Scraping segment: £{min_price}-£{max_price}")
                
                try:
                    # Get products for this segment
                    segment_result = await self.scrape_url_with_continuation(segment_url, extract_details=False, continue_on_empty=False)
                    
                    segment_products = segment_result.get('products', [])
                    if segment_products:
                        # Deduplicate by eBay ID
                        existing_ids = {p.get('ebay_id') for p in all_products if p.get('ebay_id')}
                        new_products = [p for p in segment_products if p.get('ebay_id') and p['ebay_id'] not in existing_ids]
                        all_products.extend(new_products)
                        
                        logger.info(f"Segment £{min_price}-£{max_price}: Found {len(segment_products)} products ({len(new_products)} new), Total: {len(all_products)}")
                        
                        segments_processed.append({
                            'range': f"£{min_price}-£{max_price}",
                            'products_found': len(segment_products),
                            'new_products': len(new_products)
                        })
                    
                    # Clean up between segments
                    ResourceManager.cleanup()
                    
                except Exception as e:
                    logger.error(f"Error in segment £{min_price}-£{max_price}: {e}")
                    continue
                
                # If we've reached a lot of products, consider stopping
                if len(all_products) >= 100000:
                    logger.info(f"Reached {len(all_products)} products, stopping segmentation")
                    break
        
        return {
            'search_term': base_search,
            'products': all_products,
            'total_products': len(all_products),
            'segments_processed': segments_processed,
            'strategy': 'price_segmentation'
        }

class ScrapingOrchestrator:
    """Manage scraping jobs with progress tracking"""
    
    def __init__(self):
        self.jobs = {}
        self.results_dir = Path("scraping_results")
        self.results_dir.mkdir(exist_ok=True)
    
    async def start_job(self, urls: List[str], extract_details: bool = False, max_pages: Optional[int] = None,
                       use_continuation: bool = True, use_segmentation: bool = False) -> str:
        """Start a new scraping job"""
        job_id = f"job_{int(time.time())}"
        
        self.jobs[job_id] = {
            'status': 'running',
            'started_at': datetime.now().isoformat(),
            'urls': urls,
            'extract_details': extract_details,
            'max_pages': max_pages,
            'use_continuation': use_continuation,
            'use_segmentation': use_segmentation,
            'progress': 0,
            'results': []
        }
        
        # Start scraping in background
        asyncio.create_task(self._run_job(job_id))
        
        return job_id
    
    async def _run_job(self, job_id: str):
        """Run the actual scraping job"""
        try:
            job = self.jobs[job_id]
            scraper = EbayScraperOptimized(max_pages=job.get('max_pages'))
            
            results = []
            for i, url in enumerate(job['urls']):
                job['current_url'] = url
                job['progress'] = (i / len(job['urls'])) * 100
                
                # Check if this is a large dataset search
                if job.get('use_segmentation') and 'blu ray' in url.lower():
                    # Extract search term from URL
                    import urllib.parse
                    parsed = urllib.parse.urlparse(url)
                    params = urllib.parse.parse_qs(parsed.query)
                    search_term = params.get('_nkw', ['blu ray'])[0]
                    
                    result = await scraper.scrape_large_dataset(search_term, use_segmentation=True)
                elif job.get('use_continuation', True):
                    result = await scraper.scrape_url_with_continuation(url, job['extract_details'])
                else:
                    result = await scraper.scrape_url(url, job['extract_details'])
                    
                results.append(result)
                
                # Save intermediate results
                self._save_results(job_id, results)
            
            job['status'] = 'completed'
            job['completed_at'] = datetime.now().isoformat()
            job['results'] = results
            job['progress'] = 100
            
            # Final save
            self._save_results(job_id, results, final=True)
            
        except Exception as e:
            job['status'] = 'failed'
            job['error'] = str(e)
            job['completed_at'] = datetime.now().isoformat()
    
    def _save_results(self, job_id: str, results: List[Dict], final: bool = False):
        """Save results to Excel/JSON"""
        try:
            all_products = []
            for result in results:
                for product in result['products']:
                    product['source_url'] = result['url']
                    all_products.append(product)
            
            if all_products:
                df = pd.DataFrame(all_products)
                
                # Excel file
                excel_file = self.results_dir / f"{job_id}_results.xlsx"
                df.to_excel(excel_file, index=False)
                
                # JSON file for API
                json_file = self.results_dir / f"{job_id}_results.json"
                with open(json_file, 'w') as f:
                    json.dump({
                        'job_id': job_id,
                        'results': results,
                        'total_products': len(all_products)
                    }, f, indent=2)
                
                if final:
                    logger.info(f"Results saved: {excel_file}")
                    
        except Exception as e:
            logger.error(f"Error saving results: {e}")
    
    def get_job_status(self, job_id: str) -> Dict:
        """Get current job status"""
        return self.jobs.get(job_id, {'status': 'not_found'})

# FastAPI app for web interface
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="eBay Scraper Optimized", version="4.0")

class ScrapeRequest(BaseModel):
    urls: List[str]
    extract_details: bool = False
    max_pages: Optional[int] = None  # No limit by default
    use_continuation: bool = True  # Continue beyond detected pages
    use_segmentation: bool = False  # Use price segmentation for large datasets

orchestrator = ScrapingOrchestrator()

@app.post("/scrape")
async def start_scraping(request: ScrapeRequest):
    """Start a new scraping job"""
    job_id = await orchestrator.start_job(
        request.urls,
        request.extract_details,
        request.max_pages,
        request.use_continuation,
        request.use_segmentation
    )
    return {"job_id": job_id, "settings": {
        "extract_details": request.extract_details,
        "max_pages": request.max_pages,
        "use_continuation": request.use_continuation,
        "use_segmentation": request.use_segmentation
    }}

@app.get("/status/{job_id}")
async def get_status(job_id: str):
    """Get job status"""
    status = orchestrator.get_job_status(job_id)
    if status['status'] == 'not_found':
        raise HTTPException(status_code=404, detail="Job not found")
    return status

@app.get("/results/{job_id}")
async def get_results(job_id: str):
    """Download results"""
    json_file = orchestrator.results_dir / f"{job_id}_results.json"
    if not json_file.exists():
        raise HTTPException(status_code=404, detail="Results not found")
    
    return FileResponse(json_file)

@app.get("/")
async def health_check():
    return {"status": "running", "version": "4.0"}

if __name__ == "__main__":
    import uvicorn
    
    # Set resource limits
    ResourceManager.set_limits()
    
    # Run server
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )