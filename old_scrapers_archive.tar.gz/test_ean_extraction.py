#!/usr/bin/env python3
"""
Test EAN extraction from eBay product pages
"""

import asyncio
from playwright.async_api import async_playwright
import re

async def test_ean_extraction():
    """Test extracting EAN from a specific product"""
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        )
        
        # First, get some product IDs from search
        page = await context.new_page()
        search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
        
        print("Finding products to test EAN extraction...")
        await page.goto(search_url, wait_until='domcontentloaded')
        await page.wait_for_timeout(2000)
        
        # Get first 3 product IDs
        product_ids = await page.evaluate('''() => {
            const ids = [];
            const links = document.querySelectorAll('a[href*="/itm/"]');
            for (let i = 0; i < Math.min(3, links.length); i++) {
                const match = links[i].href.match(/\\/itm\\/(\\d+)/);
                if (match) ids.push(match[1]);
            }
            return ids;
        }''')
        
        print(f"Found {len(product_ids)} products to test\n")
        
        # Test EAN extraction for each product
        for item_id in product_ids:
            product_url = f"https://www.ebay.co.uk/itm/{item_id}"
            print(f"Testing product: {item_id}")
            
            await page.goto(product_url, wait_until='domcontentloaded', timeout=15000)
            await page.wait_for_timeout(2000)
            
            # Get title
            title = await page.evaluate('''() => {
                const titleElem = document.querySelector('h1.it-ttl, .x-item-title__mainTitle');
                return titleElem ? titleElem.innerText.trim() : 'Unknown';
            }''')
            
            print(f"  Title: {title[:60]}...")
            
            # Extract EAN
            ean = await page.evaluate('''() => {
                // Method 1: Look in item specifics table
                const rows = document.querySelectorAll('.ux-layout-section__row, .u-flL.vi-acc-u-table tr');
                for (let row of rows) {
                    const text = row.innerText || '';
                    if (text.includes('EAN')) {
                        const match = text.match(/\\d{8,13}/);
                        if (match) return match[0];
                    }
                }
                
                // Method 2: Look for EAN in specs list
                const specs = document.querySelectorAll('.ux-layout-section-module .ux-textspans');
                for (let spec of specs) {
                    const label = spec.innerText || '';
                    if (label.includes('EAN')) {
                        const nextElem = spec.nextElementSibling;
                        if (nextElem) {
                            const value = nextElem.innerText;
                            const match = value.match(/\\d{8,13}/);
                            if (match) return match[0];
                        }
                    }
                }
                
                // Method 3: Look in About this item section
                const aboutSection = document.querySelector('[data-testid="ux-layout-section-about"]');
                if (aboutSection) {
                    const eanMatch = aboutSection.innerText.match(/EAN[:\\s]*(\\d{8,13})/i);
                    if (eanMatch) return eanMatch[1];
                }
                
                // Method 4: Check all visible text for EAN pattern
                const allText = document.body.innerText;
                const eanPatterns = [
                    /EAN[:\\s]*(\\d{13})/i,
                    /EAN[:\\s]*(\\d{8})/i,
                    /UPC[:\\s]*(\\d{12})/i,
                    /ISBN[:\\s]*(\\d{13})/i
                ];
                
                for (let pattern of eanPatterns) {
                    const match = allText.match(pattern);
                    if (match) return match[1];
                }
                
                return '';
            }''')
            
            if ean:
                print(f"  ✅ EAN found: {ean}")
            else:
                print(f"  ❌ No EAN found")
            
            # Also check for total pages on search results  
            if item_id == product_ids[0]:
                await page.goto(search_url, wait_until='domcontentloaded')
                await page.wait_for_timeout(2000)
                
                totalPages = await page.evaluate('''() => {
                    // Look for result count
                    const countElem = document.querySelector('.srp-controls__count-heading');
                    if (countElem) {
                        const match = countElem.innerText.match(/([\\d,]+)\\+?\\s+results/i);
                        if (match) {
                            const total = parseInt(match[1].replace(/,/g, ''));
                            return Math.min(Math.ceil(total / 60), 100);
                        }
                    }
                    return 10;
                }''')
                
                print(f"\n📄 Auto-detected pages available: {totalPages}")
            
            print()
        
        await browser.close()

if __name__ == "__main__":
    asyncio.run(test_ean_extraction())