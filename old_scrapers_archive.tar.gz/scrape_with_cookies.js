#!/usr/bin/env node

/**
 * INSTRUCTIONS:
 * 1. Open eBay in your browser
 * 2. Open DevTools (F12)
 * 3. Go to Application > Cookies
 * 4. Copy all eBay cookies
 * 5. Or use a browser extension like "EditThisCookie" to export cookies as JSON
 * 6. Save cookies to 'ebay_cookies.json' file
 */

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

puppeteer.use(StealthPlugin());

async function scrapeWithCookies() {
    const browser = await puppeteer.launch({
        headless: false,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-blink-features=AutomationControlled'
        ]
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });
    
    // Use same user agent as your browser
    await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');

    // First, go to eBay homepage to set domain
    console.log('Setting up domain...');
    await page.goto('https://www.ebay.co.uk', { waitUntil: 'networkidle2' });

    // Load cookies if they exist
    if (fs.existsSync('ebay_cookies.json')) {
        console.log('Loading cookies...');
        const cookies = JSON.parse(fs.readFileSync('ebay_cookies.json'));
        await page.setCookie(...cookies);
        console.log('Cookies loaded!');
    } else {
        console.log('No cookies file found. To get same results as your browser:');
        console.log('1. Export cookies from your browser');
        console.log('2. Save as ebay_cookies.json');
    }

    // Now navigate to the search URL
    const url = 'https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0&_from=R40&LH_PrefLoc=1&LH_ItemCondition=1000&LH_BIN=1&LH_FS=1&Format=DVD%7C4K%2520UHD%2520Blu%252Dray%7CBlu%252Dray%7CBlu%252Dray%25203D&rt=nc&Genre=Horror&_dcat=617&_ipg=200';
    
    console.log('\nNavigating to search page...');
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
    await new Promise(resolve => setTimeout(resolve, 3000));

    const results = await page.evaluate(() => {
        const heading = document.querySelector('h1.srp-controls__count-heading');
        const products = document.querySelectorAll('.srp-results li[id^="item"], li[data-viewport], .s-item');
        
        return {
            heading: heading ? heading.innerText : 'No heading',
            productCount: products.length,
            firstProduct: products[0] ? products[0].innerText.substring(0, 100) : 'No products'
        };
    });

    console.log('\nResults with cookies:');
    console.log('Heading:', results.heading);
    console.log('Products found:', results.productCount);
    console.log('First product:', results.firstProduct);

    await page.screenshot({ path: 'with_cookies.png' });
    console.log('\nScreenshot saved: with_cookies.png');

    console.log('\nBrowser will stay open for 30 seconds...');
    await new Promise(resolve => setTimeout(resolve, 30000));

    await browser.close();
}

// Instructions for exporting cookies
console.log('HOW TO EXPORT COOKIES FROM YOUR BROWSER:');
console.log('==========================================');
console.log('Option 1: Chrome DevTools');
console.log('1. Open eBay in Chrome');
console.log('2. Press F12 to open DevTools');
console.log('3. Go to Application tab > Cookies');
console.log('4. Select www.ebay.co.uk');
console.log('5. Right-click and copy all cookies');
console.log('');
console.log('Option 2: Use Cookie Editor Extension');
console.log('1. Install "Cookie-Editor" from Chrome Web Store');
console.log('2. Go to eBay.co.uk');
console.log('3. Click the extension icon');
console.log('4. Click Export > JSON');
console.log('5. Save as ebay_cookies.json in this directory');
console.log('==========================================\n');

scrapeWithCookies().catch(console.error);