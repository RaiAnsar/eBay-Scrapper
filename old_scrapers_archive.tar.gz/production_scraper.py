#!/usr/bin/env python3
"""
Production eBay Scraper - Optimized for 740,000+ products
Designed to replace Octoparse ($399/month)
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import json
import random
from typing import Dict, List, Set, Optional
import os
import time
from concurrent.futures import ThreadPoolExecutor
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ebay_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ProductionEbayScraper:
    def __init__(self, 
                 max_workers: int = 2,
                 extract_ean: bool = True,
                 extract_description: bool = False,  # Disable by default to save resources
                 batch_size: int = 1000):
        """
        Initialize production scraper
        
        Args:
            max_workers: Number of concurrent browser instances (2 recommended to avoid burning MacBook)
            extract_ean: Whether to extract EAN codes (slower but necessary)
            extract_description: Whether to extract descriptions (very slow, disable if not needed)
            batch_size: Save to file every N products
        """
        self.max_workers = max_workers
        self.extract_ean = extract_ean
        self.extract_description = extract_description
        self.batch_size = batch_size
        
        # Data storage
        self.products: List[Dict] = []
        self.seen_items: Set[str] = set()
        self.ean_cache: Dict[str, str] = {}
        self.failed_items: Set[str] = set()
        
        # File paths
        self.checkpoint_file = 'production_checkpoint.json'
        self.output_dir = 'ebay_data'
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Statistics
        self.stats = {
            'total_products': 0,
            'products_with_ean': 0,
            'products_with_description': 0,
            'pages_processed': 0,
            'start_time': None,
            'errors': []
        }
    
    def load_checkpoint(self) -> Dict:
        """Load previous scraping progress"""
        if os.path.exists(self.checkpoint_file):
            try:
                with open(self.checkpoint_file, 'r') as f:
                    data = json.load(f)
                    self.seen_items = set(data.get('seen_items', []))
                    self.ean_cache = data.get('ean_cache', {})
                    self.failed_items = set(data.get('failed_items', []))
                    self.stats = data.get('stats', self.stats)
                    logger.info(f"Loaded checkpoint: {len(self.seen_items)} seen items, {self.stats['pages_processed']} pages processed")
                    return data
            except Exception as e:
                logger.error(f"Failed to load checkpoint: {e}")
        return {'last_page': 0}
    
    def save_checkpoint(self, current_page: int):
        """Save current progress"""
        checkpoint_data = {
            'seen_items': list(self.seen_items),
            'ean_cache': self.ean_cache,
            'failed_items': list(self.failed_items),
            'stats': self.stats,
            'last_page': current_page,
            'timestamp': datetime.now().isoformat()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint_data, f, indent=2)
    
    def save_batch(self, products: List[Dict], batch_num: int):
        """Save a batch of products to file"""
        if not products:
            return
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{self.output_dir}/batch_{batch_num:05d}_{timestamp}"
        
        df = pd.DataFrame(products)
        
        # Save as CSV (faster and smaller)
        df.to_csv(f"{filename}.csv", index=False)
        
        # Also save as Excel if batch is complete
        if len(products) >= self.batch_size:
            df.to_excel(f"{filename}.xlsx", index=False, engine='openpyxl')
        
        logger.info(f"Saved batch {batch_num}: {len(products)} products")
    
    async def extract_ean_optimized(self, page, item_url: str, item_number: str) -> str:
        """Optimized EAN extraction - faster with timeout"""
        
        # Check cache
        if item_number in self.ean_cache:
            return self.ean_cache[item_number]
        
        # Skip if failed before
        if item_number in self.failed_items:
            return ''
        
        try:
            # Quick navigation with short timeout
            await page.goto(item_url, wait_until='domcontentloaded', timeout=10000)
            
            # Fast EAN extraction
            ean = await page.evaluate('''() => {
                // Quick check in item specifics only
                const labels = document.querySelectorAll('.ux-labels-values__labels');
                for(let label of labels) {
                    const text = label.textContent || '';
                    if(text.includes('EAN') || text.includes('UPC')) {
                        const value = label.nextElementSibling;
                        if(value) {
                            const ean = value.textContent.trim();
                            if(ean.match(/^[0-9]{8,13}$/)) {
                                return ean;
                            }
                        }
                    }
                }
                return '';
            }''')
            
            if ean:
                self.ean_cache[item_number] = ean
                self.stats['products_with_ean'] += 1
            else:
                self.failed_items.add(item_number)
            
            return ean
            
        except Exception:
            self.failed_items.add(item_number)
            return ''
    
    async def scrape_page(self, page, search_url: str, page_num: int) -> List[Dict]:
        """Scrape a single page of results"""
        
        products = []
        
        try:
            # Build URL with pagination
            url = f"{search_url}&_ipg=200"
            if page_num > 1:
                url += f"&_pgn={page_num}"
            
            logger.info(f"Scraping page {page_num}: {url}")
            
            # Navigate with retry
            for attempt in range(3):
                try:
                    await page.goto(url, wait_until='domcontentloaded', timeout=30000)
                    await page.wait_for_timeout(2000)
                    break
                except Exception as e:
                    if attempt == 2:
                        raise e
                    await asyncio.sleep(5)
            
            # Quick scroll to trigger lazy loading
            await page.evaluate('window.scrollTo(0, document.body.scrollHeight/2)')
            await page.wait_for_timeout(1000)
            
            # Extract all products at once
            raw_products = await page.evaluate('''() => {
                const items = [];
                const elements = document.querySelectorAll('li[data-viewport]');
                
                // Skip first 2 sponsored items
                for(let i = 2; i < elements.length; i++) {
                    const item = elements[i];
                    
                    const link = item.querySelector('a[href*="/itm/"]');
                    if(!link) continue;
                    
                    const href = link.href;
                    const match = href.match(/\\/itm\\/(\\d+)/);
                    if(!match) continue;
                    
                    // Get title
                    const titleElem = item.querySelector('div[role="heading"] span') ||
                                    item.querySelector('.s-item__title') ||
                                    item.querySelector('h3');
                    const title = titleElem ? (titleElem.innerText || '').trim() : '';
                    
                    if(!title || title === 'Shop on eBay') continue;
                    
                    // Get price
                    const priceElem = item.querySelector('.s-item__price');
                    const price = priceElem ? (priceElem.innerText || '').trim() : '';
                    
                    // Get condition
                    const condElem = item.querySelector('.SECONDARY_INFO');
                    const condition = condElem ? (condElem.innerText || '').trim() : '';
                    
                    // Get shipping
                    const shipElem = item.querySelector('.s-item__shipping');
                    const shipping = shipElem ? (shipElem.innerText || '').trim() : '';
                    
                    // Get seller
                    const sellerElem = item.querySelector('.s-item__seller-info');
                    const seller = sellerElem ? (sellerElem.innerText || '').trim() : '';
                    
                    // Get image
                    const imgElem = item.querySelector('img');
                    const image = imgElem ? (imgElem.src || imgElem.dataset.src || '') : '';
                    
                    items.push({
                        item_number: match[1],
                        title: title,
                        price: price,
                        condition: condition,
                        shipping: shipping,
                        seller: seller,
                        image: image,
                        url: href
                    });
                }
                
                return items;
            }''')
            
            # Process products
            for product in raw_products:
                if product['item_number'] in self.seen_items:
                    continue
                
                self.seen_items.add(product['item_number'])
                
                # Create product entry
                product_data = {
                    'Item_Number': product['item_number'],
                    'Title': product['title'],
                    'Price': product['price'],
                    'EAN': '',
                    'Description': '',
                    'Condition': product['condition'],
                    'Shipping': product['shipping'],
                    'Seller': product['seller'],
                    'Image_URL': product['image'],
                    'URL': product['url'],
                    'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'Page': page_num
                }
                
                products.append(product_data)
                self.stats['total_products'] += 1
            
            logger.info(f"Page {page_num}: Found {len(products)} new products")
            
        except Exception as e:
            logger.error(f"Error scraping page {page_num}: {e}")
            self.stats['errors'].append({
                'page': page_num,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            })
        
        return products
    
    async def extract_ean_batch(self, context, products: List[Dict], max_concurrent: int = 3):
        """Extract EAN codes for a batch of products using multiple tabs"""
        
        if not self.extract_ean or not products:
            return
        
        logger.info(f"Extracting EAN for {len(products)} products...")
        
        # Create multiple pages for concurrent extraction
        pages = []
        for _ in range(min(max_concurrent, len(products))):
            page = await context.new_page()
            pages.append(page)
        
        # Process products in parallel
        tasks = []
        for i, product in enumerate(products):
            if product['Item_Number'] in self.ean_cache:
                product['EAN'] = self.ean_cache[product['Item_Number']]
                continue
            
            page = pages[i % len(pages)]
            task = self.extract_ean_optimized(page, product['URL'], product['Item_Number'])
            tasks.append(task)
            
            # Process in batches to avoid overwhelming
            if len(tasks) >= max_concurrent:
                eans = await asyncio.gather(*tasks)
                for j, ean in enumerate(eans):
                    products[i - len(tasks) + j + 1]['EAN'] = ean
                tasks = []
        
        # Process remaining
        if tasks:
            eans = await asyncio.gather(*tasks)
            for j, ean in enumerate(eans):
                products[len(products) - len(tasks) + j]['EAN'] = ean
        
        # Close extra pages
        for page in pages:
            await page.close()
        
        ean_count = sum(1 for p in products if p['EAN'])
        logger.info(f"Extracted {ean_count} EAN codes from {len(products)} products")
    
    async def scrape_ebay_production(self, 
                                    search_term: str,
                                    total_pages: int = 3700,  # ~740,000 products at 200/page
                                    pages_per_session: int = 50):
        """
        Production scraping with resource management
        
        Args:
            search_term: Search query
            total_pages: Total pages to scrape (3700 for 740k products)
            pages_per_session: Pages before browser restart (prevents memory leaks)
        """
        
        logger.info("="*70)
        logger.info("🚀 PRODUCTION eBay SCRAPER")
        logger.info("="*70)
        logger.info(f"Search: {search_term}")
        logger.info(f"Target: {total_pages} pages (~{total_pages * 200:,} products)")
        logger.info(f"EAN extraction: {self.extract_ean}")
        logger.info(f"Workers: {self.max_workers}")
        logger.info("="*70)
        
        # Load checkpoint
        checkpoint = self.load_checkpoint()
        start_page = checkpoint.get('last_page', 0) + 1
        
        self.stats['start_time'] = time.time()
        
        # Process in sessions to prevent memory leaks
        for session_start in range(start_page, total_pages + 1, pages_per_session):
            session_end = min(session_start + pages_per_session, total_pages + 1)
            
            logger.info(f"\n🔄 Session: Pages {session_start} to {session_end - 1}")
            
            async with async_playwright() as p:
                browser = await p.chromium.launch(
                    headless=True,
                    args=[
                        '--disable-blink-features=AutomationControlled',
                        '--disable-dev-shm-usage',
                        '--no-sandbox'
                    ]
                )
                
                context = await browser.new_context(
                    viewport={'width': 1920, 'height': 1080},
                    user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                )
                
                # Anti-detection
                await context.add_init_script("""
                    Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                """)
                
                # Create main scraping page
                page = await context.new_page()
                
                # Establish session
                await page.goto('https://www.ebay.co.uk')
                await page.wait_for_timeout(2000)
                
                # Accept cookies
                try:
                    await page.click('#gdpr-banner-accept', timeout=2000)
                except:
                    pass
                
                # Build base search URL
                search_url = f"https://www.ebay.co.uk/sch/i.html?_nkw={search_term.replace(' ', '+')}"
                
                # Current batch
                batch_products = []
                batch_num = session_start // self.batch_size
                
                # Scrape pages in this session
                for page_num in range(session_start, session_end):
                    # Scrape page
                    products = await self.scrape_page(page, search_url, page_num)
                    
                    # Extract EAN codes if enabled (limit to reduce load)
                    if self.extract_ean and products:
                        # Only extract EAN for first 5 products per page to avoid burning resources
                        await self.extract_ean_batch(context, products[:5], max_concurrent=2)
                    
                    batch_products.extend(products)
                    
                    # Save batch if reached size
                    if len(batch_products) >= self.batch_size:
                        self.save_batch(batch_products, batch_num)
                        batch_products = []
                        batch_num += 1
                    
                    # Update stats
                    self.stats['pages_processed'] = page_num
                    
                    # Save checkpoint
                    self.save_checkpoint(page_num)
                    
                    # Progress report
                    if page_num % 10 == 0:
                        elapsed = time.time() - self.stats['start_time']
                        rate = self.stats['total_products'] / elapsed if elapsed > 0 else 0
                        eta = (total_pages - page_num) * 200 / rate if rate > 0 else 0
                        
                        logger.info(f"\n📊 Progress Report:")
                        logger.info(f"  Pages: {page_num}/{total_pages} ({page_num/total_pages*100:.1f}%)")
                        logger.info(f"  Products: {self.stats['total_products']:,}")
                        logger.info(f"  With EAN: {self.stats['products_with_ean']:,}")
                        logger.info(f"  Rate: {rate:.1f} products/sec")
                        logger.info(f"  ETA: {eta/3600:.1f} hours")
                    
                    # Delay between pages
                    await asyncio.sleep(random.uniform(2, 4))
                    
                    # Check if should stop (e.g., too many errors)
                    if len(self.stats['errors']) > 50:
                        logger.error("Too many errors, stopping...")
                        break
                
                # Save remaining batch
                if batch_products:
                    self.save_batch(batch_products, batch_num)
                
                await browser.close()
            
            # Break between sessions
            if session_end < total_pages:
                logger.info(f"Session complete. Taking a 30 second break...")
                await asyncio.sleep(30)
        
        # Final report
        elapsed = time.time() - self.stats['start_time']
        logger.info("\n" + "="*70)
        logger.info("📊 FINAL REPORT")
        logger.info("="*70)
        logger.info(f"Total products: {self.stats['total_products']:,}")
        logger.info(f"Products with EAN: {self.stats['products_with_ean']:,}")
        logger.info(f"Pages processed: {self.stats['pages_processed']}")
        logger.info(f"Time elapsed: {elapsed/3600:.2f} hours")
        logger.info(f"Average rate: {self.stats['total_products']/elapsed:.1f} products/sec")
        logger.info(f"Errors: {len(self.stats['errors'])}")
        logger.info("="*70)
        
        # Merge all batch files
        await self.merge_batches()
    
    async def merge_batches(self):
        """Merge all batch CSV files into final Excel file"""
        logger.info("\n📁 Merging batch files...")
        
        all_dfs = []
        for file in sorted(os.listdir(self.output_dir)):
            if file.endswith('.csv'):
                df = pd.read_csv(f"{self.output_dir}/{file}")
                all_dfs.append(df)
        
        if all_dfs:
            final_df = pd.concat(all_dfs, ignore_index=True)
            
            # Remove duplicates
            final_df = final_df.drop_duplicates(subset=['Item_Number'], keep='first')
            
            # Save final file
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            final_file = f"ebay_complete_{timestamp}.xlsx"
            
            # Save in chunks if too large
            if len(final_df) > 100000:
                # Split into multiple sheets
                with pd.ExcelWriter(final_file, engine='openpyxl') as writer:
                    for i in range(0, len(final_df), 100000):
                        sheet_name = f"Products_{i//100000 + 1}"
                        final_df.iloc[i:i+100000].to_excel(writer, sheet_name=sheet_name, index=False)
            else:
                final_df.to_excel(final_file, index=False)
            
            logger.info(f"✅ Final file saved: {final_file}")
            logger.info(f"✅ Total unique products: {len(final_df):,}")

async def main():
    """Main function"""
    scraper = ProductionEbayScraper(
        max_workers=2,  # Keep low to avoid burning MacBook
        extract_ean=True,  # Enable EAN extraction
        extract_description=False,  # Disable to save resources
        batch_size=1000  # Save every 1000 products
    )
    
    # Start production scraping
    await scraper.scrape_ebay_production(
        search_term="blu ray",
        total_pages=10,  # Start with 10 pages for testing (2000 products)
        pages_per_session=5  # Restart browser every 5 pages
    )

if __name__ == "__main__":
    print("\n🚀 PRODUCTION eBay SCRAPER")
    print("📌 Designed to scrape 740,000+ products efficiently")
    print("📌 Saves progress automatically - can resume if interrupted")
    print("📌 Resource-optimized to avoid burning your M4 Pro MacBook")
    print("\n⚠️ IMPORTANT:")
    print("  - This will take several hours for 740k products")
    print("  - Data is saved in batches to ebay_data/ directory")
    print("  - Can be stopped and resumed anytime")
    print("  - Monitor ebay_scraper.log for detailed progress\n")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n✅ Scraping stopped by user")
        print("📌 Progress saved. Run again to resume.")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        print(f"\n❌ Fatal error: {e}")
        print("📌 Check ebay_scraper.log for details")