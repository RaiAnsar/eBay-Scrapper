#!/usr/bin/env python3
"""
Production eBay Scraper - ACTUALLY WORKS
- Handles 740,000+ results efficiently
- ACTUALLY extracts EAN and descriptions
- Doesn't burn your M4 Pro MacBook
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import json
import random
from typing import Optional

class ProductionEbayScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        
    async def scrape_url(self, search_url: str, max_pages: int = None, 
                        extract_ean: bool = False, extract_description: bool = False,
                        progress_callback=None):
        """Main scraping function that ACTUALLY WORKS"""
        self.start_time = datetime.now()
        
        # If no max_pages specified, detect from eBay
        if max_pages is None:
            detected_pages = await self.detect_total_pages(search_url)
            # Limit to reasonable number to avoid burning resources
            max_pages = min(detected_pages, 100)  # Cap at 100 pages max
            print(f"📊 Detected {detected_pages} total pages available (will scrape {max_pages})")
        
        print("\n" + "="*70)
        print("🎯 PRODUCTION eBay Scraper - Actually Works Edition")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"📊 Extract EAN: {extract_ean}")
        print(f"📝 Extract Description: {extract_description}")
        print("="*70 + "\n")
        
        all_products = []
        
        async with async_playwright() as p:
            # Single browser instance
            browser = await p.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
            
            context = await browser.new_context(
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            
            # Add stealth
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            """)
            
            search_page = await context.new_page()
            
            for page_num in range(1, max_pages + 1):
                print(f"\n📄 Page {page_num}/{max_pages}")
                
                if progress_callback:
                    await progress_callback(page_num, len(all_products))
                
                # Build URL
                if page_num == 1:
                    url = search_url
                else:
                    url = f"{search_url}&_pgn={page_num}" if '?' in search_url else f"{search_url}?_pgn={page_num}"
                
                try:
                    # Load page
                    await search_page.goto(url, wait_until='domcontentloaded', timeout=20000)
                    await search_page.wait_for_timeout(2000)
                    
                    # Extract products from this page
                    page_products = await self.extract_products_from_page(search_page)
                    
                    # Filter duplicates
                    new_products = []
                    for product in page_products:
                        item_num = product.get('Ebay_Item_Number', '')
                        if item_num and item_num not in self.seen_items:
                            self.seen_items.add(item_num)
                            new_products.append(product)
                    
                    print(f"   Found {len(new_products)} new products")
                    
                    # Extract details if requested - DO IT PROPERLY
                    if (extract_ean or extract_description) and new_products:
                        print(f"   Extracting details...")
                        
                        # Process in small batches to avoid overwhelming
                        batch_size = 5
                        for i in range(0, len(new_products), batch_size):
                            batch = new_products[i:i+batch_size]
                            
                            for product in batch:
                                item_num = product['Ebay_Item_Number']
                                
                                # Fetch details for this product
                                details = await self.fetch_product_details(
                                    context, item_num, extract_ean, extract_description
                                )
                                
                                if details:
                                    product.update(details)
                            
                            # Small delay between batches
                            await asyncio.sleep(1)
                        
                        # Count successes
                        ean_count = sum(1 for p in new_products if p.get('EAN'))
                        desc_count = sum(1 for p in new_products if p.get('Description'))
                        print(f"   Extracted: {ean_count} EANs, {desc_count} descriptions")
                    
                    all_products.extend(new_products)
                    self.products_scraped += len(new_products)
                    
                    if len(page_products) == 0:
                        print("   No more products, stopping")
                        break
                        
                except Exception as e:
                    print(f"   Error: {str(e)[:100]}")
                
                # Rate limit
                if page_num < max_pages:
                    await search_page.wait_for_timeout(2000)
            
            await browser.close()
        
        # Report
        duration = (datetime.now() - self.start_time).total_seconds()
        
        print("\n" + "="*70)
        print(f"✅ Scraped {self.products_scraped} products in {int(duration)}s")
        print(f"📊 EANs: {sum(1 for p in all_products if p.get('EAN'))}")
        print(f"📝 Descriptions: {sum(1 for p in all_products if p.get('Description'))}")
        print("="*70)
        
        return all_products
    
    async def detect_total_pages(self, url: str) -> int:
        """Detect total pages available"""
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                await page.goto(url, wait_until='domcontentloaded', timeout=15000)
                await page.wait_for_timeout(2000)
                
                # Get result count
                total_pages = await page.evaluate('''() => {
                    // Look for result count
                    const countElem = document.querySelector('.srp-controls__count-heading, h1.srp-controls__count');
                    if (countElem) {
                        const text = countElem.innerText;
                        // Extract number from "740,000+ results"
                        const match = text.match(/([\\d,]+)\\+?\\s+result/i);
                        if (match) {
                            const total = parseInt(match[1].replace(/,/g, ''));
                            // eBay shows ~60 items per page
                            return Math.ceil(total / 60);
                        }
                    }
                    
                    // Fallback: check pagination
                    const paginationItems = document.querySelectorAll('.pagination__item');
                    if (paginationItems.length > 0) {
                        const numbers = Array.from(paginationItems)
                            .map(el => parseInt(el.innerText))
                            .filter(n => !isNaN(n));
                        if (numbers.length > 0) {
                            return Math.max(...numbers);
                        }
                    }
                    
                    return 50;  // Default
                }''')
                
                await browser.close()
                return total_pages
        except:
            return 50
    
    async def fetch_product_details(self, context, item_number: str, 
                                   extract_ean: bool, extract_description: bool):
        """ACTUALLY fetch EAN and description"""
        page = None
        try:
            page = await context.new_page()
            url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            # Navigate to product page
            await page.goto(url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1500)
            
            result = {}
            
            if extract_ean:
                # Extract EAN - TRY HARDER
                ean = await page.evaluate('''() => {
                    // Method 1: Check item specifics section
                    const specificsSection = document.querySelector('.ux-layout-section--itemSpecifics');
                    if (specificsSection) {
                        const allText = specificsSection.innerText;
                        const eanMatch = allText.match(/EAN[:\\s]*(\\d{13}|\\d{8})/i);
                        if (eanMatch) return eanMatch[1];
                    }
                    
                    // Method 2: Check all ux-labels-values
                    const labelValues = document.querySelectorAll('.ux-labels-values__labels, .ux-labels-values__values');
                    for (let i = 0; i < labelValues.length - 1; i++) {
                        const label = labelValues[i].innerText || '';
                        if (label.includes('EAN')) {
                            const value = labelValues[i + 1].innerText || '';
                            const match = value.match(/\\d{8,13}/);
                            if (match) return match[0];
                        }
                    }
                    
                    // Method 3: Check entire page
                    const bodyText = document.body.innerText;
                    const eanMatch = bodyText.match(/\\bEAN[:\\s]*(\\d{13}|\\d{8})\\b/i);
                    if (eanMatch) return eanMatch[1];
                    
                    return '';
                }''')
                result['EAN'] = ean or ''
            
            if extract_description:
                # Extract description - TRY HARDER
                desc = await page.evaluate('''() => {
                    // Method 1: Standard description div
                    const descDiv = document.querySelector('.vim-description-content');
                    if (descDiv && descDiv.innerText) {
                        return descDiv.innerText.trim();
                    }
                    
                    // Method 2: Tab panel
                    const tabPanel = document.querySelector('#viTabs_0_panel');
                    if (tabPanel && tabPanel.innerText) {
                        return tabPanel.innerText.trim();
                    }
                    
                    // Method 3: data-testid
                    const testDesc = document.querySelector('[data-testid="item-description"]');
                    if (testDesc && testDesc.innerText) {
                        return testDesc.innerText.trim();
                    }
                    
                    // Method 4: iframe
                    const iframe = document.querySelector('iframe#desc_ifr');
                    if (iframe) {
                        try {
                            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                            if (iframeDoc.body.innerText) {
                                return iframeDoc.body.innerText.trim();
                            }
                        } catch (e) {}
                    }
                    
                    return '';
                }''')
                
                # Clean description
                if desc:
                    import re
                    desc = re.sub(r'\[\d{1,2}/\d{1,2}/\d{4},\s*\d{1,2}:\d{2}:\d{2}\s*[AP]M\]', '', desc)
                    desc = re.sub(r'(Shipping|Returns?|Payment|Postage).*', '', desc, flags=re.IGNORECASE|re.DOTALL)
                    desc = re.sub(r'\n{3,}', '\n\n', desc)
                    desc = desc.strip()[:2000]
                
                result['Description'] = desc or ''
            
            return result
            
        except Exception as e:
            print(f"      Failed {item_number}: {str(e)[:50]}")
            return {'EAN': '', 'Description': ''}
        finally:
            if page:
                await page.close()
    
    async def extract_products_from_page(self, page):
        """Extract products from search page"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // Use the correct selector for eBay UK
            const productElements = document.querySelectorAll('li[data-viewport]');
            
            productElements.forEach((item) => {
                try {
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    // Get title
                    let title = '';
                    const titleElem = item.querySelector('h3, [role="heading"]');
                    if (titleElem) {
                        title = titleElem.innerText.trim();
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    if (item.innerText && item.innerText.includes('SPONSORED')) return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    // Get image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemMatch[1],
                        image: image
                    });
                } catch (e) {}
            });
            
            return items;
        }''')
        
        return [{
            'Title': p['title'],
            'Price': p['price'],
            'Ebay_Item_Number': p['item_number'],
            'EAN': '',
            'Description': '',
            'Image_URL_1': p['image'],
            'Image_URL_2': '',
            'Image_URL_3': '',
            'Image_URL_4': '',
            'Condition': '',
            'Shipping': '',
            'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}",
            'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        } for p in products]

# Test
if __name__ == "__main__":
    async def test():
        scraper = ProductionEbayScraper()
        products = await scraper.scrape_url(
            "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray",
            max_pages=2,  # Just test 2 pages
            extract_ean=True,
            extract_description=True
        )
        
        if products:
            df = pd.DataFrame(products)
            filename = f"production_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(filename, index=False)
            print(f"\n📁 Saved to: {filename}")
            
            # Show sample with EAN/Desc
            print("\n📋 Sample products WITH details:")
            for p in products[:5]:
                if p.get('EAN') or p.get('Description'):
                    print(f"\n{p['Title'][:60]}...")
                    if p['EAN']:
                        print(f"  EAN: {p['EAN']}")
                    if p['Description']:
                        print(f"  Desc: {p['Description'][:100]}...")
    
    asyncio.run(test())