#!/usr/bin/env python3
"""
Test Web Interface for eBay Scraper
Simplified version using requests instead of aiohttp
"""

import requests
import json
import time
import re
from urllib.parse import urlencode
from bs4 import BeautifulSoup
from typing import List, Dict, Optional
import logging
from pathlib import Path
from datetime import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor

# FastAPI imports
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ScrapeRequest(BaseModel):
    urls: List[str]
    extract_details: bool = False
    max_pages: int = 5

class EbayScraperSimple:
    def __init__(self, max_pages: int = 5):
        self.max_pages = max_pages
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
    
    def get_total_pages(self, url: str) -> int:
        """Get total number of pages from search results"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for pagination info
            pagination_selectors = [
                '.pagination__items .pagination__item:last-child a',
                '.pages a:last-child',
                '.pagination a:last-child',
                '[data-testid="pagination"] a:last-child'
            ]
            
            for selector in pagination_selectors:
                element = soup.select_one(selector)
                if element and element.get_text().strip().isdigit():
                    return min(int(element.get_text().strip()), self.max_pages)
            
            return 1
            
        except Exception as e:
            logger.error(f"Error getting total pages: {e}")
            return 1
    
    def extract_products(self, html: str) -> List[Dict]:
        """Extract product information from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        products = []
        
        # Multiple selectors for different eBay layouts
        product_selectors = [
            '.s-item',
            '.srp-results .s-item',
            '[data-testid="item-card"]',
            '.item',
            '.lvresult'
        ]
        
        items = []
        for selector in product_selectors:
            items = soup.select(selector)
            if items:
                logger.info(f"Found {len(items)} items using selector: {selector}")
                break
        
        for item in items:
            try:
                product = {}
                
                # Title
                title_selectors = [
                    '.s-item__title',
                    '.it-ttl a',
                    '[data-testid="item-title"]',
                    '.lvtitle a',
                    'h3 a'
                ]
                
                for selector in title_selectors:
                    title_elem = item.select_one(selector)
                    if title_elem:
                        title = title_elem.get_text().strip()
                        # Skip generic eBay promotional items
                        if title and title != "Shop on eBay" and len(title) > 10:
                            product['title'] = title
                            break
                
                # Price
                price_selectors = [
                    '.s-item__price',
                    '.notranslate',
                    '[data-testid="item-price"]',
                    '.lvprice .prc',
                    '.price'
                ]
                
                for selector in price_selectors:
                    price_elem = item.select_one(selector)
                    if price_elem:
                        price_text = price_elem.get_text().strip()
                        # Extract numeric price
                        price_match = re.search(r'[\d,]+\.?\d*', price_text.replace(',', ''))
                        if price_match:
                            product['price'] = price_match.group()
                        product['price_raw'] = price_text
                        break
                
                # URL
                url_selectors = [
                    '.s-item__link',
                    '.it-ttl a',
                    '[data-testid="item-title"] a',
                    '.lvtitle a',
                    'h3 a'
                ]
                
                for selector in url_selectors:
                    url_elem = item.select_one(selector)
                    if url_elem and url_elem.get('href'):
                        product['url'] = url_elem.get('href')
                        break
                
                # Image
                img_selectors = [
                    '.s-item__image img',
                    '.img img',
                    '[data-testid="item-image"] img',
                    '.lvpic img'
                ]
                
                for selector in img_selectors:
                    img_elem = item.select_one(selector)
                    if img_elem and img_elem.get('src'):
                        product['image'] = img_elem.get('src')
                        break
                
                # Only add if we have at least title and it's not generic
                if product.get('title'):
                    products.append(product)
                    
            except Exception as e:
                logger.error(f"Error extracting product: {e}")
                continue
        
        return products
    
    def scrape_page(self, url: str, page: int = 1) -> List[Dict]:
        """Scrape a single page"""
        try:
            # Add page parameter to URL
            if page > 1:
                separator = '&' if '?' in url else '?'
                url = f"{url}{separator}_pgn={page}"
            
            logger.info(f"Scraping page {page}: {url}")
            
            response = self.session.get(url, timeout=15)
            response.raise_for_status()
            
            products = self.extract_products(response.text)
            logger.info(f"Found {len(products)} products on page {page}")
            
            return products
            
        except Exception as e:
            logger.error(f"Error scraping page {page}: {e}")
            return []
    
    def scrape_url(self, url: str, extract_details: bool = False) -> Dict:
        """Scrape multiple pages from a URL"""
        start_time = time.time()
        all_products = []
        
        try:
            # Get total pages
            total_pages = self.get_total_pages(url)
            logger.info(f"Will scrape {total_pages} pages")
            
            # Scrape each page
            for page in range(1, total_pages + 1):
                products = self.scrape_page(url, page)
                all_products.extend(products)
                
                # Rate limiting
                if page < total_pages:
                    time.sleep(2)  # Increased delay
            
            elapsed = time.time() - start_time
            
            return {
                'url': url,
                'products': all_products,
                'total_products': len(all_products),
                'pages_scraped': total_pages,
                'time_elapsed': elapsed
            }
            
        except Exception as e:
            logger.error(f"Error scraping URL: {e}")
            return {
                'url': url,
                'products': [],
                'total_products': 0,
                'pages_scraped': 0,
                'time_elapsed': time.time() - start_time,
                'error': str(e)
            }

class ScrapingOrchestrator:
    """Manage scraping jobs with progress tracking"""
    
    def __init__(self):
        self.jobs = {}
        self.results_dir = Path("scraping_results")
        self.results_dir.mkdir(exist_ok=True)
        self.executor = ThreadPoolExecutor(max_workers=2)
    
    def start_job(self, urls: List[str], extract_details: bool = False, max_pages: int = 5) -> str:
        """Start a new scraping job"""
        job_id = f"job_{int(time.time())}"
        
        self.jobs[job_id] = {
            'status': 'running',
            'started_at': datetime.now().isoformat(),
            'urls': urls,
            'extract_details': extract_details,
            'max_pages': max_pages,
            'progress': 0,
            'results': []
        }
        
        # Start scraping in background
        self.executor.submit(self._run_job, job_id)
        
        return job_id
    
    def _run_job(self, job_id: str):
        """Run the actual scraping job"""
        try:
            job = self.jobs[job_id]
            scraper = EbayScraperSimple(max_pages=job['max_pages'])
            
            results = []
            for i, url in enumerate(job['urls']):
                job['current_url'] = url
                job['progress'] = (i / len(job['urls'])) * 100
                
                result = scraper.scrape_url(url, job['extract_details'])
                results.append(result)
                
                # Save intermediate results
                self._save_results(job_id, results)
            
            job['status'] = 'completed'
            job['completed_at'] = datetime.now().isoformat()
            job['results'] = results
            job['progress'] = 100
            
            # Final save
            self._save_results(job_id, results, final=True)
            
        except Exception as e:
            job['status'] = 'failed'
            job['error'] = str(e)
            job['completed_at'] = datetime.now().isoformat()
    
    def _save_results(self, job_id: str, results: List[Dict], final: bool = False):
        """Save results to JSON"""
        try:
            all_products = []
            for result in results:
                for product in result['products']:
                    product['source_url'] = result['url']
                    all_products.append(product)
            
            # JSON file for API
            json_file = self.results_dir / f"{job_id}_results.json"
            with open(json_file, 'w') as f:
                json.dump({
                    'job_id': job_id,
                    'results': results,
                    'total_products': len(all_products)
                }, f, indent=2)
            
            if final:
                logger.info(f"Results saved: {json_file}")
                
        except Exception as e:
            logger.error(f"Error saving results: {e}")
    
    def get_job_status(self, job_id: str) -> Dict:
        """Get current job status"""
        return self.jobs.get(job_id, {'status': 'not_found'})

# FastAPI app
app = FastAPI(title="eBay Scraper Test Interface", version="1.0")
orchestrator = ScrapingOrchestrator()

@app.post("/scrape")
async def start_scraping(request: ScrapeRequest):
    """Start a new scraping job"""
    job_id = orchestrator.start_job(
        request.urls,
        request.extract_details,
        request.max_pages
    )
    return {"job_id": job_id, "message": "Scraping job started"}

@app.get("/status/{job_id}")
async def get_status(job_id: str):
    """Get job status"""
    status = orchestrator.get_job_status(job_id)
    if status['status'] == 'not_found':
        raise HTTPException(status_code=404, detail="Job not found")
    return status

@app.get("/results/{job_id}")
async def get_results(job_id: str):
    """Download results"""
    json_file = orchestrator.results_dir / f"{job_id}_results.json"
    if not json_file.exists():
        raise HTTPException(status_code=404, detail="Results not found")
    
    return FileResponse(json_file)

@app.get("/")
async def health_check():
    return {
        "status": "running", 
        "version": "1.0",
        "message": "eBay Scraper Test Interface",
        "endpoints": {
            "POST /scrape": "Start scraping job",
            "GET /status/{job_id}": "Get job status",
            "GET /results/{job_id}": "Download results",
            "GET /": "Health check"
        }
    }

@app.get("/test")
async def test_scrape():
    """Quick test endpoint"""
    test_url = "https://www.ebay.com/sch/i.html?_from=R40&_trksid=p4432023.m570.l1313&_nkw=iphone+15+pro+max&_sacat=0"
    
    job_id = orchestrator.start_job([test_url], False, 2)
    
    return {
        "message": "Test scraping job started",
        "job_id": job_id,
        "test_url": test_url,
        "check_status": f"/status/{job_id}",
        "get_results": f"/results/{job_id}"
    }

if __name__ == "__main__":
    import uvicorn
    
    print("Starting eBay Scraper Test Interface...")
    print("Available endpoints:")
    print("  GET  /          - Health check")
    print("  GET  /test      - Quick test")
    print("  POST /scrape    - Start scraping job")
    print("  GET  /status/{job_id} - Get job status")
    print("  GET  /results/{job_id} - Download results")
    print("\nStarting server on http://localhost:8000")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )