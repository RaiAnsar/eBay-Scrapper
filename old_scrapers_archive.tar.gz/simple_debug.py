#!/usr/bin/env python3
import asyncio
from playwright.async_api import async_playwright

async def debug():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        await page.goto("https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray", wait_until='domcontentloaded')
        await page.wait_for_timeout(3000)
        
        # Just check for product links
        count = await page.evaluate('''() => {
            const links = document.querySelectorAll('a[href*="/itm/"]');
            console.log('Product links found:', links.length);
            
            // Try to find what contains these links
            if (links.length > 0) {
                const firstLink = links[0];
                let parent = firstLink.parentElement;
                while (parent && parent !== document.body) {
                    console.log('Parent:', parent.tagName, parent.className);
                    parent = parent.parentElement;
                }
            }
            
            // Check different selectors
            console.log('.s-item:', document.querySelectorAll('.s-item').length);
            console.log('li:', document.querySelectorAll('li').length);
            console.log('[data-viewport]:', document.querySelectorAll('[data-viewport]').length);
            
            return links.length;
        }''')
        
        print(f"Product links found: {count}")
        
        # Get page HTML snippet to see structure
        html = await page.evaluate('''() => {
            const elem = document.querySelector('a[href*="/itm/"]');
            if (elem) {
                let parent = elem.parentElement;
                while (parent && !parent.className.includes('item') && parent.children.length < 10) {
                    parent = parent.parentElement;
                }
                return parent ? parent.outerHTML.substring(0, 500) : 'No parent found';
            }
            return 'No product links found';
        }''')
        
        print(f"\nFirst product HTML structure:\n{html}")
        
        await browser.close()

asyncio.run(debug())