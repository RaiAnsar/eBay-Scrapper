#!/usr/bin/env python3
"""
Fixed eBay Scraper - Works with current eBay HTML structure
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from datetime import datetime
import re
import json

class FixedEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-GB,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Referer': 'https://www.ebay.co.uk/',
        })
        
        # Performance tracking
        self.start_time = None
        self.products_scraped = 0
        self.duplicates_found = 0
        self.seen_items = set()
    
    def scrape_search_url(self, search_url, max_pages=1):
        """
        Main function to scrape eBay search results
        """
        self.start_time = datetime.now()
        
        print("\n" + "="*70)
        print("🛒 Fixed eBay Scraper - Production Version")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        
        for page in range(1, max_pages + 1):
            print(f"\n📄 Page {page}/{max_pages}")
            print("-" * 40)
            
            # Construct page URL
            if page == 1:
                page_url = search_url
            else:
                # Add pagination parameter
                if '?' in search_url:
                    page_url = f"{search_url}&_pgn={page}"
                else:
                    page_url = f"{search_url}?_pgn={page}"
            
            # Scrape the page
            page_products = self.scrape_single_page(page_url)
            
            # Remove duplicates
            new_products = []
            for product in page_products:
                item_num = product.get('Ebay_Item_Number', '')
                if item_num and item_num not in self.seen_items:
                    self.seen_items.add(item_num)
                    new_products.append(product)
                    self.products_scraped += 1
                else:
                    self.duplicates_found += 1
            
            all_products.extend(new_products)
            
            print(f"✅ Found: {len(page_products)} items ({len(new_products)} new)")
            
            # Show progress
            self.show_progress()
            
            # Rate limiting between pages
            if page < max_pages:
                time.sleep(1.5)
        
        # Final report
        self.show_final_report(all_products)
        
        return all_products
    
    def scrape_single_page(self, url):
        """Scrape a single page of search results"""
        products = []
        
        try:
            response = self.session.get(url, timeout=15)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all product items using the correct selectors
            # Method 1: Try li elements with data-viewport
            items = soup.select('li[data-viewport]')
            
            if not items:
                # Method 2: Try li elements with id containing 'item'
                items = soup.select('li[id*="item"]')
            
            if not items:
                # Method 3: Fallback to s-item class (for some pages)
                items = soup.select('.s-item')
            
            print(f"   Found {len(items)} potential items on page")
            
            for item in items:
                # Skip sponsored items
                item_text = item.get_text()
                if 'SPONSORED' in item_text or 'Shop on eBay' in item_text:
                    continue
                
                # Skip variations
                if 'variation' in item_text.lower():
                    continue
                
                # Extract product data
                product = self.extract_product_from_item(item)
                
                if product and product.get('Ebay_Item_Number'):
                    products.append(product)
        
        except Exception as e:
            print(f"❌ Error scraping page: {e}")
        
        return products
    
    def extract_product_from_item(self, item):
        """Extract product data from a single item element"""
        try:
            # Get the main link - try multiple selectors
            link_elem = item.select_one('a[href*="/itm/"]')
            if not link_elem:
                link_elem = item.select_one('.s-item__link')
            if not link_elem:
                link_elem = item.find('a', href=re.compile(r'/itm/\d+'))
            
            if not link_elem:
                return None
            
            href = link_elem.get('href', '')
            
            # Extract item number from URL
            item_match = re.search(r'/itm/(\d+)', href)
            if not item_match:
                return None
            
            item_number = item_match.group(1)
            
            # Get title - try multiple selectors
            title_elem = item.select_one('h3')
            if not title_elem:
                title_elem = item.select_one('.s-item__title')
            if not title_elem:
                title_elem = item.select_one('span.vip')
            
            title = title_elem.get_text(strip=True) if title_elem else ""
            
            # Skip if it's not a real product
            if not title or 'Shop on eBay' in title or 'Results matching' in title:
                return None
            
            # Get price - try multiple selectors
            price_elem = item.select_one('.s-item__price')
            if not price_elem:
                price_elem = item.select_one('span.bold')
            if not price_elem:
                # Look for text containing £
                price_elem = item.find(string=re.compile(r'£[\d,]+'))
            
            price = ""
            if price_elem:
                if isinstance(price_elem, str):
                    price = price_elem.strip()
                else:
                    price = price_elem.get_text(strip=True)
            
            # Clean price
            price = re.sub(r'\s+to\s+.*', '', price)  # Remove range prices
            
            # Get main image - try multiple selectors
            img_elem = item.select_one('img[src*="thumbs"]')
            if not img_elem:
                img_elem = item.select_one('.s-item__image img')
            if not img_elem:
                img_elem = item.select_one('img')
            
            image_url = ""
            if img_elem:
                image_url = img_elem.get('src', '') or img_elem.get('data-src', '')
            
            # Get condition
            condition_elem = item.select_one('.SECONDARY_INFO')
            if not condition_elem:
                condition_elem = item.select_one('span.LIGHT_HIGHLIGHT')
            condition = condition_elem.get_text(strip=True) if condition_elem else ""
            
            # Get shipping info
            shipping_elem = item.select_one('.s-item__shipping')
            if not shipping_elem:
                shipping_elem = item.select_one('.fee')
            shipping = shipping_elem.get_text(strip=True) if shipping_elem else ""
            
            # Get seller info
            seller_elem = item.select_one('.s-item__seller-info-text')
            seller = seller_elem.get_text(strip=True) if seller_elem else ""
            
            # Get location
            location_elem = item.select_one('.s-item__location')
            location = location_elem.get_text(strip=True) if location_elem else ""
            
            return {
                'Title': title,
                'Price': price,
                'Ebay_Item_Number': item_number,
                'EAN': '',  # Would need to visit product page for this
                'Image_URL_1': image_url,
                'Image_URL_2': '',
                'Image_URL_3': '',
                'Image_URL_4': '',
                'Condition': condition,
                'Shipping': shipping,
                'Seller': seller,
                'Location': location,
                'URL': f"https://www.ebay.co.uk/itm/{item_number}",
                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            return None
    
    def show_progress(self):
        """Show real-time progress"""
        elapsed = datetime.now() - self.start_time
        rate = self.products_scraped / (elapsed.total_seconds() / 60) if elapsed.total_seconds() > 0 else 0
        
        print(f"⚡ Rate: {rate:.1f} products/min | 🎯 Unique: {len(self.seen_items)} | 🔄 Duplicates: {self.duplicates_found}")
    
    def show_final_report(self, products):
        """Show final scraping report"""
        elapsed = datetime.now() - self.start_time
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {len(products)}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"🔄 Duplicates removed: {self.duplicates_found}")
        print(f"⏱️  Total time: {str(elapsed).split('.')[0]}")
        print(f"⚡ Average rate: {len(products)/(elapsed.total_seconds()/60):.1f} products/minute")
        print("="*70 + "\n")
    
    def save_to_excel(self, products, filename=None):
        """Save products to Excel"""
        if not products:
            print("❌ No products to save")
            return None
        
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_results_{timestamp}.xlsx"
        
        df = pd.DataFrame(products)
        df.to_excel(filename, index=False)
        
        print(f"💾 Saved {len(products)} products to: {filename}")
        
        # Show sample
        print("\n📋 Sample results:")
        for i, product in enumerate(products[:3], 1):
            print(f"\n{i}. {product['Title'][:60]}...")
            print(f"   💰 {product['Price']}")
            print(f"   📦 {product['Condition']}")
            print(f"   🔢 Item: {product['Ebay_Item_Number']}")
        
        return filename


def main():
    """Demo the scraper"""
    scraper = FixedEbayScraper()
    
    # Your URL
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0&_from=R40&_trksid=m570.l1313"
    
    # Scrape 3 pages
    products = scraper.scrape_search_url(url, max_pages=3)
    
    # Save results
    if products:
        scraper.save_to_excel(products)
    else:
        print("❌ No products found. Please check the URL or try again.")


if __name__ == "__main__":
    main()