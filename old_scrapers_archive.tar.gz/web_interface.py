#!/usr/bin/env python3
"""
Web Interface for eBay Scraper
Simple web UI for managing scraping tasks
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException, UploadFile, File
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
import asyncio
import json
import os
from datetime import datetime
import pandas as pd
from ebay_scraper import eBayScraper, eBayProduct

app = FastAPI(title="eBay Scraper Dashboard")

# Store scraping tasks
tasks = {}
task_counter = 0

class ScrapeRequest(BaseModel):
    urls: Optional[List[str]] = None
    search_query: Optional[str] = None
    max_pages: int = 1
    use_playwright: bool = True
    output_format: str = "excel"  # excel, csv, json

class TaskStatus(BaseModel):
    task_id: int
    status: str
    progress: int
    total: int
    message: str
    created_at: str
    completed_at: Optional[str] = None
    download_link: Optional[str] = None

@app.get("/", response_class=HTMLResponse)
async def home():
    """Serve the main dashboard"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>eBay Scraper Dashboard</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                padding: 30px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            h1 {
                color: #333;
                margin-bottom: 10px;
                font-size: 2.5em;
            }
            .subtitle {
                color: #666;
                margin-bottom: 30px;
                font-size: 1.1em;
            }
            .tabs {
                display: flex;
                gap: 10px;
                margin-bottom: 30px;
                border-bottom: 2px solid #e0e0e0;
            }
            .tab {
                padding: 12px 24px;
                background: none;
                border: none;
                cursor: pointer;
                font-size: 16px;
                color: #666;
                transition: all 0.3s;
            }
            .tab.active {
                color: #667eea;
                border-bottom: 3px solid #667eea;
                margin-bottom: -2px;
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                color: #555;
                font-weight: 500;
            }
            input, textarea, select {
                width: 100%;
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            input:focus, textarea:focus, select:focus {
                outline: none;
                border-color: #667eea;
            }
            textarea {
                min-height: 120px;
                resize: vertical;
            }
            button {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                padding: 14px 28px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: transform 0.2s;
            }
            button:hover {
                transform: translateY(-2px);
            }
            button:disabled {
                opacity: 0.5;
                cursor: not-allowed;
            }
            .tasks-list {
                margin-top: 30px;
            }
            .task-item {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 15px;
                border: 2px solid #e0e0e0;
            }
            .task-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
            }
            .task-id {
                font-weight: 600;
                color: #667eea;
            }
            .status {
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: 500;
            }
            .status.pending { background: #fff3cd; color: #856404; }
            .status.running { background: #cfe2ff; color: #084298; }
            .status.completed { background: #d1e7dd; color: #0a3622; }
            .status.failed { background: #f8d7da; color: #842029; }
            .progress-bar {
                width: 100%;
                height: 8px;
                background: #e0e0e0;
                border-radius: 4px;
                overflow: hidden;
                margin: 10px 0;
            }
            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
                transition: width 0.3s;
            }
            .download-btn {
                background: #28a745;
                padding: 8px 16px;
                font-size: 14px;
            }
            .info-box {
                background: #e8f4ff;
                border: 2px solid #b8e0ff;
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 20px;
            }
            .info-box h3 {
                color: #0066cc;
                margin-bottom: 10px;
            }
            .info-box ul {
                margin-left: 20px;
                color: #555;
            }
            .checkbox-group {
                display: flex;
                align-items: center;
                gap: 10px;
                margin: 15px 0;
            }
            input[type="checkbox"] {
                width: auto;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🛒 eBay Scraper Dashboard</h1>
            <p class="subtitle">Professional eBay data extraction tool - Better than Octoparse, 90% cheaper!</p>
            
            <div class="info-box">
                <h3>✨ Features</h3>
                <ul>
                    <li>Extract complete product data: title, price, EAN, images, descriptions</li>
                    <li>Batch processing with search queries</li>
                    <li>Export to Excel, CSV, or JSON</li>
                    <li>Anti-detection mechanisms built-in</li>
                    <li>90% cost savings vs Octoparse ($30/mo vs $399/mo)</li>
                </ul>
            </div>
            
            <div class="tabs">
                <button class="tab active" onclick="showTab('url-scrape')">Scrape by URLs</button>
                <button class="tab" onclick="showTab('search-scrape')">Scrape by Search</button>
                <button class="tab" onclick="showTab('tasks')">Tasks History</button>
            </div>
            
            <div id="url-scrape" class="tab-content active">
                <form onsubmit="submitUrlScrape(event)">
                    <div class="form-group">
                        <label>eBay Product URLs (one per line)</label>
                        <textarea name="urls" placeholder="https://www.ebay.co.uk/itm/123456789
https://www.ebay.co.uk/itm/987654321" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Output Format</label>
                        <select name="format">
                            <option value="excel">Excel (.xlsx)</option>
                            <option value="csv">CSV</option>
                            <option value="json">JSON</option>
                        </select>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="playwright" name="playwright" checked>
                        <label for="playwright">Use advanced scraping (slower but more reliable)</label>
                    </div>
                    <button type="submit">Start Scraping</button>
                </form>
            </div>
            
            <div id="search-scrape" class="tab-content">
                <form onsubmit="submitSearchScrape(event)">
                    <div class="form-group">
                        <label>Search Query</label>
                        <input type="text" name="query" placeholder="e.g. blu ray musicmagpie" required>
                    </div>
                    <div class="form-group">
                        <label>Number of Pages</label>
                        <input type="number" name="pages" min="1" max="10" value="1">
                    </div>
                    <div class="form-group">
                        <label>Output Format</label>
                        <select name="format">
                            <option value="excel">Excel (.xlsx)</option>
                            <option value="csv">CSV</option>
                            <option value="json">JSON</option>
                        </select>
                    </div>
                    <button type="submit">Start Search & Scrape</button>
                </form>
            </div>
            
            <div id="tasks" class="tab-content">
                <div id="tasks-list" class="tasks-list">
                    <!-- Tasks will be loaded here -->
                </div>
            </div>
        </div>
        
        <script>
            function showTab(tabName) {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                event.target.classList.add('active');
                document.getElementById(tabName).classList.add('active');
                if (tabName === 'tasks') {
                    loadTasks();
                }
            }
            
            async function submitUrlScrape(event) {
                event.preventDefault();
                const formData = new FormData(event.target);
                const urls = formData.get('urls').split('\\n').filter(u => u.trim());
                const response = await fetch('/scrape', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        urls: urls,
                        output_format: formData.get('format'),
                        use_playwright: formData.get('playwright') === 'on'
                    })
                });
                const result = await response.json();
                alert(`Task #${result.task_id} started! Check Tasks History for progress.`);
                showTab('tasks');
            }
            
            async function submitSearchScrape(event) {
                event.preventDefault();
                const formData = new FormData(event.target);
                const response = await fetch('/scrape', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        search_query: formData.get('query'),
                        max_pages: parseInt(formData.get('pages')),
                        output_format: formData.get('format')
                    })
                });
                const result = await response.json();
                alert(`Task #${result.task_id} started! Check Tasks History for progress.`);
                showTab('tasks');
            }
            
            async function loadTasks() {
                const response = await fetch('/tasks');
                const tasks = await response.json();
                const container = document.getElementById('tasks-list');
                
                if (tasks.length === 0) {
                    container.innerHTML = '<p style="text-align: center; color: #999;">No tasks yet. Start scraping!</p>';
                    return;
                }
                
                container.innerHTML = tasks.map(task => `
                    <div class="task-item">
                        <div class="task-header">
                            <span class="task-id">Task #${task.task_id}</span>
                            <span class="status ${task.status}">${task.status.toUpperCase()}</span>
                        </div>
                        <p>${task.message}</p>
                        ${task.status === 'running' ? `
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${(task.progress/task.total)*100}%"></div>
                            </div>
                            <p style="font-size: 14px; color: #666;">${task.progress} / ${task.total} items processed</p>
                        ` : ''}
                        ${task.download_link ? `
                            <a href="${task.download_link}" download>
                                <button class="download-btn">📥 Download Results</button>
                            </a>
                        ` : ''}
                        <p style="font-size: 12px; color: #999; margin-top: 10px;">
                            Created: ${new Date(task.created_at).toLocaleString()}
                            ${task.completed_at ? `<br>Completed: ${new Date(task.completed_at).toLocaleString()}` : ''}
                        </p>
                    </div>
                `).join('');
            }
            
            // Auto-refresh tasks every 2 seconds when on tasks tab
            setInterval(() => {
                if (document.getElementById('tasks').classList.contains('active')) {
                    loadTasks();
                }
            }, 2000);
        </script>
    </body>
    </html>
    """

@app.post("/scrape")
async def create_scrape_task(request: ScrapeRequest, background_tasks: BackgroundTasks):
    """Create a new scraping task"""
    global task_counter
    task_counter += 1
    task_id = task_counter
    
    tasks[task_id] = TaskStatus(
        task_id=task_id,
        status="pending",
        progress=0,
        total=0,
        message="Task created, starting soon...",
        created_at=datetime.now().isoformat()
    )
    
    background_tasks.add_task(run_scraping_task, task_id, request)
    
    return {"task_id": task_id, "message": "Task created successfully"}

async def run_scraping_task(task_id: int, request: ScrapeRequest):
    """Run the actual scraping task"""
    task = tasks[task_id]
    task.status = "running"
    
    try:
        scraper = eBayScraper(headless=True)
        urls = request.urls or []
        
        # If search query provided, get URLs first
        if request.search_query:
            task.message = f"Searching for '{request.search_query}'..."
            urls = await scraper.scrape_search_results(request.search_query, request.max_pages)
            task.message = f"Found {len(urls)} products, starting scrape..."
        
        task.total = len(urls)
        products = []
        
        for i, url in enumerate(urls, 1):
            task.progress = i
            task.message = f"Scraping product {i}/{len(urls)}..."
            
            if request.use_playwright:
                product = await scraper.scrape_with_playwright(url)
            else:
                product = scraper.scrape_with_requests(url)
            
            if product:
                products.append(product)
            
            await asyncio.sleep(1)  # Rate limiting
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"results_{task_id}_{timestamp}"
        
        if request.output_format == "excel":
            output_file = f"{filename}.xlsx"
            scraper.save_to_excel(products, output_file)
        elif request.output_format == "csv":
            output_file = f"{filename}.csv"
            scraper.save_to_csv(products, output_file)
        else:
            output_file = f"{filename}.json"
            with open(output_file, 'w') as f:
                json.dump([p.__dict__ for p in products], f, indent=2, default=str)
        
        task.status = "completed"
        task.message = f"Successfully scraped {len(products)} products"
        task.completed_at = datetime.now().isoformat()
        task.download_link = f"/download/{output_file}"
        
    except Exception as e:
        task.status = "failed"
        task.message = f"Error: {str(e)}"
        task.completed_at = datetime.now().isoformat()

@app.get("/tasks")
async def get_tasks():
    """Get all tasks"""
    return list(tasks.values())

@app.get("/task/{task_id}")
async def get_task(task_id: int):
    """Get specific task status"""
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    return tasks[task_id]

@app.get("/download/{filename}")
async def download_file(filename: str):
    """Download result file"""
    if not os.path.exists(filename):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(filename, media_type="application/octet-stream", filename=filename)

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting eBay Scraper Dashboard...")
    print("📍 Open http://localhost:8000 in your browser")
    uvicorn.run(app, host="0.0.0.0", port=8000)