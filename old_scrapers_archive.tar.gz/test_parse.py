#!/usr/bin/env python3
"""
Test HTML parsing
"""

from bs4 import BeautifulSoup

# Read the saved HTML
with open('ebay_page.html', 'r', encoding='utf-8') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

# Test different parsers
print("Testing with html.parser:")
items1 = soup.find_all('li', class_='s-card')
print(f"  s-card items: {len(items1)}")

# Try lxml parser
try:
    soup2 = BeautifulSoup(html, 'lxml')
    items2 = soup2.find_all('li', class_='s-card')
    print(f"\nTesting with lxml:")
    print(f"  s-card items: {len(items2)}")
except:
    print("\nlxml not available")

# Try different selectors
print("\nTrying different selectors:")
items3 = soup.find_all('li', {'class': re.compile('s-card')})
print(f"  li with s-card regex: {len(items3)}")

import re
items4 = soup.find_all('li', class_=re.compile('s-card'))
print(f"  li with s-card regex (class_): {len(items4)}")

# Check if the HTML is complete
print(f"\nHTML length: {len(html)} bytes")
print(f"Number of <li> tags: {len(soup.find_all('li'))}")

# Look for any item with /itm/ links
links = soup.find_all('a', href=re.compile(r'/itm/\d+'))
print(f"Links with /itm/: {len(links)}")