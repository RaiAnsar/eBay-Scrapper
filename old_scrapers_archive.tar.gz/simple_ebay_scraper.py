#!/usr/bin/env python3
"""
Simple eBay Scraper using requests and BeautifulSoup
Fast and lightweight alternative for basic scraping needs
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import re
from datetime import datetime
import time

class SimpleEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
    
    def scrape_product(self, url):
        """Scrape a single eBay product"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract data with multiple fallback selectors
            data = {
                'page_url': url,
                'title': self._extract_text(soup, [
                    'h1.it-ttl', 
                    'h1[class*="title"]',
                    '[data-testid="x-item-title"] span',
                    'h1'
                ]),
                'price': self._extract_price(soup),
                'ean': self._extract_ean_upc(soup),
                'main_image': self._extract_image(soup),
                'gallery_images': self._extract_gallery_images(soup),
                'seller': self._extract_text(soup, [
                    '.si-inner .mbg-nw',
                    '[data-testid="str-title"] a',
                    '.str-seller-card__store-name'
                ]),
                'condition': self._extract_text(soup, [
                    '.u-flL.condText',
                    '[data-testid="x-item-condition-value"] span',
                    '.ux-icon-text__text'
                ]),
                'shipping': self._extract_shipping(soup),
                'availability': self._extract_text(soup, [
                    '[data-testid="x-bin-quantity"]',
                    '.vi-acc-num-avail',
                    '.qtyTxt'
                ]),
                'item_number': self._extract_item_number(url, soup),
                'category': self._extract_category(soup),
                'brand': self._extract_specifics(soup, 'Brand'),
                'mpn': self._extract_specifics(soup, 'MPN'),
                'scraped_at': datetime.now().isoformat()
            }
            
            return data
            
        except Exception as e:
            print(f"Error scraping {url}: {e}")
            return None
    
    def _extract_text(self, soup, selectors):
        """Try multiple selectors to extract text"""
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get_text(strip=True)
        return ""
    
    def _extract_price(self, soup):
        """Extract price with multiple strategies"""
        # Try meta tag first
        price_meta = soup.find('meta', {'itemprop': 'price'})
        if price_meta:
            return price_meta.get('content', '')
        
        # Try various price selectors
        selectors = [
            '.x-price-primary',
            '[data-testid="x-price-primary"] span',
            '.vi-VR-cvipPrice',
            '.prc-now',
            'span[itemprop="price"]'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                price_text = elem.get_text(strip=True)
                # Extract numeric price
                price_match = re.search(r'[\d,]+\.?\d*', price_text)
                if price_match:
                    return f"£{price_match.group()}"
        
        return ""
    
    def _extract_ean_upc(self, soup):
        """Extract EAN or UPC"""
        # Look for EAN/UPC in item specifics
        specifics = soup.select('.ux-layout-section__row, .itemAttr tr')
        for row in specifics:
            text = row.get_text()
            if 'EAN' in text or 'UPC' in text:
                # Find the value
                value = row.select_one('.ux-textspans--BOLD, .attrLabels + span')
                if value:
                    return value.get_text(strip=True)
        return ""
    
    def _extract_image(self, soup):
        """Extract main product image"""
        selectors = [
            '#icImg',
            '.ux-image-magnify__container img',
            '[data-testid="primary-image"] img',
            'img[itemprop="image"]'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get('src', '')
        return ""
    
    def _extract_gallery_images(self, soup):
        """Extract all gallery images"""
        images = []
        
        # Try different gallery selectors
        gallery_imgs = soup.select('.ux-image-filmstrip img, .ux-image-carousel img, .tdThumb img')
        
        for img in gallery_imgs:
            src = img.get('src', '')
            if src and 'ebayimg.com' in src:
                images.append(src)
        
        return ','.join(images[:10])  # Limit to 10 images
    
    def _extract_shipping(self, soup):
        """Extract shipping information"""
        selectors = [
            '.vi-acc-del-range',
            '[data-testid="x-shipping-delivery"] span',
            '.vi-ship-del-acc'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get_text(strip=True)
        return ""
    
    def _extract_item_number(self, url, soup):
        """Extract item number from URL or page"""
        # Try URL first
        match = re.search(r'/itm/(\d+)', url)
        if match:
            return match.group(1)
        
        # Try page content
        elem = soup.select_one('[data-testid="x-item-number"], .vi-acc-num')
        if elem:
            text = elem.get_text()
            match = re.search(r'\d+', text)
            if match:
                return match.group()
        
        return ""
    
    def _extract_category(self, soup):
        """Extract category breadcrumb"""
        breadcrumb = soup.select('.vi-VR-brumb-lnkLst li, nav[aria-label="Breadcrumb"] a')
        if breadcrumb:
            categories = [item.get_text(strip=True) for item in breadcrumb]
            return ' > '.join(categories)
        return ""
    
    def _extract_specifics(self, soup, name):
        """Extract specific item details like Brand, MPN"""
        rows = soup.select('.ux-layout-section__row, .itemAttr tr')
        for row in rows:
            if name in row.get_text():
                value = row.select_one('.ux-textspans--BOLD, .attrLabels + span')
                if value:
                    return value.get_text(strip=True)
        return ""
    
    def search_products(self, query, max_pages=1):
        """Search for products and return URLs"""
        urls = []
        base_url = "https://www.ebay.co.uk/sch/i.html"
        
        for page in range(1, max_pages + 1):
            params = {
                '_nkw': query,
                '_pgn': page,
                'LH_ItemCondition': '4'  # Used condition
            }
            
            try:
                response = self.session.get(base_url, params=params, timeout=10)
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Find all product links
                for link in soup.select('.s-item__link'):
                    href = link.get('href', '')
                    if href and '/itm/' in href:
                        # Clean the URL
                        clean_url = href.split('?')[0]
                        if clean_url not in urls:
                            urls.append(clean_url)
                
                print(f"Found {len(urls)} products on page {page}")
                time.sleep(1)  # Be respectful
                
            except Exception as e:
                print(f"Error searching page {page}: {e}")
        
        return urls
    
    def scrape_multiple(self, urls, delay=1):
        """Scrape multiple URLs"""
        results = []
        
        for i, url in enumerate(urls, 1):
            print(f"Scraping {i}/{len(urls)}: {url}")
            
            data = self.scrape_product(url)
            if data:
                results.append(data)
            
            if i < len(urls):  # Don't delay after last item
                time.sleep(delay)
        
        return results
    
    def save_to_excel(self, data, filename="ebay_products.xlsx"):
        """Save data to Excel file"""
        df = pd.DataFrame(data)
        df.to_excel(filename, index=False)
        print(f"✅ Saved {len(data)} products to {filename}")
    
    def save_to_csv(self, data, filename="ebay_products.csv"):
        """Save data to CSV file"""
        df = pd.DataFrame(data)
        df.to_csv(filename, index=False)
        print(f"✅ Saved {len(data)} products to {filename}")


def main():
    """Example usage"""
    print("\n" + "="*60)
    print("Simple eBay Scraper - Fast & Lightweight")
    print("="*60 + "\n")
    
    scraper = SimpleEbayScraper()
    
    # Test with specific URLs
    test_urls = [
        "https://www.ebay.co.uk/itm/296667726490",
        "https://www.ebay.co.uk/itm/386978552699"
    ]
    
    print("📦 Scraping test products...\n")
    results = scraper.scrape_multiple(test_urls)
    
    if results:
        # Display results
        for product in results:
            print(f"\n{'='*40}")
            print(f"Title: {product['title'][:50]}...")
            print(f"Price: {product['price']}")
            print(f"Item #: {product['item_number']}")
            print(f"Seller: {product['seller']}")
            print(f"Condition: {product['condition']}")
            print(f"EAN: {product['ean']}")
        
        # Save to files
        scraper.save_to_excel(results, "test_results.xlsx")
        scraper.save_to_csv(results, "test_results.csv")
    
    # Test search functionality
    print(f"\n{'='*40}")
    print("🔍 Testing search functionality...")
    
    search_urls = scraper.search_products("blu ray", max_pages=1)
    print(f"\nFound {len(search_urls)} products from search")
    
    if search_urls[:3]:  # Scrape first 3 results
        print("\n📦 Scraping search results...\n")
        search_results = scraper.scrape_multiple(search_urls[:3])
        
        if search_results:
            scraper.save_to_excel(search_results, "search_results.xlsx")

if __name__ == "__main__":
    main()