#!/usr/bin/env python3
"""
Test Playwright-based eBay Scraper
More reliable for modern eBay pages
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime

async def scrape_ebay_search():
    print("\n" + "="*60)
    print("🛒 Testing eBay Scraper with Playwright")
    print("="*60 + "\n")
    
    async with async_playwright() as p:
        # Launch browser
        print("🌐 Launching browser...")
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        # Set user agent
        await page.set_extra_http_headers({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        
        # Navigate to eBay search
        url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_ipg=240"
        print(f"📍 Navigating to: {url}\n")
        
        await page.goto(url, wait_until='networkidle')
        
        # Wait for results to load
        await page.wait_for_selector('.srp-results', timeout=10000)
        
        # Extract product data
        print("📦 Extracting products...\n")
        
        products = await page.evaluate('''() => {
            const items = [];
            const productElements = document.querySelectorAll('.s-item:not(.s-item--watch-at-corner)');
            
            productElements.forEach((item, index) => {
                // Skip first item (often a placeholder)
                if (index === 0) return;
                
                // Skip sponsored items
                if (item.innerText.includes('SPONSORED')) return;
                
                const link = item.querySelector('.s-item__link');
                const title = item.querySelector('.s-item__title');
                const price = item.querySelector('.s-item__price');
                const image = item.querySelector('.s-item__image img');
                const shipping = item.querySelector('.s-item__shipping');
                const condition = item.querySelector('.SECONDARY_INFO');
                
                if (link && title && !title.innerText.includes('Shop on eBay')) {
                    // Extract item number from URL
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    const itemNumber = itemMatch ? itemMatch[1] : '';
                    
                    items.push({
                        title: title.innerText.trim(),
                        price: price ? price.innerText.trim() : '',
                        item_number: itemNumber,
                        url: href.split('?')[0],
                        image: image ? image.src : '',
                        shipping: shipping ? shipping.innerText.trim() : '',
                        condition: condition ? condition.innerText.trim() : ''
                    });
                }
            });
            
            return items;
        }''')
        
        await browser.close()
        
        print(f"✅ Found {len(products)} products\n")
        
        if products:
            # Save to Excel
            df = pd.DataFrame(products)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_playwright_results_{timestamp}.xlsx"
            df.to_excel(filename, index=False)
            
            print("📊 Sample Results:")
            print("="*60)
            
            for i, product in enumerate(products[:5], 1):
                print(f"\n{i}. {product['title'][:60]}...")
                print(f"   💰 Price: {product['price']}")
                print(f"   🔢 Item #: {product['item_number']}")
                print(f"   📦 Condition: {product['condition']}")
                print(f"   🚚 Shipping: {product['shipping']}")
            
            print(f"\n💾 Full results saved to: {filename}")
            print(f"📈 Total unique products: {len(df['item_number'].unique())}")
        
        return products

if __name__ == "__main__":
    asyncio.run(scrape_ebay_search())