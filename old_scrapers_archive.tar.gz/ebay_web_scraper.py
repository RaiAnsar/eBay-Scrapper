#!/usr/bin/env python3
"""
eBay Web Scraper with UI - Dynamic URL Input
Combines working scraper with web interface for easy use
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional, Dict
import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import json
import random
import os
import uuid
from pathlib import Path
import time
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create app
app = FastAPI(title="eBay Scraper Web Interface", version="4.0")

# Storage
tasks = {}
results_dir = Path("scraping_results")
results_dir.mkdir(exist_ok=True)

class ScrapeRequest(BaseModel):
    urls: List[str]  # Can be search URLs or keywords
    auto_detect_pages: bool = True
    max_pages_override: Optional[int] = None
    extract_ean: bool = False
    extract_description: bool = False
    items_per_page: int = 200  # eBay allows up to 200 items per page

class WorkingEbayScraper:
    """The actual working scraper logic from our tested implementation"""
    
    def __init__(self, extract_ean=False, extract_description=False):
        self.extract_ean = extract_ean
        self.extract_description = extract_description
        self.seen_items = set()
        self.ean_cache = {}
        
    async def scrape_url(self, search_url: str, max_pages: int, items_per_page: int = 200, progress_callback=None):
        """Scrape a single eBay search URL"""
        products = []
        
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
            
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            )
            
            # Anti-detection
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            """)
            
            page = await context.new_page()
            
            # Establish session
            await page.goto('https://www.ebay.co.uk')
            await page.wait_for_timeout(2000)
            
            # Accept cookies
            try:
                await page.click('#gdpr-banner-accept', timeout=2000)
            except:
                pass
            
            # Create detail page for EAN extraction if needed
            detail_page = await context.new_page() if self.extract_ean else None
            
            # Scrape pages
            for page_num in range(1, max_pages + 1):
                # Build URL with pagination
                url = search_url
                if '?' in url:
                    url += f"&_ipg={items_per_page}"
                else:
                    url += f"?_ipg={items_per_page}"
                    
                if page_num > 1:
                    url += f"&_pgn={page_num}"
                
                try:
                    # Navigate to page
                    await page.goto(url, wait_until='domcontentloaded', timeout=30000)
                    await page.wait_for_timeout(2000)
                    
                    # Scroll to load lazy content
                    await page.evaluate('window.scrollTo(0, document.body.scrollHeight/2)')
                    await page.wait_for_timeout(1000)
                    
                    # Extract products
                    page_products = await page.evaluate('''() => {
                        const items = [];
                        const elements = document.querySelectorAll('li[data-viewport]');
                        
                        // Skip first 2 sponsored items
                        for(let i = 2; i < elements.length; i++) {
                            const item = elements[i];
                            
                            const link = item.querySelector('a[href*="/itm/"]');
                            if(!link) continue;
                            
                            const href = link.href;
                            const match = href.match(/\\/itm\\/(\\d+)/);
                            if(!match) continue;
                            
                            // Get title
                            const titleElem = item.querySelector('div[role="heading"] span') ||
                                            item.querySelector('.s-item__title') ||
                                            item.querySelector('h3');
                            const title = titleElem ? (titleElem.innerText || '').trim() : '';
                            
                            if(!title || title === 'Shop on eBay') continue;
                            
                            // Get price
                            const priceElem = item.querySelector('.s-item__price');
                            const price = priceElem ? (priceElem.innerText || '').trim() : '';
                            
                            // Get condition
                            const condElem = item.querySelector('.SECONDARY_INFO');
                            const condition = condElem ? (condElem.innerText || '').trim() : '';
                            
                            // Get shipping
                            const shipElem = item.querySelector('.s-item__shipping');
                            const shipping = shipElem ? (shipElem.innerText || '').trim() : '';
                            
                            // Get image
                            const imgElem = item.querySelector('img');
                            const image = imgElem ? (imgElem.src || imgElem.dataset.src || '') : '';
                            
                            items.push({
                                item_number: match[1],
                                title: title,
                                price: price,
                                condition: condition,
                                shipping: shipping,
                                image: image,
                                url: href
                            });
                        }
                        
                        return items;
                    }''')
                    
                    # Process new products
                    for product in page_products:
                        if product['item_number'] not in self.seen_items:
                            self.seen_items.add(product['item_number'])
                            
                            # Extract EAN if requested (limit to 3 per page)
                            ean = ''
                            if self.extract_ean and detail_page and len(products) % 50 < 3:
                                ean = await self.extract_ean_from_page(detail_page, product['url'], product['item_number'])
                            
                            products.append({
                                'Item_Number': product['item_number'],
                                'Title': product['title'],
                                'Price': product['price'],
                                'EAN': ean,
                                'Condition': product['condition'],
                                'Shipping': product['shipping'],
                                'Image_URL': product['image'],
                                'URL': product['url'],
                                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            })
                    
                    # Progress callback
                    if progress_callback:
                        await progress_callback(page_num, len(page_products))
                    
                    logger.info(f"Page {page_num}: Found {len(page_products)} products")
                    
                except Exception as e:
                    logger.error(f"Error on page {page_num}: {e}")
                
                # Delay between pages
                if page_num < max_pages:
                    await asyncio.sleep(random.uniform(2, 4))
            
            await browser.close()
        
        return products
    
    async def extract_ean_from_page(self, page, item_url: str, item_number: str) -> str:
        """Extract EAN from product page"""
        if item_number in self.ean_cache:
            return self.ean_cache[item_number]
        
        try:
            await page.goto(item_url, wait_until='domcontentloaded', timeout=10000)
            
            ean = await page.evaluate('''() => {
                // Check item specifics table
                const labels = document.querySelectorAll('.ux-labels-values__labels');
                for(let label of labels) {
                    const text = label.textContent || '';
                    if(text.includes('EAN') || text.includes('UPC')) {
                        const value = label.nextElementSibling;
                        if(value) {
                            const ean = value.textContent.trim();
                            if(ean.match(/^[0-9]{8,13}$/)) {
                                return ean;
                            }
                        }
                    }
                }
                return '';
            }''')
            
            if ean:
                self.ean_cache[item_number] = ean
            
            return ean
            
        except:
            return ''

async def detect_total_pages(url: str) -> int:
    """Detect total pages available for a search"""
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            
            await page.goto(url, wait_until='domcontentloaded', timeout=15000)
            await page.wait_for_timeout(1000)
            
            # Try to extract total results count
            total_items = await page.evaluate('''() => {
                // Look for result count
                const countElem = document.querySelector('.srp-controls__count-heading') ||
                                document.querySelector('.srp-controls__count');
                if (countElem) {
                    const text = countElem.innerText || '';
                    const match = text.match(/([\\d,]+)\\+?\\s+results?/i);
                    if (match) {
                        return parseInt(match[1].replace(/,/g, ''));
                    }
                }
                
                // Alternative: count current page items
                const items = document.querySelectorAll('li[data-viewport]');
                return items.length > 2 ? items.length - 2 : 0;
            }''')
            
            await browser.close()
            
            if total_items:
                # Calculate pages (200 items per page max)
                pages = min(int(total_items / 200) + 1, 50)  # Cap at 50 pages
                return pages
            
            return 10  # Default
            
    except Exception as e:
        logger.error(f"Error detecting pages: {e}")
        return 10

async def scrape_task(task_id: str, urls: List[str], auto_detect: bool, max_pages_override: Optional[int], 
                      extract_ean: bool, extract_description: bool, items_per_page: int):
    """Background task to scrape multiple URLs"""
    
    task = tasks[task_id]
    task['status'] = 'running'
    task['started_at'] = datetime.now()
    
    try:
        all_products = []
        
        for url_index, url_input in enumerate(urls, 1):
            task['current_url'] = url_index
            
            # Process URL - detect if it's a keyword or actual URL
            if not url_input.startswith('http'):
                # It's keywords - build URL
                keywords = url_input.replace(' ', '+')
                search_url = f"https://www.ebay.co.uk/sch/i.html?_nkw={keywords}"
            else:
                search_url = url_input
            
            task['current_url_text'] = search_url[:80]
            
            # Auto-detect pages if enabled
            if auto_detect and not max_pages_override:
                detected_pages = await detect_total_pages(search_url)
                max_pages = min(detected_pages, 50)  # Cap at 50 for safety
                logger.info(f"Detected {detected_pages} pages, using {max_pages}")
            else:
                max_pages = max_pages_override or 10
            
            task['total_pages'] = max_pages
            
            # Progress callback
            async def progress_callback(current_page, products_found):
                task['current_page'] = current_page
                task['products_on_current_page'] = products_found
            
            # Create scraper and run
            scraper = WorkingEbayScraper(extract_ean=extract_ean, extract_description=extract_description)
            products = await scraper.scrape_url(
                search_url,
                max_pages,
                items_per_page,
                progress_callback
            )
            
            if products:
                all_products.extend(products)
                
                # Save individual file
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"ebay_{task_id}_url{url_index}_{timestamp}.xlsx"
                filepath = results_dir / filename
                
                df = pd.DataFrame(products)
                df.to_excel(filepath, index=False)
                
                task['results'].append({
                    'url': search_url,
                    'products_count': len(products),
                    'excel_file': filename
                })
            
            task['total_products'] = len(all_products)
            
            # Small delay between URLs
            if url_index < len(urls):
                await asyncio.sleep(3)
        
        # Save combined file if multiple URLs
        if len(urls) > 1 and all_products:
            combined_filename = f"ebay_{task_id}_combined_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            combined_filepath = results_dir / combined_filename
            
            df_combined = pd.DataFrame(all_products)
            df_combined.to_excel(combined_filepath, index=False)
            task['combined_file'] = combined_filename
        
        # Calculate stats
        elapsed = (datetime.now() - task['started_at']).total_seconds()
        task['products_per_minute'] = (task['total_products'] / elapsed * 60) if elapsed > 0 else 0
        task['status'] = 'completed'
        task['completed_at'] = datetime.now()
        
    except Exception as e:
        task['status'] = 'failed'
        task['error_message'] = str(e)
        task['completed_at'] = datetime.now()
        logger.error(f"Task {task_id} failed: {e}")

@app.get("/", response_class=HTMLResponse)
async def home():
    """Serve the main page"""
    html = """
<!DOCTYPE html>
<html>
<head>
    <title>eBay Scraper - Web Interface</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 48px;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: monospace;
            min-height: 150px;
            resize: vertical;
        }
        textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        .checkbox-group {
            display: flex;
            gap: 30px;
            margin: 20px 0;
        }
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        input[type="number"] {
            width: 100px;
            padding: 8px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
        }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 14px 40px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        .status {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .status.running {
            background: #fff3cd;
            color: #856404;
        }
        .status.completed {
            background: #d1f2eb;
            color: #0c5460;
        }
        .status.failed {
            background: #f8d7da;
            color: #721c24;
        }
        .progress-bar {
            width: 100%;
            height: 30px;
            background: #e0e0e0;
            border-radius: 15px;
            overflow: hidden;
            margin: 20px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            transition: width 0.5s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
        .result-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .download-btn {
            background: #28a745;
            color: white;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
        }
        .download-btn:hover {
            background: #218838;
        }
        .warning {
            background: #ffeaa7;
            color: #d63031;
            padding: 10px;
            border-radius: 6px;
            margin: 15px 0;
            font-size: 14px;
        }
        .loader {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛒 eBay Scraper Web Interface</h1>
            <p>Scrape multiple eBay searches with dynamic URL input</p>
        </div>
        
        <div class="card">
            <h2>Configure Scraping</h2>
            
            <div style="margin-bottom: 20px;">
                <label><strong>Enter eBay URLs or Search Keywords (one per line):</strong></label>
                <textarea id="urlInput" placeholder="Examples:
https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray
https://www.ebay.co.uk/sch/i.html?_nkw=ps5+games
nintendo switch games
xbox series x
4K movies"></textarea>
            </div>
            
            <div class="checkbox-group">
                <div class="checkbox-item">
                    <input type="checkbox" id="autoDetect" checked>
                    <label for="autoDetect">Auto-detect total pages</label>
                </div>
                <div class="checkbox-item">
                    <input type="checkbox" id="extractEan">
                    <label for="extractEan">Extract EAN codes (slower)</label>
                </div>
            </div>
            
            <div id="maxPagesGroup" style="display:none; margin: 20px 0;">
                <label>Max pages per search:</label>
                <input type="number" id="maxPages" value="10" min="1" max="100">
            </div>
            
            <div id="eanWarning" class="warning" style="display:none;">
                ⚠️ EAN extraction visits individual product pages, significantly increasing scraping time.
            </div>
            
            <button class="btn" onclick="startScraping()" id="startBtn">🚀 Start Scraping</button>
            
            <div id="status" class="status" style="display:none;"></div>
        </div>
        
        <div class="card" id="progressCard" style="display:none;">
            <h2>Progress</h2>
            
            <div class="progress-bar">
                <div class="progress-fill" id="progressBar" style="width: 0%">0%</div>
            </div>
            
            <div class="stats-grid" id="statsGrid"></div>
            
            <div id="resultsList"></div>
        </div>
    </div>
    
    <script>
        let currentTaskId = null;
        let monitorInterval = null;
        
        document.getElementById('autoDetect').addEventListener('change', function() {
            document.getElementById('maxPagesGroup').style.display = this.checked ? 'none' : 'block';
        });
        
        document.getElementById('extractEan').addEventListener('change', function() {
            document.getElementById('eanWarning').style.display = this.checked ? 'block' : 'none';
        });
        
        async function startScraping() {
            const urlInput = document.getElementById('urlInput').value.trim();
            if (!urlInput) {
                alert('Please enter at least one URL or search keyword');
                return;
            }
            
            const urls = urlInput.split('\\n').filter(line => line.trim());
            const autoDetect = document.getElementById('autoDetect').checked;
            const extractEan = document.getElementById('extractEan').checked;
            const maxPages = autoDetect ? null : parseInt(document.getElementById('maxPages').value);
            
            document.getElementById('startBtn').disabled = true;
            
            const statusDiv = document.getElementById('status');
            statusDiv.style.display = 'block';
            statusDiv.className = 'status running';
            statusDiv.innerHTML = `<span class="loader"></span> Starting...`;
            
            document.getElementById('progressCard').style.display = 'block';
            
            const response = await fetch('/scrape', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    urls: urls,
                    auto_detect_pages: autoDetect,
                    max_pages_override: maxPages,
                    extract_ean: extractEan,
                    extract_description: false,
                    items_per_page: 200
                })
            });
            
            const data = await response.json();
            currentTaskId = data.task_id;
            
            monitorProgress();
        }
        
        async function monitorProgress() {
            if (!currentTaskId) return;
            
            const response = await fetch(`/status/${currentTaskId}`);
            const task = await response.json();
            
            updateUI(task);
            
            if (task.status === 'running' || task.status === 'pending') {
                monitorInterval = setTimeout(monitorProgress, 2000);
            } else {
                document.getElementById('startBtn').disabled = false;
            }
        }
        
        function updateUI(task) {
            const statusDiv = document.getElementById('status');
            statusDiv.className = `status ${task.status}`;
            
            if (task.status === 'running') {
                statusDiv.innerHTML = `<span class="loader"></span> Processing URL ${task.current_url}/${task.total_urls}...`;
            } else if (task.status === 'completed') {
                statusDiv.innerHTML = `✅ Completed! ${task.total_products} products scraped`;
            } else if (task.status === 'failed') {
                statusDiv.innerHTML = `❌ Error: ${task.error_message}`;
            }
            
            // Update progress
            let progress = 0;
            if (task.total_urls > 0 && task.total_pages > 0) {
                const urlProgress = (task.current_url - 1) / task.total_urls;
                const pageProgress = task.current_page / task.total_pages / task.total_urls;
                progress = (urlProgress + pageProgress) * 100;
            }
            
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressBar').innerText = Math.round(progress) + '%';
            
            // Update stats
            document.getElementById('statsGrid').innerHTML = `
                <div class="stat-card">
                    <div class="stat-value">${task.current_url}/${task.total_urls}</div>
                    <div class="stat-label">URLs</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.current_page}/${task.total_pages}</div>
                    <div class="stat-label">Pages</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.total_products}</div>
                    <div class="stat-label">Products</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.products_per_minute ? task.products_per_minute.toFixed(0) : 0}</div>
                    <div class="stat-label">Products/Min</div>
                </div>
            `;
            
            // Update results
            if (task.results && task.results.length > 0) {
                let html = '<h3>Results:</h3>';
                task.results.forEach(result => {
                    html += `
                        <div class="result-item">
                            <div>
                                <strong>${result.url.substring(0, 60)}...</strong><br>
                                📦 ${result.products_count} products
                            </div>
                            <a href="/download/${result.excel_file}" class="download-btn">📥 Download</a>
                        </div>
                    `;
                });
                
                if (task.combined_file) {
                    html += `
                        <div class="result-item" style="background: #d1f2eb;">
                            <div>
                                <strong>🎯 Combined Results</strong><br>
                                📦 ${task.total_products} total products
                            </div>
                            <a href="/download/${task.combined_file}" class="download-btn">📥 Download All</a>
                        </div>
                    `;
                }
                
                document.getElementById('resultsList').innerHTML = html;
            }
        }
    </script>
</body>
</html>
"""
    return html

@app.post("/scrape")
async def create_scrape_task(request: ScrapeRequest, background_tasks: BackgroundTasks):
    """Create a new scraping task"""
    
    task_id = str(uuid.uuid4())[:8]
    tasks[task_id] = {
        'task_id': task_id,
        'status': 'pending',
        'started_at': None,
        'completed_at': None,
        'current_url': 0,
        'total_urls': len(request.urls),
        'current_page': 0,
        'total_pages': 0,
        'total_products': 0,
        'products_per_minute': 0,
        'error_message': None,
        'results': []
    }
    
    background_tasks.add_task(
        scrape_task,
        task_id,
        request.urls,
        request.auto_detect_pages,
        request.max_pages_override,
        request.extract_ean,
        request.extract_description,
        request.items_per_page
    )
    
    return {"task_id": task_id, "message": f"Started processing {len(request.urls)} URL(s)"}

@app.get("/status/{task_id}")
async def get_task_status(task_id: str):
    """Get status of a scraping task"""
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    return tasks[task_id]

@app.get("/download/{filename}")
async def download_file(filename: str):
    """Download Excel file"""
    filepath = results_dir / filename
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=filepath,
        filename=filename,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("🚀 eBay Scraper - Web Interface")
    print("="*60)
    print("✅ Starting server at http://localhost:8000")
    print("📊 Features:")
    print("   • Dynamic URL/keyword input")
    print("   • Auto-detects total pages")
    print("   • Optional EAN extraction")
    print("   • Real-time progress tracking")
    print("   • Excel export with downloads")
    print("="*60 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)