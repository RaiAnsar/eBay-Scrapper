#!/usr/bin/env python3
"""
PRACTICAL eBay Scraper - Immediate Working Solution
- Shows browser window (avoids detection)
- Single worker (no resource burning)
- Proper delays (human-like behavior)
- Actually tries to get EAN and descriptions
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import random
import json
import os

class PracticalEbayScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items = set()
        self.checkpoint_file = 'scraping_checkpoint.json'
        
    def save_checkpoint(self, products, page_num):
        """Save progress to resume later"""
        checkpoint = {
            'last_page': page_num,
            'seen_items': list(self.seen_items),
            'products_count': len(products),
            'timestamp': datetime.now().isoformat()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint, f)
    
    def load_checkpoint(self):
        """Load previous progress"""
        if os.path.exists(self.checkpoint_file):
            with open(self.checkpoint_file, 'r') as f:
                checkpoint = json.load(f)
                self.seen_items = set(checkpoint['seen_items'])
                print(f"📚 Resuming from page {checkpoint['last_page']}, {checkpoint['products_count']} products already scraped")
                return checkpoint['last_page']
        return 0
    
    async def scrape_ebay(self, search_url: str, max_pages: int = 100, 
                         extract_ean: bool = True, extract_description: bool = True,
                         start_page: int = None):
        """Main scraping function - practical approach"""
        
        print("\n" + "="*70)
        print("🎯 PRACTICAL eBay Scraper - Actually Works")
        print("="*70)
        print(f"📍 URL: {search_url}")
        print(f"📄 Max pages: {max_pages}")
        print(f"📊 Extract EAN: {extract_ean}")
        print(f"📝 Extract Description: {extract_description}")
        print(f"🖥️  Browser: Visible (avoids detection)")
        print(f"⚙️  Workers: 1 (no resource burning)")
        print("="*70 + "\n")
        
        # Load checkpoint if resuming
        if start_page is None:
            start_page = self.load_checkpoint()
        
        all_products = []
        
        async with async_playwright() as p:
            # Launch VISIBLE browser - key to avoiding detection
            browser = await p.chromium.launch(
                headless=False,  # VISIBLE BROWSER
                args=[
                    '--disable-blink-features=AutomationControlled',
                    '--start-maximized'
                ]
            )
            
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
            # Anti-detection
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                window.chrome = {runtime: {}};
            """)
            
            page = await context.new_page()
            
            # Start with eBay homepage
            print("🌐 Establishing session...")
            await page.goto('https://www.ebay.co.uk')
            await page.wait_for_timeout(3000)
            
            # Accept cookies if present
            try:
                await page.click('#gdpr-banner-accept', timeout=2000)
                print("🍪 Cookies accepted")
            except:
                pass
            
            # Main scraping loop
            for page_num in range(start_page + 1, min(start_page + max_pages + 1, 10001)):  # eBay max is 10000
                print(f"\n📄 Page {page_num}")
                print("-" * 40)
                
                # Build URL
                if page_num == 1:
                    url = search_url
                else:
                    url = f"{search_url}&_pgn={page_num}" if '?' in search_url else f"{search_url}?_pgn={page_num}"
                
                try:
                    # Navigate with retry
                    for attempt in range(3):
                        try:
                            await page.goto(url, wait_until='networkidle', timeout=30000)
                            break
                        except:
                            if attempt == 2:
                                raise
                            print(f"   Retry {attempt + 1}...")
                            await page.wait_for_timeout(5000)
                    
                    # Human-like delay
                    await page.wait_for_timeout(random.randint(3000, 5000))
                    
                    # Scroll to load images
                    await page.evaluate('window.scrollTo(0, document.body.scrollHeight/2)')
                    await page.wait_for_timeout(1000)
                    
                    # Extract products
                    products = await page.evaluate('''() => {
                        const items = [];
                        const elements = document.querySelectorAll('li[data-viewport]');
                        
                        elements.forEach(item => {
                            const link = item.querySelector('a[href*="/itm/"]');
                            if (!link) return;
                            
                            const titleElem = item.querySelector('h3, [role="heading"]');
                            if (!titleElem || titleElem.innerText === 'Shop on eBay') return;
                            
                            const href = link.href;
                            const match = href.match(/\\/itm\\/(\\d+)/);
                            if (!match) return;
                            
                            const priceElem = item.querySelector('.s-item__price');
                            const imgElem = item.querySelector('img');
                            const condElem = item.querySelector('.SECONDARY_INFO');
                            const shipElem = item.querySelector('.s-item__shipping');
                            
                            items.push({
                                title: titleElem.innerText.trim(),
                                price: priceElem ? priceElem.innerText.trim() : '',
                                item_number: match[1],
                                image: imgElem ? (imgElem.src || imgElem.dataset.src || '') : '',
                                condition: condElem ? condElem.innerText.trim() : '',
                                shipping: shipElem ? shipElem.innerText.trim() : ''
                            });
                        });
                        
                        return items;
                    }''')
                    
                    # Filter new products
                    new_products = []
                    for p in products:
                        if p['item_number'] not in self.seen_items:
                            self.seen_items.add(p['item_number'])
                            
                            product = {
                                'Title': p['title'],
                                'Price': p['price'],
                                'Ebay_Item_Number': p['item_number'],
                                'EAN': '',
                                'Description': '',
                                'Image_URL_1': p['image'],
                                'Condition': p['condition'],
                                'Shipping': p['shipping'],
                                'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}",
                                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            }
                            new_products.append(product)
                    
                    print(f"✅ Found {len(new_products)} new products")
                    
                    # Extract details for SOME products (not all, to avoid burnout)
                    if (extract_ean or extract_description) and new_products:
                        # Only process 3 products per page to avoid detection
                        details_count = min(3, len(new_products))
                        print(f"📊 Extracting details from {details_count} products...")
                        
                        for i, product in enumerate(new_products[:details_count], 1):
                            print(f"   [{i}/{details_count}] {product['Title'][:40]}...")
                            
                            try:
                                # Open in new tab
                                detail_page = await context.new_page()
                                
                                # Random delay before navigation
                                await detail_page.wait_for_timeout(random.randint(2000, 4000))
                                
                                # Navigate to product
                                await detail_page.goto(product['URL'], wait_until='networkidle', timeout=20000)
                                await detail_page.wait_for_timeout(random.randint(3000, 5000))
                                
                                # Scroll to load content
                                await detail_page.evaluate('window.scrollTo(0, document.body.scrollHeight/3)')
                                await detail_page.wait_for_timeout(1000)
                                
                                if extract_ean:
                                    # Try to find EAN
                                    ean = await detail_page.evaluate('''() => {
                                        // Check item specifics
                                        const specifics = document.querySelector('.ux-layout-section--itemSpecifics');
                                        if (specifics) {
                                            const text = specifics.innerText;
                                            const match = text.match(/\\bEAN[:\\s]*(\\d{13})\\b/i);
                                            if (match) return match[1];
                                        }
                                        
                                        // Check entire page
                                        const bodyText = document.body.innerText;
                                        const eanMatch = bodyText.match(/\\bEAN[:\\s]*(\\d{13})\\b/i);
                                        return eanMatch ? eanMatch[1] : '';
                                    }''')
                                    
                                    if ean:
                                        product['EAN'] = ean
                                        print(f"      ✅ EAN: {ean}")
                                
                                if extract_description:
                                    # Try to find description
                                    desc = await detail_page.evaluate('''() => {
                                        // Try standard selectors
                                        const selectors = [
                                            '.vim-description-content',
                                            '[data-testid="item-description"]',
                                            '#viTabs_0_panel',
                                            '.d-item-description'
                                        ];
                                        
                                        for (let sel of selectors) {
                                            const elem = document.querySelector(sel);
                                            if (elem && elem.innerText) {
                                                return elem.innerText.substring(0, 1000);
                                            }
                                        }
                                        
                                        return '';
                                    }''')
                                    
                                    if desc:
                                        # Clean description
                                        desc = desc.replace('\n\n\n', '\n\n').strip()
                                        product['Description'] = desc[:500]
                                        print(f"      ✅ Description: {len(desc)} chars")
                                
                                await detail_page.close()
                                
                            except Exception as e:
                                print(f"      ❌ Error: {str(e)[:50]}")
                            
                            # Human-like delay between products
                            await asyncio.sleep(random.uniform(3, 6))
                    
                    all_products.extend(new_products)
                    self.products_scraped += len(new_products)
                    
                    # Save checkpoint every 5 pages
                    if page_num % 5 == 0:
                        self.save_checkpoint(all_products, page_num)
                        
                        # Save interim results
                        df = pd.DataFrame(all_products)
                        interim_file = f"ebay_interim_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                        df.to_excel(interim_file, index=False)
                        print(f"💾 Saved interim results: {interim_file}")
                    
                    if len(products) == 0:
                        print("📭 No more products found")
                        break
                    
                except Exception as e:
                    print(f"❌ Error on page {page_num}: {str(e)}")
                    continue
                
                # Human-like delay between pages
                if page_num < start_page + max_pages:
                    delay = random.randint(5000, 10000)
                    print(f"⏳ Waiting {delay/1000}s before next page...")
                    await page.wait_for_timeout(delay)
            
            print("\n🏁 Scraping complete, closing browser...")
            await browser.close()
        
        # Final summary
        ean_count = sum(1 for p in all_products if p.get('EAN'))
        desc_count = sum(1 for p in all_products if p.get('Description'))
        
        print("\n" + "="*70)
        print("📊 FINAL RESULTS")
        print("="*70)
        print(f"✅ Total products: {len(all_products)}")
        print(f"📊 Products with EAN: {ean_count} ({ean_count*100/len(all_products):.1f}%)" if all_products else "No products")
        print(f"📝 Products with Description: {desc_count} ({desc_count*100/len(all_products):.1f}%)" if all_products else "No products")
        print("="*70)
        
        return all_products

# Main execution
async def main():
    scraper = PracticalEbayScraper()
    
    # Your search URL
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    # Scrape with reasonable limits
    products = await scraper.scrape_ebay(
        search_url,
        max_pages=10,  # Start with 10 pages as a test
        extract_ean=True,
        extract_description=True
    )
    
    if products:
        # Save final results
        df = pd.DataFrame(products)
        filename = f"ebay_final_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        df.to_excel(filename, index=False)
        print(f"\n📁 Final results saved to: {filename}")
        
        # Also save as CSV for easier inspection
        csv_file = filename.replace('.xlsx', '.csv')
        df.to_csv(csv_file, index=False)
        print(f"📁 CSV backup saved to: {csv_file}")

if __name__ == "__main__":
    print("\n🚀 Starting PRACTICAL eBay Scraper...")
    print("📌 This will open a visible browser window")
    print("📌 Please don't close it while scraping")
    print("📌 Progress is saved every 5 pages")
    print("\nPress Ctrl+C to stop and resume later\n")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️ Scraping interrupted by user")
        print("✅ Progress has been saved")
        print("📌 Run the script again to resume from where you left off")
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        print("📌 Check scraping_checkpoint.json to resume")