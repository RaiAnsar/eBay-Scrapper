#!/usr/bin/env python3
"""
Debug what's on the eBay page
"""

import asyncio
from playwright.async_api import async_playwright

async def debug():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)  # Show browser
        context = await browser.new_context()
        page = await context.new_page()
        
        url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
        print(f"Loading: {url}")
        await page.goto(url, wait_until='domcontentloaded')
        await page.wait_for_timeout(3000)
        
        # Debug selectors
        selectors = [
            'li[data-viewport]',
            '.s-item',
            'li[id*="item"]',
            '[data-gr4]',
            'article[data-gr4]',
            'div[data-gr4]',
            '.srp-results li',
            'ul.srp-results > li'
        ]
        
        for selector in selectors:
            count = await page.evaluate(f'document.querySelectorAll("{selector}").length')
            print(f"Selector '{selector}': {count} elements")
        
        # Check for any items
        item_count = await page.evaluate('''() => {
            // Look for links with /itm/
            const links = document.querySelectorAll('a[href*="/itm/"]');
            console.log('Found links:', links.length);
            return links.length;
        }''')
        print(f"Links with /itm/: {item_count}")
        
        # Try to find what the actual container is
        print("\n🔍 Looking for product containers...")
        containers = await page.evaluate('''() => {
            const allElements = document.querySelectorAll('*');
            const results = [];
            
            for (let elem of allElements) {
                const text = elem.innerText || '';
                // If element contains a price and a link to /itm/
                if (text.includes('£') && elem.querySelector('a[href*="/itm/"]')) {
                    results.push({
                        tag: elem.tagName,
                        className: elem.className,
                        id: elem.id,
                        childCount: elem.children.length
                    });
                    if (results.length >= 5) break;
                }
            }
            
            return results;
        }''')
        
        print("Found product containers:")
        for c in containers:
            print(f"  - <{c['tag']}> class='{c['className']}' id='{c['id']}' children={c['childCount']}")
        
        print("\nKeeping browser open for 10 seconds to inspect...")
        await page.wait_for_timeout(10000)
        await browser.close()

asyncio.run(debug())