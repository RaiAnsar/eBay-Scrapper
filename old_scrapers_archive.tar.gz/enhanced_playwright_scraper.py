#!/usr/bin/env python3
"""
Enhanced Playwright eBay Scraper
- Auto-detects total pages
- Extracts EAN numbers from product pages
- Handles multiple tasks efficiently
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import re
from typing import List, Dict, Optional

class EnhancedEbayScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        self.browser = None
        self.context = None
    
    async def initialize_browser(self):
        """Initialize browser once for multiple tasks"""
        if not self.browser:
            playwright = await async_playwright().start()
            self.browser = await playwright.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
            self.context = await self.browser.new_context(
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
    
    async def detect_total_pages(self, search_url: str) -> int:
        """Auto-detect how many pages are available for this search"""
        print("🔍 Detecting total pages available...")
        
        page = await self.context.new_page()
        try:
            await page.goto(search_url, wait_until='domcontentloaded', timeout=15000)
            await page.wait_for_timeout(2000)
            
            # Try to find pagination info
            total_pages = await page.evaluate('''() => {
                // Method 1: Look for pagination numbers
                const paginationElements = document.querySelectorAll('.pagination__item');
                if (paginationElements.length > 0) {
                    const lastPage = Array.from(paginationElements)
                        .map(el => parseInt(el.innerText))
                        .filter(n => !isNaN(n))
                        .sort((a, b) => b - a)[0];
                    if (lastPage) return lastPage;
                }
                
                // Method 2: Look for "X of Y pages" text
                const pageText = document.body.innerText.match(/of\\s+(\\d+)\\s+pages/i);
                if (pageText) return parseInt(pageText[1]);
                
                // Method 3: Look for result count and calculate pages
                const resultText = document.querySelector('.srp-controls__count-heading');
                if (resultText) {
                    const match = resultText.innerText.match(/([\\d,]+)\\s+results/i);
                    if (match) {
                        const totalResults = parseInt(match[1].replace(/,/g, ''));
                        // eBay shows max 60 items per page
                        return Math.min(Math.ceil(totalResults / 60), 100); // Cap at 100 pages
                    }
                }
                
                // Method 4: Check next button availability
                let currentPage = 1;
                const nextButtons = document.querySelectorAll('a[aria-label*="next"], .pagination__next');
                
                // If we can't determine, default to checking first 10 pages
                return 10;
            }''')
            
            print(f"✅ Detected {total_pages} pages available")
            return min(total_pages, 50)  # Cap at 50 pages for safety
            
        except Exception as e:
            print(f"⚠️ Could not detect total pages, defaulting to 5: {e}")
            return 5
        finally:
            await page.close()
    
    async def extract_ean_from_product_page(self, item_number: str) -> str:
        """Extract EAN from individual product page"""
        try:
            page = await self.context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1000)
            
            # Extract EAN using multiple methods
            ean = await page.evaluate('''() => {
                // Method 1: Look in item specifics
                const specifics = document.querySelectorAll('.ux-layout-section__item');
                for (let spec of specifics) {
                    const text = spec.innerText;
                    if (text.includes('EAN') || text.includes('UPC') || text.includes('ISBN')) {
                        const match = text.match(/\\d{8,13}/);
                        if (match) return match[0];
                    }
                }
                
                // Method 2: Look in description
                const description = document.querySelector('.vim-description-content');
                if (description) {
                    const eanMatch = description.innerText.match(/EAN[:\\s]*(\\d{8,13})/i);
                    if (eanMatch) return eanMatch[1];
                    
                    const upcMatch = description.innerText.match(/UPC[:\\s]*(\\d{8,13})/i);
                    if (upcMatch) return upcMatch[1];
                }
                
                // Method 3: Check structured data
                const scripts = document.querySelectorAll('script[type="application/ld+json"]');
                for (let script of scripts) {
                    try {
                        const data = JSON.parse(script.innerText);
                        if (data.gtin13) return data.gtin13;
                        if (data.gtin) return data.gtin;
                    } catch {}
                }
                
                return '';
            }''')
            
            await page.close()
            return ean or ''
            
        except Exception as e:
            return ''
    
    async def extract_all_images(self, item_number: str) -> Dict[str, str]:
        """Extract up to 4 image URLs from product page"""
        try:
            page = await self.context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1000)
            
            images = await page.evaluate('''() => {
                const imageUrls = [];
                
                // Method 1: Main image gallery
                const galleryImages = document.querySelectorAll('.ux-image-carousel-item img');
                galleryImages.forEach(img => {
                    const src = img.src || img.dataset.src;
                    if (src && !src.includes('placeholder')) {
                        imageUrls.push(src.replace(/s-l[0-9]+/, 's-l1600')); // Get high-res version
                    }
                });
                
                // Method 2: Thumbnail images
                if (imageUrls.length === 0) {
                    const thumbs = document.querySelectorAll('.ux-image-filmstrip-carousel-item img');
                    thumbs.forEach(img => {
                        const src = img.src || img.dataset.src;
                        if (src) imageUrls.push(src.replace(/s-l[0-9]+/, 's-l1600'));
                    });
                }
                
                // Method 3: Main product image
                if (imageUrls.length === 0) {
                    const mainImg = document.querySelector('.ux-image-carousel img');
                    if (mainImg) imageUrls.push(mainImg.src);
                }
                
                return imageUrls.slice(0, 4); // Return max 4 images
            }''')
            
            await page.close()
            
            return {
                'Image_URL_1': images[0] if len(images) > 0 else '',
                'Image_URL_2': images[1] if len(images) > 1 else '',
                'Image_URL_3': images[2] if len(images) > 2 else '',
                'Image_URL_4': images[3] if len(images) > 3 else ''
            }
            
        except Exception as e:
            return {'Image_URL_1': '', 'Image_URL_2': '', 'Image_URL_3': '', 'Image_URL_4': ''}
    
    async def scrape_url(self, search_url: str, max_pages: Optional[int] = None, extract_ean: bool = False, extract_description: bool = False, progress_callback=None):
        """Main scraping function with auto page detection"""
        self.start_time = datetime.now()
        
        # Initialize browser if not already done
        await self.initialize_browser()
        
        print("\n" + "="*70)
        print("🛒 Enhanced eBay Scraper")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        
        # Auto-detect pages if not specified
        if max_pages is None:
            max_pages = await self.detect_total_pages(search_url)
        
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        page = await self.context.new_page()
        
        for page_num in range(1, max_pages + 1):
            print(f"\n📄 Processing Page {page_num}/{max_pages}")
            print("-" * 40)
            
            # Construct URL for page
            if page_num == 1:
                url = search_url
            else:
                if '?' in search_url:
                    url = f"{search_url}&_pgn={page_num}"
                else:
                    url = f"{search_url}?_pgn={page_num}"
            
            try:
                print(f"   Loading: {url[:80]}...")
                await page.goto(url, wait_until='domcontentloaded', timeout=15000)
                await page.wait_for_timeout(2000)
                
                # Extract products
                products = await self.extract_products_from_page(page)
                
                # Filter duplicates and enrich with EAN if requested
                new_products = []
                for product in products:
                    item_num = product.get('Ebay_Item_Number', '')
                    if item_num and item_num not in self.seen_items:
                        self.seen_items.add(item_num)
                        
                        # Extract EAN if requested (adds time)
                        if extract_ean and item_num:
                            print(f"   📊 Fetching EAN for item {item_num}...")
                            product['EAN'] = await self.extract_ean_from_product_page(item_num)
                            
                            # Also get all 4 images
                            images = await self.extract_all_images(item_num)
                            product.update(images)
                        
                        # Extract description if requested
                        if extract_description and item_num:
                            print(f"   📝 Fetching description for item {item_num}...")
                            product['Description'] = await self.extract_product_description(item_num)
                        
                        new_products.append(product)
                        self.products_scraped += 1
                
                all_products.extend(new_products)
                
                print(f"✅ Found: {len(products)} items ({len(new_products)} new)")
                
                # Update progress callback if provided
                if progress_callback:
                    await progress_callback(page_num, len(all_products))
                
                # Show sample titles
                for i, p in enumerate(new_products[:2], 1):
                    print(f"   {i}. {p['Title'][:60]}...")
                    if p.get('EAN'):
                        print(f"      EAN: {p['EAN']}")
                
                # Stop if no more products found
                if len(products) == 0:
                    print("   ℹ️ No more products found, stopping early")
                    break
                
            except Exception as e:
                print(f"❌ Error on page {page_num}: {e}")
            
            # Rate limiting
            if page_num < max_pages:
                await page.wait_for_timeout(1500)
        
        await page.close()
        
        # Show final report
        self.show_final_report(all_products)
        
        return all_products
    
    async def extract_products_from_page(self, page):
        """Extract products from current page"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // Find product elements - try multiple selectors
            let productElements = document.querySelectorAll('li[data-viewport]');
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('.s-item');
            }
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('li[id*="item"]');
            }
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('[data-gr4]');
            }
            
            console.log('Found elements:', productElements.length);
            
            productElements.forEach((item) => {
                try {
                    const itemText = item.innerText || '';
                    if (itemText.includes('SPONSORED') || itemText.includes('Shop on eBay')) {
                        return;
                    }
                    
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    const itemNumber = itemMatch[1];
                    
                    // Get title
                    let title = '';
                    const h3 = item.querySelector('h3');
                    if (h3) {
                        title = h3.innerText.trim();
                    } else {
                        const titleElem = item.querySelector('.s-item__title');
                        if (titleElem) title = titleElem.innerText.trim();
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    // Get first image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    // Get condition
                    let condition = '';
                    const conditionElem = item.querySelector('.SECONDARY_INFO');
                    if (conditionElem) {
                        condition = conditionElem.innerText.trim();
                    }
                    
                    // Get shipping
                    let shipping = '';
                    const shippingElem = item.querySelector('.s-item__shipping');
                    if (shippingElem) {
                        shipping = shippingElem.innerText.trim();
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemNumber,
                        image: image,
                        condition: condition,
                        shipping: shipping
                    });
                    
                } catch (e) {}
            });
            
            return items;
        }''')
        
        # Convert to our format
        formatted_products = []
        for p in products:
            formatted_products.append({
                'Title': p.get('title', ''),
                'Price': p.get('price', ''),
                'Ebay_Item_Number': p.get('item_number', ''),
                'EAN': '',  # Will be filled if extract_ean is True
                'Image_URL_1': p.get('image', ''),
                'Image_URL_2': '',
                'Image_URL_3': '',
                'Image_URL_4': '',
                'Condition': p.get('condition', ''),
                'Shipping': p.get('shipping', ''),
                'URL': f"https://www.ebay.co.uk/itm/{p.get('item_number', '')}",
                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
        
        return formatted_products
    
    async def extract_product_description(self, item_number: str) -> str:
        """Extract and clean product description from product page"""
        try:
            page = await self.context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            await page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
            await page.wait_for_timeout(1500)
            
            # Extract and clean description
            description = await page.evaluate('''() => {
                // Try multiple selectors for description
                let descText = '';
                
                // Method 1: iframe description
                const iframe = document.querySelector('iframe#desc_ifr');
                if (iframe) {
                    try {
                        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                        descText = iframeDoc.body.innerText || iframeDoc.body.textContent || '';
                    } catch (e) {
                        // Cross-origin iframe
                    }
                }
                
                // Method 2: Direct description div
                if (!descText) {
                    const descDiv = document.querySelector('.vim-description-content, .vim-d-description, .d-item-description');
                    if (descDiv) {
                        descText = descDiv.innerText || descDiv.textContent || '';
                    }
                }
                
                // Method 3: Tab panel description
                if (!descText) {
                    const tabPanel = document.querySelector('[role="tabpanel"][aria-labelledby*="description"]');
                    if (tabPanel) {
                        descText = tabPanel.innerText || '';
                    }
                }
                
                // Clean the text
                if (descText) {
                    // Remove excessive whitespace but preserve paragraph breaks
                    descText = descText
                        .replace(/[\r\n]+/g, '\n\n')
                        .replace(/[ \t]+/g, ' ')
                        .replace(/\n{3,}/g, '\n\n')
                        .trim();
                    
                    // Remove common boilerplate text
                    const boilerplates = [
                        /\\[\\d{1,2}\\/\\d{1,2}\\/\\d{4},\\s*\\d{1,2}:\\d{2}:\\d{2}\\s*[AP]M\\]/gi,
                        /Shipping and handling.*/gi,
                        /Returns?.*/gi,
                        /Refund.*/gi,
                        /Payment method.*/gi,
                        /Seller assumes all responsibility.*/gi,
                        /Business seller information.*/gi,
                        /Please leave feedback.*/gi,
                        /Visit my eBay store.*/gi
                    ];
                    
                    for (let pattern of boilerplates) {
                        descText = descText.replace(pattern, '');
                    }
                    
                    descText = descText.replace(/\n{3,}/g, '\n\n').trim();
                }
                
                return descText;
            }''')
            
            await page.close()
            return description or ''
            
        except Exception as e:
            print(f"   ⚠️ Could not extract description: {e}")
            return ''
    
    async def scrape_multiple_urls(self, urls: List[str], extract_ean: bool = False):
        """Scrape multiple URLs as separate tasks"""
        await self.initialize_browser()
        
        all_results = {}
        
        print("\n" + "="*70)
        print(f"🛒 Processing {len(urls)} separate search URLs")
        print("="*70 + "\n")
        
        for i, url in enumerate(urls, 1):
            print(f"\n{'='*70}")
            print(f"📌 Task {i}/{len(urls)}")
            print(f"{'='*70}")
            
            # Reset for each task
            self.seen_items.clear()
            self.products_scraped = 0
            
            # Scrape this URL
            products = await self.scrape_url(url, max_pages=None, extract_ean=extract_ean)
            
            # Store results
            all_results[url] = {
                'products': products,
                'count': len(products),
                'timestamp': datetime.now()
            }
            
            # Save individual Excel file
            if products:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"ebay_task_{i}_{timestamp}.xlsx"
                df = pd.DataFrame(products)
                df.to_excel(f"scraping_results/{filename}", index=False)
                all_results[url]['filename'] = filename
                print(f"💾 Saved to: {filename}")
        
        # Close browser
        if self.browser:
            await self.browser.close()
        
        return all_results
    
    def show_final_report(self, products):
        """Show final scraping report"""
        elapsed = datetime.now() - self.start_time
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {len(products)}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"⏱️  Total time: {str(elapsed).split('.')[0]}")
        print(f"⚡ Average rate: {len(products)/(elapsed.total_seconds()/60):.1f} products/minute")
        
        # Check EAN extraction rate
        ean_count = sum(1 for p in products if p.get('EAN'))
        if ean_count > 0:
            print(f"📊 EAN numbers found: {ean_count}/{len(products)} ({ean_count*100/len(products):.1f}%)")
        
        print("="*70 + "\n")


async def main():
    """Test the enhanced scraper"""
    scraper = EnhancedEbayScraper()
    
    # Test single URL with auto page detection
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=playstation+5"
    
    print("Testing auto page detection and EAN extraction...")
    products = await scraper.scrape_url(url, max_pages=2, extract_ean=True)
    
    if products:
        # Save results
        df = pd.DataFrame(products)
        filename = f"enhanced_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        df.to_excel(filename, index=False)
        print(f"💾 Results saved to: {filename}")
        
        # Show sample with EAN
        print("\n📋 Sample results with EAN:")
        for i, product in enumerate(products[:3], 1):
            print(f"\n{i}. {product['Title'][:60]}...")
            print(f"   💰 {product['Price']}")
            print(f"   📊 EAN: {product.get('EAN', 'Not found')}")
            print(f"   🔢 Item: {product['Ebay_Item_Number']}")
    
    # Close browser
    if scraper.browser:
        await scraper.browser.close()


if __name__ == "__main__":
    asyncio.run(main())