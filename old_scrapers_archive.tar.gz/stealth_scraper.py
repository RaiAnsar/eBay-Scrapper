#!/usr/bin/env python3
"""
Stealth eBay Scraper - Bypasses detection
- Uses stealth techniques to avoid detection
- Properly extracts EAN and descriptions
- Optimized for stability
"""

import asyncio
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout
import pandas as pd
from datetime import datetime
import re
from typing import List, Dict, Optional
import random

class StealthEbayScraper:
    def __init__(self, max_workers=2):  # Only 2 workers for stealth
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        self.browser = None
        self.playwright = None
        self.max_workers = max_workers
        self.context_pool = []
        
    async def initialize(self):
        """Initialize browser with stealth settings"""
        self.playwright = await async_playwright().start()
        
        # Launch with stealth settings
        self.browser = await self.playwright.chromium.launch(
            headless=True,  # Can use headless with proper stealth
            args=[
                '--disable-blink-features=AutomationControlled',
                '--disable-web-security',
                '--disable-features=IsolateOrigins,site-per-process',
                '--disable-dev-shm-usage',
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote'
            ]
        )
        
        # Different user agents for each context
        user_agents = [
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]
        
        for i in range(self.max_workers):
            context = await self.browser.new_context(
                user_agent=user_agents[i % len(user_agents)],
                viewport={'width': 1920, 'height': 1080},
                locale='en-GB',
                timezone_id='Europe/London',
                ignore_https_errors=True
            )
            
            # Add stealth scripts to each context
            await context.add_init_script("""
                // Override webdriver detection
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
                
                // Mock Chrome object
                window.chrome = {
                    runtime: {},
                    loadTimes: function() {},
                    csi: function() {}
                };
                
                // Mock permissions
                const originalQuery = window.navigator.permissions.query;
                window.navigator.permissions.query = (parameters) => (
                    parameters.name === 'notifications' ?
                        Promise.resolve({state: Notification.permission}) :
                        originalQuery(parameters)
                );
                
                // Mock plugins
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [
                        {0: {type: "application/x-google-chrome-pdf", suffixes: "pdf"}},
                        {0: {type: "application/pdf", suffixes: "pdf"}}
                    ]
                });
                
                // Mock languages
                Object.defineProperty(navigator, 'languages', {
                    get: () => ['en-GB', 'en']
                });
            """)
            
            self.context_pool.append(context)
    
    async def close(self):
        """Close all contexts and browser"""
        for context in self.context_pool:
            await context.close()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
    
    async def scrape_url(self, search_url: str, max_pages: int = 10, 
                        extract_ean: bool = False, extract_description: bool = False,
                        progress_callback=None):
        """Main scraping function with stealth mode"""
        self.start_time = datetime.now()
        await self.initialize()
        
        print("\n" + "="*70)
        print("🥷 STEALTH eBay Scraper - Undetectable Mode")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"🔧 Workers: {self.max_workers}")
        print(f"📊 Extract EAN: {extract_ean}")
        print(f"📝 Extract Description: {extract_description}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        
        # Use first context for search pages
        search_page = await self.context_pool[0].new_page()
        
        # Add random delay to seem human
        await search_page.wait_for_timeout(random.randint(1000, 3000))
        
        for page_num in range(1, max_pages + 1):
            print(f"\n📄 Processing Page {page_num}/{max_pages}")
            print("-" * 40)
            
            if progress_callback:
                await progress_callback(page_num, len(all_products))
            
            # Construct URL
            if page_num == 1:
                url = search_url
            else:
                url = f"{search_url}&_pgn={page_num}" if '?' in search_url else f"{search_url}?_pgn={page_num}"
            
            try:
                print(f"   Loading: {url[:80]}...")
                
                # Navigate and handle challenge if needed
                response = await search_page.goto(url, wait_until='domcontentloaded', timeout=20000)
                
                # Check if we hit a challenge page
                if 'challenge' in response.url:
                    print("   ⚠️ Challenge detected, waiting...")
                    await search_page.wait_for_timeout(5000)
                    # Try to continue
                    await search_page.goto(url, wait_until='domcontentloaded', timeout=20000)
                
                # Wait for content
                await search_page.wait_for_timeout(random.randint(2000, 4000))
                
                # Extract products
                products = await self.extract_products_from_page(search_page)
                
                # Filter duplicates
                new_products = []
                for product in products:
                    item_num = product.get('Ebay_Item_Number', '')
                    if item_num and item_num not in self.seen_items:
                        self.seen_items.add(item_num)
                        new_products.append(product)
                
                print(f"✅ Found: {len(products)} items ({len(new_products)} new)")
                
                # Process details if requested
                if (extract_ean or extract_description) and new_products:
                    print(f"🔄 Fetching details for {len(new_products)} products...")
                    
                    # Process sequentially with delays to avoid detection
                    success_count = 0
                    for i, product in enumerate(new_products, 1):
                        item_num = product.get('Ebay_Item_Number', '')
                        if not item_num:
                            continue
                        
                        print(f"   [{i}/{len(new_products)}] Processing {item_num}...", end='', flush=True)
                        
                        # Use second context for details
                        context_idx = 1 if len(self.context_pool) > 1 else 0
                        result = await self.fetch_product_details_stealth(
                            item_num,
                            self.context_pool[context_idx],
                            extract_ean,
                            extract_description
                        )
                        
                        if result:
                            product.update(result)
                            if result.get('EAN') or result.get('Description'):
                                success_count += 1
                                print(" ✓")
                            else:
                                print(" -")
                        else:
                            print(" ✗")
                        
                        # Random delay between products
                        await asyncio.sleep(random.uniform(1, 3))
                    
                    print(f"   ✨ Successfully extracted details for {success_count}/{len(new_products)} products")
                
                all_products.extend(new_products)
                self.products_scraped += len(new_products)
                
                if progress_callback:
                    await progress_callback(page_num, len(all_products))
                
                if len(products) == 0:
                    print("   ℹ️ No more products found, stopping")
                    break
                    
            except Exception as e:
                print(f"❌ Error on page {page_num}: {str(e)[:100]}")
            
            # Rate limiting between pages
            if page_num < max_pages:
                await search_page.wait_for_timeout(random.randint(3000, 5000))
        
        await search_page.close()
        await self.close()
        
        # Final report
        duration = (datetime.now() - self.start_time).total_seconds()
        rate = (self.products_scraped / duration * 60) if duration > 0 else 0
        
        ean_count = sum(1 for p in all_products if p.get('EAN'))
        desc_count = sum(1 for p in all_products if p.get('Description'))
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {self.products_scraped}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"📊 Products with EAN: {ean_count}/{len(all_products)}")
        print(f"📝 Products with Description: {desc_count}/{len(all_products)}")
        print(f"⏱️  Total time: {int(duration//60)}:{int(duration%60):02d}")
        print(f"⚡ Average rate: {rate:.1f} products/minute")
        print("="*70 + "\n")
        
        return all_products
    
    async def fetch_product_details_stealth(self, item_number: str, context,
                                           extract_ean: bool, extract_description: bool):
        """Fetch product details with stealth mode"""
        result = {}
        page = None
        
        try:
            page = await context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            # Add delay before navigation
            await page.wait_for_timeout(random.randint(500, 1500))
            
            # Navigate to product
            await page.goto(product_url, wait_until='domcontentloaded', timeout=15000)
            await page.wait_for_timeout(random.randint(1500, 3000))
            
            # Extract data
            data = await page.evaluate('''(extractEan, extractDesc) => {
                const result = {};
                
                if (extractEan) {
                    let ean = '';
                    
                    // Check all text on page for EAN
                    const bodyText = document.body.innerText || '';
                    const eanMatch = bodyText.match(/\\bEAN[:\\s]*(\\d{13}|\\d{8})\\b/i);
                    if (eanMatch) {
                        ean = eanMatch[1];
                    }
                    
                    result.ean = ean;
                }
                
                if (extractDesc) {
                    let desc = '';
                    
                    // Try multiple selectors for description
                    const selectors = [
                        '.vim-description-content',
                        '[data-testid="item-description"]',
                        '.d-item-description',
                        '#viTabs_0_panel'
                    ];
                    
                    for (let sel of selectors) {
                        const elem = document.querySelector(sel);
                        if (elem && elem.innerText) {
                            desc = elem.innerText;
                            break;
                        }
                    }
                    
                    // Clean description
                    if (desc) {
                        desc = desc
                            .replace(/\\[(\\d{1,2}\\/\\d{1,2}\\/\\d{4}),\\s*\\d{1,2}:\\d{2}:\\d{2}\\s*[AP]M\\]/gi, '')
                            .replace(/(Shipping|Returns?|Payment|Postage).*/gis, '')
                            .replace(/\\n{3,}/g, '\\n\\n')
                            .trim()
                            .substring(0, 1500);
                    }
                    
                    result.description = desc;
                }
                
                return result;
            }''', extract_ean, extract_description)
            
            if extract_ean:
                result['EAN'] = data.get('ean', '')
            if extract_description:
                result['Description'] = data.get('description', '')
            
        except Exception as e:
            # Silent fail
            pass
        finally:
            if page:
                await page.close()
        
        return result
    
    async def extract_products_from_page(self, page):
        """Extract products from search page"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // Try multiple selectors
            let productElements = document.querySelectorAll('li[data-viewport]');
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('.s-item');
            }
            
            productElements.forEach((item) => {
                try {
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    // Get title
                    let title = '';
                    const titleElem = item.querySelector('h3, [role="heading"], .s-item__title');
                    if (titleElem) {
                        title = titleElem.innerText.trim();
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Skip sponsored
                    if (item.innerText && item.innerText.includes('SPONSORED')) return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price, [class*="price"]');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    // Get image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemMatch[1],
                        image: image
                    });
                } catch (e) {}
            });
            
            return items;
        }''')
        
        # Format products
        return [{
            'Title': p['title'],
            'Price': p['price'],
            'Ebay_Item_Number': p['item_number'],
            'EAN': '',
            'Description': '',
            'Image_URL_1': p['image'],
            'Image_URL_2': '',
            'Image_URL_3': '',
            'Image_URL_4': '',
            'Condition': '',
            'Shipping': '',
            'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}",
            'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        } for p in products]

# Test
if __name__ == "__main__":
    async def test():
        scraper = StealthEbayScraper(max_workers=2)
        products = await scraper.scrape_url(
            "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray",
            max_pages=1,
            extract_ean=True,
            extract_description=True
        )
        
        if products:
            df = pd.DataFrame(products)
            filename = f"stealth_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(filename, index=False)
            print(f"📁 Saved to: {filename}")
    
    asyncio.run(test())