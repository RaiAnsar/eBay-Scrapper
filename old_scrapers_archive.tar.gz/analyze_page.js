#!/usr/bin/env node

/**
 * Analyze eBay Page Architecture
 * Understand the DOM structure and selectors
 */

const puppeteer = require('puppeteer');

async function analyzePage(url) {
    console.log('🔍 Analyzing eBay Page Architecture\n');
    console.log('URL:', url);
    console.log('='.repeat(80));

    const browser = await puppeteer.launch({
        headless: false, // Show browser to see what's happening
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });

    console.log('\n📄 Loading page...');
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Analyze page structure
    const analysis = await page.evaluate(() => {
        const report = {
            title: document.title,
            url: window.location.href,
            selectors: {},
            counts: {},
            samples: {}
        };

        // Check for results count
        const countElements = [
            'h1.srp-controls__count-heading',
            '.srp-controls__count-heading',
            'h1[class*="count"]',
            '.rsHdr h1',
            '.srp-results'
        ];

        for (const selector of countElements) {
            const elem = document.querySelector(selector);
            if (elem) {
                report.counts[selector] = elem.innerText.trim();
            }
        }

        // Check for product selectors
        const productSelectors = [
            'li[data-viewport]',
            '.s-item',
            'div.s-item__wrapper',
            'li.s-item',
            '.srp-results li[id^="item"]',
            'li[id*="item"]',
            'div[data-listing-id]',
            '.sresult',
            'li[class*="result"]'
        ];

        for (const selector of productSelectors) {
            const elements = document.querySelectorAll(selector);
            report.selectors[selector] = {
                count: elements.length,
                hasProducts: elements.length > 0
            };

            // Get sample of first item
            if (elements.length > 0) {
                const first = elements[0];
                report.samples[selector] = {
                    html: first.outerHTML.substring(0, 500),
                    text: first.innerText.substring(0, 200),
                    classes: first.className,
                    id: first.id
                };

                // Check for title
                const titleSelectors = ['h3', '.s-item__title', 'a[class*="title"]', 'span[role="heading"]'];
                for (const ts of titleSelectors) {
                    const title = first.querySelector(ts);
                    if (title) {
                        report.samples[selector].title = title.innerText;
                        break;
                    }
                }

                // Check for price
                const priceSelectors = ['.s-item__price', 'span[class*="price"]', '.lvprice'];
                for (const ps of priceSelectors) {
                    const price = first.querySelector(ps);
                    if (price) {
                        report.samples[selector].price = price.innerText;
                        break;
                    }
                }

                // Check for link
                const link = first.querySelector('a[href*="/itm/"]');
                if (link) {
                    report.samples[selector].link = link.href;
                }
            }
        }

        // Check for pagination
        report.pagination = {
            hasNext: !!document.querySelector('a[aria-label*="next page"]'),
            hasPrev: !!document.querySelector('a[aria-label*="prev page"]'),
            currentPage: document.querySelector('.pagination__item--selected')?.innerText || '1'
        };

        // Check for no results message
        const noResultsSelectors = [
            '.srp-save-null-search',
            '.srp-river-answer',
            '.no-results',
            '[class*="no-result"]'
        ];

        for (const selector of noResultsSelectors) {
            const elem = document.querySelector(selector);
            if (elem) {
                report.noResults = elem.innerText;
            }
        }

        // Check what layout/view is being used
        report.viewType = {
            isList: !!document.querySelector('.srp-view-options__list'),
            isGallery: !!document.querySelector('.srp-view-options__gallery'),
            isGrid: !!document.querySelector('[class*="grid-view"]')
        };

        return report;
    });

    // Print analysis
    console.log('\n📊 PAGE ANALYSIS RESULTS:');
    console.log('='.repeat(80));
    
    console.log('\n🔢 Result Counts:');
    for (const [selector, count] of Object.entries(analysis.counts)) {
        console.log(`  ${selector}: "${count}"`);
    }

    console.log('\n🎯 Product Selectors Found:');
    for (const [selector, info] of Object.entries(analysis.selectors)) {
        if (info.hasProducts) {
            console.log(`  ✅ ${selector}: ${info.count} elements`);
        }
    }

    console.log('\n❌ Selectors NOT Found:');
    for (const [selector, info] of Object.entries(analysis.selectors)) {
        if (!info.hasProducts) {
            console.log(`  ❌ ${selector}: 0 elements`);
        }
    }

    console.log('\n📦 Sample Products:');
    for (const [selector, sample] of Object.entries(analysis.samples)) {
        console.log(`\n  Selector: ${selector}`);
        console.log(`  Title: ${sample.title || 'Not found'}`);
        console.log(`  Price: ${sample.price || 'Not found'}`);
        console.log(`  Link: ${sample.link || 'Not found'}`);
        console.log(`  Classes: ${sample.classes}`);
        console.log(`  ID: ${sample.id}`);
    }

    console.log('\n📄 Pagination:');
    console.log(`  Current Page: ${analysis.pagination.currentPage}`);
    console.log(`  Has Next: ${analysis.pagination.hasNext}`);
    console.log(`  Has Previous: ${analysis.pagination.hasPrev}`);

    if (analysis.noResults) {
        console.log('\n⚠️  No Results Message Found:');
        console.log(`  ${analysis.noResults}`);
    }

    // Take screenshot
    await page.screenshot({ path: 'ebay_page_analysis.png', fullPage: false });
    console.log('\n📸 Screenshot saved: ebay_page_analysis.png');

    // Save HTML for inspection
    const html = await page.content();
    require('fs').writeFileSync('ebay_page.html', html);
    console.log('📄 HTML saved: ebay_page.html');

    await browser.close();
    console.log('\n✅ Analysis complete!');
}

// Run analysis
const url = process.argv[2] || 'https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0&_from=R40&LH_PrefLoc=1&LH_ItemCondition=1000&LH_BIN=1&LH_FS=1&Format=DVD%7C4K%2520UHD%2520Blu%252Dray%7CBlu%252Dray%7CBlu%252Dray%25203D&rt=nc&Genre=Horror&_dcat=617';

analyzePage(url).catch(console.error);