#!/usr/bin/env python3
"""
BeautifulSoup eBay Scraper - Simpler approach without browser automation
Based on the code you shared, optimized for UK eBay and EAN extraction
"""

import requests
from bs4 import BeautifulSoup
import time
import pandas as pd
from datetime import datetime
import re

class SoupEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-GB,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0'
        })
        self.products = []
        self.seen_items = set()

    def scrape_product_page(self, url, item_number):
        """Scrape individual product page for EAN and description"""
        try:
            print(f"      Fetching: {item_number}...", end='')
            response = self.session.get(url, timeout=10)
            if response.status_code != 200:
                print(f" ❌ Status: {response.status_code}")
                return None, None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract EAN - multiple strategies
            ean = None
            description = None
            
            # Strategy 1: Look for EAN in item specifics
            specifics = soup.find('div', class_='ux-layout-section--itemSpecifics')
            if not specifics:
                specifics = soup.find('div', {'class': re.compile('itemSpecifics')})
            
            if specifics:
                # Look for EAN in text
                text = specifics.get_text()
                ean_match = re.search(r'\bEAN[:\s]*(\d{13})\b', text, re.IGNORECASE)
                if ean_match:
                    ean = ean_match.group(1)
                    print(f" ✅ EAN: {ean}", end='')
                
                # Also check for UPC
                if not ean:
                    upc_match = re.search(r'\bUPC[:\s]*(\d{12})\b', text, re.IGNORECASE)
                    if upc_match:
                        ean = upc_match.group(1)
                        print(f" ✅ UPC: {ean}", end='')
            
            # Strategy 2: Check in labels-values sections
            if not ean:
                labels = soup.find_all('div', class_='ux-labels-values__labels')
                values = soup.find_all('div', class_='ux-labels-values__values')
                
                for label, value in zip(labels, values):
                    label_text = label.get_text().strip()
                    if 'EAN' in label_text or 'UPC' in label_text:
                        ean = value.get_text().strip()
                        print(f" ✅ {label_text}: {ean}", end='')
                        break
            
            # Strategy 3: Check h2 with itemprop
            if not ean:
                gtin = soup.find('h2', {'itemprop': 'gtin13'})
                if gtin:
                    ean = gtin.get_text().strip()
                    print(f" ✅ GTIN: {ean}", end='')
            
            # Extract description
            desc_elem = soup.find('div', class_='vim-description-content')
            if not desc_elem:
                desc_elem = soup.find('div', {'data-testid': 'item-description'})
            if not desc_elem:
                desc_elem = soup.find('div', id='viTabs_0_panel')
            
            if desc_elem:
                description = desc_elem.get_text().strip()[:1000]
                print(f" ✅ Desc: {len(description)} chars", end='')
            
            print()  # New line
            return ean, description
            
        except Exception as e:
            print(f" ❌ Error: {str(e)[:50]}")
            return None, None

    def scrape_search_results(self, url, max_pages=5, extract_details=True):
        """Scrape eBay search results with pagination"""
        
        print("\n" + "="*70)
        print("🍲 BeautifulSoup eBay Scraper")
        print("="*70)
        print(f"📍 URL: {url}")
        print(f"📄 Max pages: {max_pages}")
        print(f"📊 Extract details: {extract_details}")
        print("="*70 + "\n")
        
        for page_num in range(1, max_pages + 1):
            print(f"\n📄 Page {page_num}")
            print("-" * 40)
            
            # Build URL with pagination and 200 items per page
            if page_num == 1:
                page_url = f"{url}&_ipg=200"
            else:
                page_url = f"{url}&_ipg=200&_pgn={page_num}"
            
            try:
                response = self.session.get(page_url, timeout=15)
                if response.status_code != 200:
                    print(f"❌ Failed to load page: {response.status_code}")
                    continue
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Find all product listings - exclude the first 2 which are usually headers
                all_listings = soup.find_all('li', {'data-viewport': True})
                if not all_listings:
                    all_listings = soup.find_all('li', class_='s-item')
                
                # Skip first 2 items (usually "Shop on eBay" placeholders)
                listings = all_listings[2:] if len(all_listings) > 2 else all_listings
                
                print(f"📦 Found {len(listings)} products on page (after filtering)")
                
                new_products = []
                for listing in listings:
                    # Note: BeautifulSoup might not see SPONSORED tags properly
                    # Let's be less strict for now
                    # listing_text = listing.get_text()
                    # if 'SPONSORED' in listing_text:
                    #     continue
                    
                    # Extract product URL and item number
                    link_elem = listing.find('a', {'href': re.compile(r'/itm/\d+')})
                    if not link_elem:
                        # print(f"   No link found in listing")
                        continue
                    
                    product_url = link_elem['href']
                    if not product_url.startswith('http'):
                        product_url = 'https://www.ebay.co.uk' + product_url
                    
                    # Extract item number
                    item_match = re.search(r'/itm/(\d+)', product_url)
                    if not item_match:
                        continue
                    
                    item_number = item_match.group(1)
                    
                    # Skip if already seen
                    if item_number in self.seen_items:
                        continue
                    
                    self.seen_items.add(item_number)
                    
                    # Extract title - multiple strategies
                    title = 'No title'
                    
                    # Try standard selectors
                    title_elem = listing.find('h3', class_='s-item__title')
                    if not title_elem:
                        title_elem = listing.find('div', class_='s-item__title')
                    if not title_elem:
                        title_elem = listing.find('h3')
                    if not title_elem:
                        # For new card layout
                        title_elem = listing.find('span', {'data-testid': 's-item__title'})
                    
                    if title_elem:
                        # Get text, removing any nested spans
                        title_text = title_elem.get_text(separator=' ', strip=True)
                        if title_text:
                            title = title_text
                    
                    # Skip non-product items
                    if title in ['Shop on eBay', 'New Listing', 'No title'] or title.startswith('Shop on'):
                        continue
                    
                    # Extract price
                    price_elem = listing.find('span', class_='s-item__price')
                    price = price_elem.get_text().strip() if price_elem else ''
                    
                    # Extract condition
                    condition_elem = listing.find('span', class_='SECONDARY_INFO')
                    condition = condition_elem.get_text().strip() if condition_elem else ''
                    
                    # Extract shipping
                    shipping_elem = listing.find('span', class_='s-item__shipping')
                    shipping = shipping_elem.get_text().strip() if shipping_elem else ''
                    
                    # Extract image
                    img_elem = listing.find('img')
                    image = ''
                    if img_elem:
                        image = img_elem.get('src', '') or img_elem.get('data-src', '')
                        # Get larger image
                        image = image.replace('s-l140', 's-l500').replace('s-l64', 's-l500')
                    
                    product = {
                        'Ebay_Item_Number': item_number,
                        'Title': title,
                        'Price': price,
                        'Condition': condition,
                        'Shipping': shipping,
                        'Image_URL': image,
                        'URL': product_url,
                        'EAN': '',
                        'Description': '',
                        'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    
                    new_products.append(product)
                
                print(f"✅ {len(new_products)} new products (skipped {len(listings)-len(new_products)} duplicates/sponsored)")
                
                # Extract details for some products
                if extract_details and new_products:
                    sample_size = min(5, len(new_products))  # Limit to 5 per page
                    print(f"🔍 Extracting details from {sample_size} products...")
                    
                    for product in new_products[:sample_size]:
                        ean, description = self.scrape_product_page(product['URL'], product['Ebay_Item_Number'])
                        if ean:
                            product['EAN'] = ean
                        if description:
                            product['Description'] = description
                        
                        time.sleep(2)  # Polite delay between requests
                
                self.products.extend(new_products)
                
                if len(listings) == 0:
                    print("📭 No more products found")
                    break
                
            except Exception as e:
                print(f"❌ Error on page {page_num}: {str(e)}")
            
            # Delay between pages
            if page_num < max_pages:
                print(f"⏳ Waiting 3 seconds...")
                time.sleep(3)
        
        return self.products

    def save_results(self):
        """Save results to Excel and CSV"""
        if self.products:
            df = pd.DataFrame(self.products)
            
            # Save Excel
            excel_file = f"ebay_soup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(excel_file, index=False)
            print(f"\n📁 Excel saved: {excel_file}")
            
            # Save CSV
            csv_file = excel_file.replace('.xlsx', '.csv')
            df.to_csv(csv_file, index=False)
            print(f"📁 CSV saved: {csv_file}")
            
            # Stats
            ean_count = sum(1 for p in self.products if p.get('EAN'))
            desc_count = sum(1 for p in self.products if p.get('Description'))
            
            print(f"\n📊 Results:")
            print(f"   Total: {len(self.products)} products")
            print(f"   With EAN: {ean_count} ({ean_count*100/len(self.products):.1f}%)")
            print(f"   With Description: {desc_count} ({desc_count*100/len(self.products):.1f}%)")
            
            return excel_file
        return None

# Main execution
if __name__ == "__main__":
    scraper = SoupEbayScraper()
    
    # Your search URL
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    # Scrape with BeautifulSoup
    products = scraper.scrape_search_results(
        search_url,
        max_pages=3,  # Test with 3 pages
        extract_details=True
    )
    
    # Save results
    scraper.save_results()
    
    print("\n✅ Scraping complete!")