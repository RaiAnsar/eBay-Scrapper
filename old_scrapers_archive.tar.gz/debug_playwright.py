#!/usr/bin/env python3
"""
Debug Playwright scraper to see what's happening
"""

import asyncio
from playwright.async_api import async_playwright

async def debug_scrape():
    print("Starting Playwright debug...")
    
    async with async_playwright() as p:
        # Launch visible browser
        browser = await p.chromium.launch(
            headless=False,  # Visible browser
            args=['--disable-blink-features=AutomationControlled']
        )
        
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        
        page = await context.new_page()
        
        print("1. Going to eBay UK...")
        await page.goto('https://www.ebay.co.uk')
        await page.wait_for_timeout(3000)
        
        # Try to accept cookies
        try:
            print("2. Accepting cookies...")
            await page.click('#gdpr-banner-accept', timeout=2000)
        except:
            print("   No cookie banner")
        
        # Search for blu ray
        print("3. Going to search page...")
        search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
        await page.goto(search_url)
        await page.wait_for_timeout(3000)
        
        print("4. Checking what's on the page...")
        
        # Method 1: Check for products with evaluate
        products_count = await page.evaluate('''() => {
            // Try different selectors
            let count = 0;
            
            // Check li with data-viewport
            const viewport_items = document.querySelectorAll('li[data-viewport]');
            console.log('data-viewport items:', viewport_items.length);
            
            // Check s-item class
            const s_items = document.querySelectorAll('.s-item');
            console.log('s-item items:', s_items.length);
            
            // Check for any product links
            const product_links = document.querySelectorAll('a[href*="/itm/"]');
            console.log('Product links:', product_links.length);
            
            // Return counts
            return {
                viewport: viewport_items.length,
                s_items: s_items.length,
                links: product_links.length,
                title: document.title
            };
        }''')
        
        print(f"   Page title: {products_count['title']}")
        print(f"   Items with data-viewport: {products_count['viewport']}")
        print(f"   Items with s-item class: {products_count['s_items']}")
        print(f"   Product links: {products_count['links']}")
        
        # Method 2: Try to extract first few products
        print("\n5. Trying to extract products...")
        products = await page.evaluate('''() => {
            const items = [];
            const elements = document.querySelectorAll('li[data-viewport]');
            
            for(let i = 0; i < Math.min(3, elements.length); i++) {
                const elem = elements[i];
                const link = elem.querySelector('a[href*="/itm/"]');
                
                if(link) {
                    const href = link.href;
                    
                    // Try to find title
                    let title = 'No title';
                    const titleElem = elem.querySelector('h3') || elem.querySelector('[role="heading"]');
                    if(titleElem) {
                        title = titleElem.innerText;
                    }
                    
                    items.push({
                        url: href,
                        title: title
                    });
                }
            }
            
            return items;
        }''')
        
        print(f"   Extracted {len(products)} products:")
        for p in products:
            print(f"     - {p['title'][:50]}")
        
        # Check for error pages
        print("\n6. Checking for blocks or errors...")
        page_text = await page.content()
        
        if 'Pardon our interruption' in page_text:
            print("   ⚠️ BLOCKED: 'Pardon our interruption' detected")
        elif 'Access Denied' in page_text:
            print("   ⚠️ BLOCKED: Access Denied")
        elif 'challenge' in page_text.lower():
            print("   ⚠️ BLOCKED: Challenge page detected")
        elif len(page_text) < 10000:
            print(f"   ⚠️ Page too small: {len(page_text)} bytes")
        else:
            print(f"   ✅ Page loaded: {len(page_text)} bytes")
        
        print("\n7. Taking screenshot...")
        await page.screenshot(path='ebay_debug.png')
        print("   Screenshot saved as ebay_debug.png")
        
        print("\nPress Enter to close browser...")
        input()
        
        await browser.close()

if __name__ == "__main__":
    asyncio.run(debug_scrape())