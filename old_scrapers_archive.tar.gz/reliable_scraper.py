#!/usr/bin/env python3
"""
Reliable eBay Scraper - Actually captures EAN and descriptions
- Sequential but reliable processing
- Proper error handling
- Saves progress as it goes
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import re
import json
import os

class ReliableEbayScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        self.browser = None
        self.context = None
        self.progress_file = None
        
    async def scrape_url(self, search_url: str, max_pages: int = 10, 
                        extract_ean: bool = False, extract_description: bool = False,
                        progress_callback=None):
        """Reliable scraping with actual data extraction"""
        self.start_time = datetime.now()
        self.progress_file = f"progress_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        print("\n" + "="*70)
        print("🎯 RELIABLE eBay Scraper - Quality over Speed")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"📊 Extract EAN: {extract_ean}")
        print(f"📝 Extract Description: {extract_description}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        
        async with async_playwright() as p:
            self.browser = await p.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
            
            self.context = await self.browser.new_context(
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            
            # Main search page
            search_page = await self.context.new_page()
            
            for page_num in range(1, max_pages + 1):
                print(f"\n📄 Processing Page {page_num}/{max_pages}")
                print("-" * 40)
                
                if progress_callback:
                    await progress_callback(page_num, len(all_products))
                
                # Construct URL
                if page_num == 1:
                    url = search_url
                else:
                    url = f"{search_url}&_pgn={page_num}" if '?' in search_url else f"{search_url}?_pgn={page_num}"
                
                try:
                    print(f"   Loading: {url[:80]}...")
                    await search_page.goto(url, wait_until='domcontentloaded', timeout=30000)
                    await search_page.wait_for_timeout(3000)
                    
                    # Wait for products
                    try:
                        await search_page.wait_for_selector('.s-item', timeout=5000)
                    except:
                        print("   ⚠️ No products found, checking alternative selectors...")
                    
                    # Extract products
                    products = await self.extract_products_from_page(search_page)
                    
                    # Filter duplicates
                    new_products = []
                    for product in products:
                        item_num = product.get('Ebay_Item_Number', '')
                        if item_num and item_num not in self.seen_items:
                            self.seen_items.add(item_num)
                            new_products.append(product)
                    
                    print(f"✅ Found: {len(products)} items ({len(new_products)} new)")
                    
                    # Process details SEQUENTIALLY for reliability
                    if (extract_ean or extract_description) and new_products:
                        print(f"📊 Processing {len(new_products)} products for details...")
                        
                        for i, product in enumerate(new_products, 1):
                            item_num = product.get('Ebay_Item_Number', '')
                            if not item_num:
                                continue
                            
                            print(f"   [{i}/{len(new_products)}] Processing {item_num}...", end='')
                            
                            try:
                                # Open product page
                                detail_page = await self.context.new_page()
                                product_url = f"https://www.ebay.co.uk/itm/{item_num}"
                                
                                await detail_page.goto(product_url, wait_until='domcontentloaded', timeout=10000)
                                await detail_page.wait_for_timeout(1500)
                                
                                # Extract both EAN and description
                                details = await detail_page.evaluate('''() => {
                                    const result = {};
                                    
                                    // Extract EAN
                                    let ean = '';
                                    const rows = document.querySelectorAll('.ux-layout-section__row, tr');
                                    for (let row of rows) {
                                        const text = row.innerText || '';
                                        if (text.includes('EAN')) {
                                            const match = text.match(/\\d{8,13}/);
                                            if (match) {
                                                ean = match[0];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    // Extract description
                                    let desc = '';
                                    const iframe = document.querySelector('iframe#desc_ifr');
                                    if (iframe) {
                                        try {
                                            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                                            desc = iframeDoc.body.innerText || '';
                                        } catch (e) {}
                                    }
                                    
                                    if (!desc) {
                                        const descDiv = document.querySelector('.vim-description-content');
                                        if (descDiv) desc = descDiv.innerText || '';
                                    }
                                    
                                    // Clean description
                                    if (desc) {
                                        desc = desc
                                            .replace(/\\[\\d{1,2}\\/\\d{1,2}\\/\\d{4},\\s*\\d{1,2}:\\d{2}:\\d{2}\\s*[AP]M\\]/gi, '')
                                            .replace(/Shipping.*/gi, '')
                                            .replace(/Returns?.*/gi, '')
                                            .trim()
                                            .substring(0, 1000);  // Limit to 1000 chars
                                    }
                                    
                                    return { ean: ean, description: desc };
                                }''')
                                
                                if extract_ean:
                                    product['EAN'] = details.get('ean', '')
                                    if product['EAN']:
                                        print(f" EAN: {product['EAN']}", end='')
                                
                                if extract_description:
                                    product['Description'] = details.get('description', '')
                                    if product['Description']:
                                        print(f" ✓", end='')
                                
                                await detail_page.close()
                                print()  # New line
                                
                                # Small delay to avoid rate limiting
                                await asyncio.sleep(0.5)
                                
                            except Exception as e:
                                print(f" ❌ Error: {str(e)[:50]}")
                    
                    all_products.extend(new_products)
                    self.products_scraped += len(new_products)
                    
                    # Save progress
                    self.save_progress(all_products)
                    
                    if progress_callback:
                        await progress_callback(page_num, len(all_products))
                    
                    # Stop if no products found
                    if len(products) == 0:
                        print("   ℹ️ No more products found, stopping")
                        break
                    
                except Exception as e:
                    print(f"❌ Error on page {page_num}: {e}")
                
                # Rate limiting between pages
                if page_num < max_pages:
                    await search_page.wait_for_timeout(2000)
            
            await self.browser.close()
        
        # Final report
        duration = (datetime.now() - self.start_time).total_seconds()
        rate = (self.products_scraped / duration * 60) if duration > 0 else 0
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {self.products_scraped}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"⏱️  Total time: {int(duration//60)}:{int(duration%60):02d}")
        print(f"⚡ Average rate: {rate:.1f} products/minute")
        
        # Count EAN and descriptions
        ean_count = sum(1 for p in all_products if p.get('EAN'))
        desc_count = sum(1 for p in all_products if p.get('Description'))
        print(f"📊 Products with EAN: {ean_count}/{len(all_products)}")
        print(f"📝 Products with Description: {desc_count}/{len(all_products)}")
        print("="*70 + "\n")
        
        return all_products
    
    def save_progress(self, products):
        """Save progress to file in case of crash"""
        with open(self.progress_file, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'count': len(products),
                'products': products
            }, f)
    
    async def extract_products_from_page(self, page):
        """Extract products from search page"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // Get all product elements
            const productElements = document.querySelectorAll('.s-item');
            
            productElements.forEach((item) => {
                try {
                    // Skip if no link
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    // Skip sponsored
                    const itemText = item.innerText || '';
                    if (itemText.includes('SPONSORED')) return;
                    
                    // Extract item number
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    const itemNumber = itemMatch[1];
                    
                    // Get title
                    let title = '';
                    const titleElem = item.querySelector('h3, .s-item__title');
                    if (titleElem) {
                        title = titleElem.innerText.trim();
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    }
                    
                    // Get image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemNumber,
                        image: image
                    });
                } catch (e) {}
            });
            
            return items;
        }''')
        
        # Format products
        return [{
            'Title': p['title'],
            'Price': p['price'],
            'Ebay_Item_Number': p['item_number'],
            'EAN': '',
            'Description': '',
            'Image_URL_1': p['image'],
            'Image_URL_2': '',
            'Image_URL_3': '',
            'Image_URL_4': '',
            'Condition': '',
            'Shipping': '',
            'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}",
            'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        } for p in products]

# Direct test
if __name__ == "__main__":
    async def test():
        scraper = ReliableEbayScraper()
        products = await scraper.scrape_url(
            "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray",
            max_pages=2,
            extract_ean=True,
            extract_description=True
        )
        
        if products:
            df = pd.DataFrame(products)
            filename = f"reliable_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(filename, index=False)
            print(f"📁 Saved to: {filename}")
    
    asyncio.run(test())