#!/usr/bin/env python3
"""
eBay Bulk Scraper - Production Ready
Handles search URLs and bulk product scraping
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from datetime import datetime
import re
import json

class eBayBulkScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-GB,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
    
    def extract_products_from_search(self, search_url_or_query, max_pages=1):
        """
        Extract product URLs from eBay search results
        Can handle both search queries and full search URLs
        """
        products = []
        
        # Check if it's a full URL or just a query
        if search_url_or_query.startswith('http'):
            # Parse the URL to get parameters
            base_url = search_url_or_query.split('?')[0]
            query = self._extract_query_from_url(search_url_or_query)
        else:
            base_url = "https://www.ebay.co.uk/sch/i.html"
            query = search_url_or_query
        
        print(f"🔍 Searching for: {query}")
        print(f"📄 Pages to process: {max_pages}\n")
        
        for page in range(1, max_pages + 1):
            print(f"Processing page {page}...")
            
            params = {
                '_nkw': query,
                '_pgn': page,
                '_ipg': 200  # 200 items per page
            }
            
            try:
                response = self.session.get(base_url, params=params, timeout=15)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Find all item containers
                items = soup.find_all('div', class_='s-item__wrapper')
                
                for item in items:
                    # Get the link
                    link_elem = item.find('a', class_='s-item__link')
                    if not link_elem:
                        continue
                    
                    href = link_elem.get('href', '')
                    if not href or '/itm/' not in href:
                        continue
                    
                    # Extract item ID from URL
                    item_id_match = re.search(r'/itm/(\d+)', href)
                    if not item_id_match:
                        continue
                    
                    item_id = item_id_match.group(1)
                    clean_url = f"https://www.ebay.co.uk/itm/{item_id}"
                    
                    # Get title
                    title_elem = item.find('div', class_='s-item__title')
                    title = title_elem.get_text(strip=True) if title_elem else ""
                    
                    # Skip promotional items
                    if 'Shop on eBay' in title or not title:
                        continue
                    
                    # Get price
                    price_elem = item.find('span', class_='s-item__price')
                    price = price_elem.get_text(strip=True) if price_elem else ""
                    
                    # Get condition
                    condition_elem = item.find('span', class_='SECONDARY_INFO')
                    condition = condition_elem.get_text(strip=True) if condition_elem else ""
                    
                    products.append({
                        'url': clean_url,
                        'item_id': item_id,
                        'title': title,
                        'price': price,
                        'condition': condition
                    })
                
                print(f"  Found {len([p for p in products if p['url'].endswith(str(page))])} items on page {page}")
                time.sleep(1)  # Respectful delay
                
            except Exception as e:
                print(f"  Error on page {page}: {e}")
        
        print(f"\n✅ Total products found: {len(products)}")
        return products
    
    def _extract_query_from_url(self, url):
        """Extract search query from eBay URL"""
        if '_nkw=' in url:
            query = url.split('_nkw=')[1].split('&')[0]
            return query.replace('+', ' ').replace('%20', ' ')
        return "blu ray"
    
    def scrape_product_details(self, product_url):
        """Scrape detailed information from a product page"""
        try:
            response = self.session.get(product_url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract detailed information
            details = {
                'url': product_url,
                'title': self._safe_extract(soup, 'h1.it-ttl', 'h1'),
                'price': self._extract_price(soup),
                'condition': self._safe_extract(soup, '.u-flL.condText'),
                'seller': self._safe_extract(soup, '.si-inner .mbg-nw'),
                'ean_upc': self._extract_ean_upc(soup),
                'brand': self._extract_specific(soup, 'Brand'),
                'mpn': self._extract_specific(soup, 'MPN'),
                'main_image': self._extract_main_image(soup),
                'shipping': self._safe_extract(soup, '.vi-acc-del-range'),
                'location': self._safe_extract(soup, '.vi-acc-del-range'),
                'returns': self._safe_extract(soup, '.vi-ret-accpt-txt'),
                'scraped_at': datetime.now().isoformat()
            }
            
            return details
            
        except Exception as e:
            print(f"  Error scraping {product_url}: {e}")
            return None
    
    def _safe_extract(self, soup, *selectors):
        """Safely extract text using multiple selectors"""
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get_text(strip=True)
        return ""
    
    def _extract_price(self, soup):
        """Extract price from various locations"""
        # Try meta tag
        price_meta = soup.find('meta', {'itemprop': 'price'})
        if price_meta and price_meta.get('content'):
            return f"£{price_meta['content']}"
        
        # Try price spans
        price_elem = soup.select_one('.x-price-primary, .vi-VR-cvipPrice')
        if price_elem:
            return price_elem.get_text(strip=True)
        
        return ""
    
    def _extract_ean_upc(self, soup):
        """Extract EAN or UPC from item specifics"""
        for row in soup.select('.ux-layout-section__row, .itemAttr tr'):
            text = row.get_text()
            if 'EAN' in text or 'UPC' in text:
                parts = text.split(':')
                if len(parts) > 1:
                    return parts[-1].strip()
        return ""
    
    def _extract_specific(self, soup, name):
        """Extract specific item attribute"""
        for row in soup.select('.ux-layout-section__row, .itemAttr tr'):
            if name in row.get_text():
                parts = row.get_text().split(':')
                if len(parts) > 1:
                    return parts[-1].strip()
        return ""
    
    def _extract_main_image(self, soup):
        """Extract main product image"""
        img = soup.select_one('#icImg, .ux-image-magnify__container img')
        return img.get('src', '') if img else ""
    
    def bulk_scrape(self, search_url_or_query, max_pages=1, max_products=None):
        """
        Main function to handle bulk scraping
        1. Gets products from search
        2. Scrapes each product's details
        3. Returns complete dataset
        """
        # Step 1: Get product list from search
        products = self.extract_products_from_search(search_url_or_query, max_pages)
        
        if not products:
            print("❌ No products found")
            return []
        
        # Limit products if specified
        if max_products:
            products = products[:max_products]
        
        # Step 2: Scrape each product
        print(f"\n📦 Scraping details for {len(products)} products...\n")
        
        detailed_products = []
        for i, product in enumerate(products, 1):
            print(f"[{i}/{len(products)}] Scraping: {product['title'][:50]}...")
            
            details = self.scrape_product_details(product['url'])
            
            if details:
                # Merge search info with detailed info
                details.update({
                    'search_title': product['title'],
                    'search_price': product['price'],
                    'item_id': product['item_id']
                })
                detailed_products.append(details)
            
            # Rate limiting
            if i < len(products):
                time.sleep(1.5)
        
        print(f"\n✅ Successfully scraped {len(detailed_products)} products")
        return detailed_products
    
    def save_results(self, products, filename=None):
        """Save results to Excel and CSV"""
        if not products:
            print("No products to save")
            return
        
        df = pd.DataFrame(products)
        
        # Generate filename if not provided
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_products_{timestamp}"
        
        # Save to Excel
        excel_file = f"{filename}.xlsx"
        df.to_excel(excel_file, index=False)
        print(f"📊 Saved to Excel: {excel_file}")
        
        # Save to CSV
        csv_file = f"{filename}.csv"
        df.to_csv(csv_file, index=False)
        print(f"📄 Saved to CSV: {csv_file}")
        
        return excel_file, csv_file


def main():
    """Example usage"""
    print("\n" + "="*60)
    print("🛒 eBay Bulk Scraper - Production Ready")
    print("="*60 + "\n")
    
    scraper = eBayBulkScraper()
    
    # Option 1: Use the exact URL you provided
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray+&_sacat=0&_from=R40&_trksid=m570.l1313"
    
    # Option 2: Or just use keywords
    # search_query = "blu ray"
    
    # Scrape products (adjust max_pages and max_products as needed)
    products = scraper.bulk_scrape(
        search_url,
        max_pages=2,      # Scrape 2 pages of results
        max_products=10   # But limit to 10 products total
    )
    
    # Save results
    if products:
        scraper.save_results(products)
        
        # Display summary
        print("\n" + "="*60)
        print("📋 Sample Results:")
        print("="*60)
        
        for i, product in enumerate(products[:5], 1):
            print(f"\n{i}. {product.get('title', 'No title')[:60]}...")
            print(f"   💰 Price: {product.get('price', 'N/A')}")
            print(f"   📦 Condition: {product.get('condition', 'N/A')}")
            print(f"   🔢 EAN/UPC: {product.get('ean_upc', 'N/A')}")
            print(f"   👤 Seller: {product.get('seller', 'N/A')}")


if __name__ == "__main__":
    main()