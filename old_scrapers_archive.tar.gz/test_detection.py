#!/usr/bin/env python3
"""
Test if eBay is detecting automation
"""

import asyncio
from playwright.async_api import async_playwright

async def test():
    async with async_playwright() as p:
        # Launch with stealth mode
        browser = await p.chromium.launch(
            headless=False,  # Show browser to see what's happening
            args=[
                '--disable-blink-features=AutomationControlled',
                '--disable-features=site-per-process',
                '--disable-dev-shm-usage'
            ]
        )
        
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            viewport={'width': 1920, 'height': 1080},
            locale='en-GB',
            timezone_id='Europe/London'
        )
        
        # Add stealth scripts
        await context.add_init_script("""
            // Remove webdriver property
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
            
            // Remove automation indicators
            window.chrome = {
                runtime: {}
            };
            
            // Remove plugins check
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });
        """)
        
        page = await context.new_page()
        
        print("Loading eBay...")
        response = await page.goto('https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray', wait_until='domcontentloaded')
        print(f"Response status: {response.status}")
        print(f"Response URL: {response.url}")
        
        await page.wait_for_timeout(5000)
        
        # Check if we got redirected
        current_url = page.url
        print(f"Current URL: {current_url}")
        
        # Check page title
        title = await page.title()
        print(f"Page title: {title}")
        
        # Check if captcha or security page
        captcha = await page.evaluate('''() => {
            const text = document.body.innerText || '';
            return {
                hasCaptcha: text.includes('captcha') || text.includes('CAPTCHA'),
                hasSecurityCheck: text.includes('security') || text.includes('Security'),
                hasRobotCheck: text.includes('robot') || text.includes('Robot'),
                bodyTextSample: text.substring(0, 200)
            };
        }''')
        
        print(f"Security checks: {captcha}")
        
        # Try to find products
        products = await page.evaluate('''() => {
            return {
                liDataViewport: document.querySelectorAll('li[data-viewport]').length,
                sItem: document.querySelectorAll('.s-item').length,
                links: document.querySelectorAll('a[href*="/itm/"]').length
            };
        }''')
        
        print(f"Elements found: {products}")
        
        print("\nKeeping browser open for 10 seconds to inspect...")
        await page.wait_for_timeout(10000)
        
        await browser.close()

asyncio.run(test())