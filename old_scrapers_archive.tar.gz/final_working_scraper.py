#!/usr/bin/env python3
"""
FINAL WORKING eBay Scraper - handles the new s-card structure
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import time
import re
import json

class FinalEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        # Use the Chrome headers that worked
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'Cache-Control': 'max-age=0',
        })
        self.products = []
        self.seen_items = set()
        self.checkpoint_file = 'checkpoint.json'
        
    def save_checkpoint(self, page_num):
        """Save progress"""
        checkpoint = {
            'page': page_num,
            'products_count': len(self.products),
            'seen_items': list(self.seen_items),
            'timestamp': datetime.now().isoformat()
        }
        with open(self.checkpoint_file, 'w') as f:
            json.dump(checkpoint, f)
    
    def load_checkpoint(self):
        """Load previous progress"""
        try:
            with open(self.checkpoint_file, 'r') as f:
                checkpoint = json.load(f)
                self.seen_items = set(checkpoint['seen_items'])
                print(f"📚 Resuming from page {checkpoint['page']}, {checkpoint['products_count']} products already scraped")
                return checkpoint['page']
        except:
            return 0
    
    def extract_product_details(self, url):
        """Extract EAN and description from product page"""
        try:
            headers = {'Referer': 'https://www.ebay.co.uk/sch/i.html'}
            response = self.session.get(url, headers=headers, timeout=15)
            
            if response.status_code != 200:
                return None, None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            ean = None
            description = None
            
            # Look for EAN everywhere
            full_text = soup.get_text()
            ean_patterns = [
                r'EAN[:\s]+(\d{13})',
                r'EAN\s*(\d{13})',
                r'(\d{13})\s*EAN',
            ]
            
            for pattern in ean_patterns:
                match = re.search(pattern, full_text, re.IGNORECASE)
                if match:
                    ean = match.group(1)
                    break
            
            # Also check for UPC (12 digits)
            if not ean:
                upc_match = re.search(r'UPC[:\s]+(\d{12})', full_text, re.IGNORECASE)
                if upc_match:
                    ean = upc_match.group(1)
            
            # Extract description - multiple attempts
            desc_selectors = [
                {'data-testid': 'x-item-description'},
                {'class': 'vim-description-content'},
                {'id': 'viTabs_0_panel'},
                {'class': 'd-item-description'}
            ]
            
            for selector in desc_selectors:
                desc_elem = soup.find('div', selector)
                if desc_elem:
                    description = desc_elem.get_text().strip()[:1000]
                    break
            
            return ean, description
            
        except Exception as e:
            return None, None
    
    def scrape_search_page(self, url, page_num=1):
        """Scrape a single search results page"""
        
        # Build URL with pagination
        if '?' in url:
            if page_num == 1:
                page_url = f"{url}&_ipg=200"
            else:
                page_url = f"{url}&_ipg=200&_pgn={page_num}"
        else:
            if page_num == 1:
                page_url = f"{url}?_ipg=200"
            else:
                page_url = f"{url}?_ipg=200&_pgn={page_num}"
        
        print(f"\n📄 Page {page_num}")
        print("-" * 40)
        
        try:
            response = self.session.get(page_url, timeout=30)
            if response.status_code != 200:
                print(f"❌ Failed to load page: {response.status_code}")
                return []
            
            soup = BeautifulSoup(response.text, 'html.parser')
            products_found = []
            
            # Find ALL items with proper class matching
            items = []
            
            # Method 1: Find by class containing 's-card'
            all_li = soup.find_all('li')
            for li in all_li:
                classes = li.get('class', [])
                if any('s-card' in c for c in classes):
                    items.append(li)
            
            # If no s-card items, try old structure
            if not items:
                items = soup.find_all('li', class_='s-item')
            
            # If still nothing, try data-viewport
            if not items:
                items = soup.find_all('li', {'data-viewport': True})
            
            print(f"📦 Found {len(items)} total items")
            
            # Skip first 2 if they're "Shop on eBay" placeholders
            if len(items) > 2:
                first_link = items[0].find('a', href=re.compile(r'/itm/'))
                if first_link:
                    first_title = first_link.get_text(strip=True)
                    if 'Shop on eBay' in first_title:
                        items = items[2:]
                        print(f"   Skipped 2 header items, processing {len(items)} products")
            
            for item in items:
                # Find product link
                link = item.find('a', href=re.compile(r'/itm/\d+'))
                if not link:
                    continue
                
                href = link.get('href', '')
                if not href.startswith('http'):
                    href = 'https://www.ebay.co.uk' + href
                
                # Clean URL (remove tracking params)
                href = href.split('?')[0] if '?' in href else href
                
                # Extract item number
                item_match = re.search(r'/itm/(\d+)', href)
                if not item_match:
                    continue
                
                item_number = item_match.group(1)
                
                # Skip if already seen
                if item_number in self.seen_items:
                    continue
                
                self.seen_items.add(item_number)
                
                # Extract title from various places
                title = ''
                
                # For s-card items
                title_elem = item.find('span', class_='s-item__title--tag-value')
                if not title_elem:
                    title_elem = item.find('div', class_='s-item__title')
                if not title_elem:
                    title_elem = item.find('h3', class_='s-item__title')
                if not title_elem:
                    # Try finding any heading
                    title_elem = item.find('span', {'role': 'heading'})
                
                if title_elem:
                    title = title_elem.get_text(strip=True)
                
                # Skip non-products
                if not title or 'Shop on eBay' in title:
                    continue
                
                # Extract price
                price_elem = item.find('span', class_='s-item__price')
                price = price_elem.get_text(strip=True) if price_elem else ''
                
                # Extract condition
                condition_elem = item.find('span', class_='SECONDARY_INFO')
                condition = condition_elem.get_text(strip=True) if condition_elem else ''
                
                # Extract shipping
                shipping_elem = item.find('span', class_='s-item__shipping')
                shipping = shipping_elem.get_text(strip=True) if shipping_elem else ''
                
                # Extract image
                img_elem = item.find('img')
                image = ''
                if img_elem:
                    image = img_elem.get('src') or img_elem.get('data-src') or ''
                    # Get larger image
                    image = image.replace('s-l140', 's-l500').replace('s-l225', 's-l500')
                
                product = {
                    'Ebay_Item_Number': item_number,
                    'Title': title,
                    'Price': price,
                    'Condition': condition,
                    'Shipping': shipping,
                    'Image_URL': image,
                    'URL': f"https://www.ebay.co.uk/itm/{item_number}",
                    'EAN': '',
                    'Description': '',
                    'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                products_found.append(product)
            
            print(f"✅ Extracted {len(products_found)} new products")
            return products_found
            
        except Exception as e:
            print(f"❌ Error on page {page_num}: {e}")
            return []
    
    def scrape(self, search_url, max_pages=5, extract_details=True):
        """Main scraping function"""
        
        print("\n" + "="*70)
        print("🚀 FINAL WORKING eBay Scraper")
        print("="*70)
        print(f"📍 URL: {search_url}")
        print(f"📄 Max pages: {max_pages}")
        print(f"📊 Extract details: {extract_details}")
        print("="*70)
        
        # Load checkpoint
        start_page = self.load_checkpoint()
        
        for page_num in range(start_page + 1, max_pages + 1):
            page_products = self.scrape_search_page(search_url, page_num)
            
            if page_products:
                # Extract details for some products
                if extract_details and page_products:
                    sample_size = min(3, len(page_products))
                    print(f"🔍 Extracting details from {sample_size} products...")
                    
                    for i, product in enumerate(page_products[:sample_size], 1):
                        print(f"   [{i}/{sample_size}] {product['Title'][:40]}...")
                        ean, desc = self.extract_product_details(product['URL'])
                        
                        if ean:
                            product['EAN'] = ean
                            print(f"      ✅ EAN: {ean}")
                        if desc:
                            product['Description'] = desc
                            print(f"      ✅ Description: {len(desc)} chars")
                        
                        time.sleep(2)  # Polite delay
                
                self.products.extend(page_products)
                
                # Save checkpoint every 3 pages
                if page_num % 3 == 0:
                    self.save_checkpoint(page_num)
                    print(f"💾 Checkpoint saved at page {page_num}")
            
            if not page_products:
                print("📭 No more products found")
                break
            
            # Delay between pages
            if page_num < max_pages:
                delay = 3
                print(f"⏳ Waiting {delay} seconds...")
                time.sleep(delay)
        
        return self.save_results()
    
    def save_results(self):
        """Save results to files"""
        if self.products:
            df = pd.DataFrame(self.products)
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            excel_file = f"ebay_final_{timestamp}.xlsx"
            csv_file = f"ebay_final_{timestamp}.csv"
            
            df.to_excel(excel_file, index=False)
            df.to_csv(csv_file, index=False)
            
            # Stats
            total = len(self.products)
            with_ean = sum(1 for p in self.products if p.get('EAN'))
            with_desc = sum(1 for p in self.products if p.get('Description'))
            
            print(f"\n" + "="*70)
            print("📊 FINAL RESULTS")
            print("="*70)
            print(f"✅ Total products: {total}")
            if total > 0:
                print(f"📊 With EAN: {with_ean} ({with_ean*100/total:.1f}%)")
                print(f"📝 With Description: {with_desc} ({with_desc*100/total:.1f}%)")
            print(f"📁 Excel saved: {excel_file}")
            print(f"📁 CSV saved: {csv_file}")
            print("="*70)
            
            return excel_file
        return None

# Test the scraper
if __name__ == "__main__":
    scraper = FinalEbayScraper()
    
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    result_file = scraper.scrape(
        search_url,
        max_pages=5,  # Test with 5 pages
        extract_details=True
    )
    
    if result_file:
        print(f"\n✅ SUCCESS! Results saved to: {result_file}")
