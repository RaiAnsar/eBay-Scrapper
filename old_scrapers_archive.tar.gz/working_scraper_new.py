#!/usr/bin/env python3
"""
WORKING eBay Scraper with proper headers
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import time
import re
import json

class WorkingEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        # Use the Chrome headers that worked
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'Cache-Control': 'max-age=0',
        })
        self.products = []
        self.seen_items = set()
    
    def extract_product_details(self, url):
        """Extract EAN and description from product page"""
        try:
            # Add referer for product pages
            headers = {
                'Referer': 'https://www.ebay.co.uk/sch/i.html',
            }
            
            response = self.session.get(url, headers=headers, timeout=15)
            if response.status_code != 200:
                return None, None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            ean = None
            description = None
            
            # Find EAN in various locations
            # Method 1: Item specifics section
            specifics_section = soup.find('section', {'data-testid': 'x-about-this-item'})
            if specifics_section:
                text = specifics_section.get_text()
                ean_match = re.search(r'EAN[:\s]+(\d{13})', text, re.IGNORECASE)
                if ean_match:
                    ean = ean_match.group(1)
            
            # Method 2: Check all divs with labels-values
            if not ean:
                for row in soup.find_all('div', class_='ux-labels-values__labels-content'):
                    if 'EAN' in row.get_text():
                        value = row.find_next_sibling('div', class_='ux-labels-values__values-content')
                        if value:
                            ean_text = value.get_text().strip()
                            if re.match(r'^\d{13}$', ean_text):
                                ean = ean_text
                                break
            
            # Method 3: Check description for EAN
            desc_section = soup.find('div', {'data-testid': 'x-item-description'})
            if desc_section and not ean:
                desc_text = desc_section.get_text()
                ean_match = re.search(r'EAN[:\s]+(\d{13})', desc_text, re.IGNORECASE)
                if ean_match:
                    ean = ean_match.group(1)
            
            # Extract description
            if desc_section:
                description = desc_section.get_text().strip()[:1000]
            
            return ean, description
            
        except Exception as e:
            print(f"      Error fetching details: {str(e)[:50]}")
            return None, None
    
    def scrape_search_page(self, url, page_num=1):
        """Scrape a single search results page"""
        
        # Add pagination and items per page
        if page_num == 1:
            page_url = f"{url}&_ipg=200"
        else:
            page_url = f"{url}&_ipg=200&_pgn={page_num}"
        
        print(f"\n📄 Page {page_num}")
        print("-" * 40)
        
        try:
            response = self.session.get(page_url, timeout=30)
            if response.status_code != 200:
                print(f"❌ Failed to load page: {response.status_code}")
                return []
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all product containers
            products_found = []
            
            # Method 1: data-viewport items
            items = soup.find_all('li', {'data-viewport': True})
            print(f"📦 Found {len(items)} items with data-viewport")
            
            # Skip first 2 items (usually headers/ads)
            items = items[2:] if len(items) > 2 else items
            
            for item in items:
                # Find the product link
                link = item.find('a', href=re.compile(r'/itm/\d+'))
                if not link:
                    continue
                
                href = link.get('href', '')
                if not href.startswith('http'):
                    href = 'https://www.ebay.co.uk' + href
                
                # Extract item number
                item_match = re.search(r'/itm/(\d+)', href)
                if not item_match:
                    continue
                
                item_number = item_match.group(1)
                
                # Skip if already seen
                if item_number in self.seen_items:
                    continue
                
                self.seen_items.add(item_number)
                
                # Extract title - look in the link first
                title = ''
                title_elem = link.find('span', {'role': 'heading'})
                if not title_elem:
                    title_elem = link.find('h3')
                if not title_elem:
                    title_elem = item.find('h3', class_='s-item__title')
                if not title_elem:
                    title_elem = item.find('div', class_='s-item__title')
                
                if title_elem:
                    title = title_elem.get_text(strip=True)
                
                # Skip non-products
                if not title or 'Shop on eBay' in title:
                    continue
                
                # Extract price
                price_elem = item.find('span', class_='s-item__price')
                price = price_elem.get_text(strip=True) if price_elem else ''
                
                # Extract condition
                condition_elem = item.find('span', class_='SECONDARY_INFO')
                condition = condition_elem.get_text(strip=True) if condition_elem else ''
                
                # Extract image
                img_elem = item.find('img')
                image = ''
                if img_elem:
                    image = img_elem.get('src') or img_elem.get('data-src') or ''
                    # Get larger image
                    image = image.replace('s-l140', 's-l500').replace('s-l225', 's-l500')
                
                product = {
                    'Ebay_Item_Number': item_number,
                    'Title': title,
                    'Price': price,
                    'Condition': condition,
                    'Image_URL': image,
                    'URL': href,
                    'EAN': '',
                    'Description': ''
                }
                
                products_found.append(product)
            
            print(f"✅ Extracted {len(products_found)} new products")
            return products_found
            
        except Exception as e:
            print(f"❌ Error on page {page_num}: {e}")
            return []
    
    def scrape(self, search_url, max_pages=5, extract_details=True):
        """Main scraping function"""
        
        print("\n" + "="*70)
        print("🚀 WORKING eBay Scraper with Proper Headers")
        print("="*70)
        print(f"📍 URL: {search_url}")
        print(f"📄 Max pages: {max_pages}")
        print(f"📊 Extract details: {extract_details}")
        print("="*70)
        
        for page_num in range(1, max_pages + 1):
            page_products = self.scrape_search_page(search_url, page_num)
            
            if page_products:
                # Extract details for some products
                if extract_details:
                    sample_size = min(3, len(page_products))
                    print(f"🔍 Extracting details from {sample_size} products...")
                    
                    for i, product in enumerate(page_products[:sample_size], 1):
                        print(f"   [{i}/{sample_size}] {product['Title'][:40]}...")
                        ean, desc = self.extract_product_details(product['URL'])
                        
                        if ean:
                            product['EAN'] = ean
                            print(f"      ✅ EAN: {ean}")
                        if desc:
                            product['Description'] = desc
                            print(f"      ✅ Description: {len(desc)} chars")
                        
                        time.sleep(2)  # Polite delay
                
                self.products.extend(page_products)
            
            if not page_products:
                print("📭 No more products found")
                break
            
            # Delay between pages
            if page_num < max_pages:
                print(f"⏳ Waiting 3 seconds...")
                time.sleep(3)
        
        return self.save_results()
    
    def save_results(self):
        """Save results to files"""
        if self.products:
            df = pd.DataFrame(self.products)
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            excel_file = f"ebay_working_{timestamp}.xlsx"
            csv_file = f"ebay_working_{timestamp}.csv"
            
            df.to_excel(excel_file, index=False)
            df.to_csv(csv_file, index=False)
            
            # Stats
            total = len(self.products)
            with_ean = sum(1 for p in self.products if p.get('EAN'))
            with_desc = sum(1 for p in self.products if p.get('Description'))
            
            print(f"\n" + "="*70)
            print("📊 RESULTS SUMMARY")
            print("="*70)
            print(f"✅ Total products: {total}")
            print(f"📊 With EAN: {with_ean} ({with_ean*100/total:.1f}%)" if total else "")
            print(f"📝 With Description: {with_desc} ({with_desc*100/total:.1f}%)" if total else "")
            print(f"📁 Excel saved: {excel_file}")
            print(f"📁 CSV saved: {csv_file}")
            print("="*70)
            
            return excel_file
        return None

# Test the scraper
if __name__ == "__main__":
    scraper = WorkingEbayScraper()
    
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    result_file = scraper.scrape(
        search_url,
        max_pages=3,
        extract_details=True
    )
    
    if result_file:
        print(f"\n✅ Scraping complete! Check: {result_file}")