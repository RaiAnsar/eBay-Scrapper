#!/usr/bin/env python3
"""
Debug BeautifulSoup scraper to see what's being found
"""

import requests
from bs4 import BeautifulSoup
import re

# Setup session
session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-GB,en;q=0.9',
})

url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_ipg=200"

print(f"Fetching: {url}")
response = session.get(url, timeout=15)
print(f"Status: {response.status_code}")

soup = BeautifulSoup(response.text, 'html.parser')

# Check what selectors work
print("\n=== Selector Test ===")
print(f"li[data-viewport]: {len(soup.find_all('li', {'data-viewport': True}))} items")
print(f"li.s-item: {len(soup.find_all('li', class_='s-item'))} items")
print(f"div.s-item__wrapper: {len(soup.find_all('div', class_='s-item__wrapper'))} items")

# Try to find product links
links = soup.find_all('a', {'href': re.compile(r'/itm/\d+')})
print(f"\nProduct links found: {len(links)}")

# Show first few products
listings = soup.find_all('li', {'data-viewport': True})
if not listings:
    listings = soup.find_all('li', class_='s-item')

print(f"\nFirst 3 products:")
for i, listing in enumerate(listings[:3], 1):
    print(f"\n{i}. Listing HTML snippet:")
    print(str(listing)[:500])
    
    # Try to extract title
    title_elem = listing.find('h3', class_='s-item__title')
    if not title_elem:
        title_elem = listing.find('h3')
    if not title_elem:
        title_elem = listing.find('div', class_='s-item__title')
    
    if title_elem:
        print(f"   Title: {title_elem.get_text().strip()[:50]}")
    else:
        print("   Title: NOT FOUND")
    
    # Try to extract link
    link = listing.find('a', {'href': re.compile(r'/itm/')})
    if link:
        href = link.get('href', '')
        print(f"   Link: {href[:100]}")
        item_match = re.search(r'/itm/(\d+)', href)
        if item_match:
            print(f"   Item #: {item_match.group(1)}")
    else:
        print("   Link: NOT FOUND")
    
    # Check for SPONSORED
    if 'SPONSORED' in listing.get_text():
        print("   ⚠️ Contains SPONSORED")