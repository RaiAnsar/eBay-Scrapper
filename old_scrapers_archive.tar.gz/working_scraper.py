#!/usr/bin/env python3
"""
Working eBay Scraper - Handles current eBay structure
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from datetime import datetime
import re
import json

class WorkingEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        # Use a more realistic user agent
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0',
        })
    
    def test_scrape(self, search_url):
        """Test scraping with your exact URL"""
        print("\n" + "="*60)
        print("🔍 Testing eBay Scraper")
        print("="*60 + "\n")
        
        # Parse the URL
        if '_nkw=' in search_url:
            query = search_url.split('_nkw=')[1].split('&')[0]
            query = query.replace('+', ' ').replace('%20', ' ')
        else:
            query = "blu ray"
        
        print(f"📍 URL: {search_url}")
        print(f"🔍 Query: {query}\n")
        
        # Make the request
        print("📡 Fetching page...")
        response = self.session.get(search_url)
        
        if response.status_code == 200:
            print("✅ Page loaded successfully\n")
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Debug: Check what we're getting
            print("🔍 Analyzing page structure...")
            
            # Method 1: Look for s-item containers
            items_v1 = soup.find_all('div', {'class': 's-item__wrapper'})
            print(f"  Found {len(items_v1)} items with s-item__wrapper")
            
            # Method 2: Look for s-item class
            items_v2 = soup.find_all('div', class_=re.compile('s-item(?!.*s-item--watch)'))
            print(f"  Found {len(items_v2)} items with s-item class")
            
            # Method 3: Look for listing items
            items_v3 = soup.select('[data-gr4="1"]')
            print(f"  Found {len(items_v3)} items with data-gr4")
            
            # Method 4: Find by item links
            item_links = soup.find_all('a', href=re.compile(r'/itm/\d+'))
            print(f"  Found {len(item_links)} item links\n")
            
            # Extract products
            products = []
            
            # Try to extract from item links
            for link in item_links[:10]:  # First 10 items
                href = link.get('href', '')
                
                # Skip if not a product link
                if not '/itm/' in href:
                    continue
                
                # Extract item number
                item_match = re.search(r'/itm/(\d+)', href)
                if not item_match:
                    continue
                
                item_number = item_match.group(1)
                
                # Get the parent container
                parent = link.find_parent('div', class_='s-item__wrapper') or link.find_parent('li') or link.find_parent('div')
                
                if parent:
                    # Extract title
                    title_elem = parent.find(['span', 'div', 'h3'], class_=re.compile('s-item__title'))
                    title = title_elem.get_text(strip=True) if title_elem else ""
                    
                    # Skip if it's a shop link
                    if 'Shop on eBay' in title or not title:
                        continue
                    
                    # Extract price
                    price_elem = parent.find('span', class_=re.compile('s-item__price'))
                    price = price_elem.get_text(strip=True) if price_elem else ""
                    
                    # Extract image
                    img_elem = parent.find('img')
                    image = img_elem.get('src', '') if img_elem else ""
                    
                    # Extract condition
                    condition_elem = parent.find('span', class_='SECONDARY_INFO')
                    condition = condition_elem.get_text(strip=True) if condition_elem else ""
                    
                    products.append({
                        'Title': title,
                        'Price': price,
                        'Ebay_Item_Number': item_number,
                        'URL': f"https://www.ebay.co.uk/itm/{item_number}",
                        'Image_URL': image,
                        'Condition': condition
                    })
                    
                    print(f"✅ Found: {title[:50]}...")
            
            print(f"\n📊 Total products extracted: {len(products)}")
            
            if products:
                # Save to file
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"ebay_test_{timestamp}.xlsx"
                df = pd.DataFrame(products)
                df.to_excel(filename, index=False)
                print(f"💾 Saved to: {filename}")
                
                # Show sample
                print("\n📋 Sample Results:")
                for i, p in enumerate(products[:3], 1):
                    print(f"\n{i}. {p['Title'][:60]}...")
                    print(f"   Price: {p['Price']}")
                    print(f"   Item #: {p['Ebay_Item_Number']}")
            
            return products
        else:
            print(f"❌ Failed to load page: Status {response.status_code}")
            return []


def main():
    scraper = WorkingEbayScraper()
    
    # Your exact URL
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0&_from=R40&_trksid=m570.l1313"
    
    products = scraper.test_scrape(url)
    
    if not products:
        print("\n⚠️  No products found. eBay might have changed their structure.")
        print("Try using the Playwright version or check if the URL is correct.")

if __name__ == "__main__":
    main()