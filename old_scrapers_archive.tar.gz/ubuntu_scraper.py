#!/usr/bin/env python3
"""
eBay Scraper Optimized for Ubuntu 24.04 LTS
- Uses Selenium with Chrome/Firefox
- Resource-conscious (single browser instance)
- Automatic memory management
- Works on low-spec servers
"""

import os
import sys
import time
import json
import csv
import gc
import psutil
from datetime import datetime
from typing import List, Dict, Optional
import logging

# Selenium imports
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class UbuntuEbayScraper:
    """Lightweight eBay scraper for Ubuntu servers"""
    
    def __init__(self, browser='chrome', headless=True, max_memory_mb=512):
        """
        Initialize scraper with resource limits
        
        Args:
            browser: 'chrome' or 'firefox'
            headless: Run without GUI
            max_memory_mb: Maximum memory usage in MB
        """
        self.browser_type = browser
        self.headless = headless
        self.max_memory_mb = max_memory_mb
        self.driver = None
        self.products = []
        
    def check_memory(self):
        """Check if memory usage is within limits"""
        process = psutil.Process(os.getpid())
        mem_usage = process.memory_info().rss / 1024 / 1024  # MB
        
        if mem_usage > self.max_memory_mb:
            logger.warning(f"Memory usage ({mem_usage:.1f}MB) exceeds limit ({self.max_memory_mb}MB)")
            # Force garbage collection
            gc.collect()
            
            # If still over limit, restart browser
            if mem_usage > self.max_memory_mb * 1.2:
                logger.info("Restarting browser to free memory...")
                self.restart_browser()
                
        return mem_usage
    
    def setup_chrome(self):
        """Setup Chrome with minimal resource usage"""
        options = ChromeOptions()
        
        if self.headless:
            options.add_argument('--headless=new')
        
        # Resource-saving options
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_argument('--disable-web-security')
        options.add_argument('--disable-features=VizDisplayCompositor')
        options.add_argument('--disable-software-rasterizer')
        
        # Memory optimization
        options.add_argument('--memory-pressure-off')
        options.add_argument('--max_old_space_size=512')
        options.add_argument('--js-flags="--max-old-space-size=512"')
        
        # Disable images and unnecessary features
        prefs = {
            'profile.default_content_setting_values': {
                'images': 2,
                'plugins': 2,
                'popups': 2,
                'geolocation': 2,
                'notifications': 2,
                'media_stream': 2,
            }
        }
        options.add_experimental_option('prefs', prefs)
        
        # Anti-detection
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        return webdriver.Chrome(options=options)
    
    def setup_firefox(self):
        """Setup Firefox with minimal resource usage"""
        options = FirefoxOptions()
        
        if self.headless:
            options.add_argument('--headless')
        
        # Resource-saving preferences
        options.set_preference('dom.ipc.processCount', 1)
        options.set_preference('browser.tabs.remote.autostart', False)
        options.set_preference('browser.tabs.remote.autostart.2', False)
        options.set_preference('permissions.default.image', 2)  # Block images
        options.set_preference('dom.webnotifications.enabled', False)
        
        return webdriver.Firefox(options=options)
    
    def setup_browser(self):
        """Initialize browser with resource limits"""
        logger.info(f"Setting up {self.browser_type} browser...")
        
        if self.browser_type == 'chrome':
            self.driver = self.setup_chrome()
        else:
            self.driver = self.setup_firefox()
        
        # Set timeouts
        self.driver.set_page_load_timeout(30)
        self.driver.implicitly_wait(5)
        
        # Inject anti-detection script
        self.driver.execute_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
        """)
        
        logger.info("Browser setup complete")
    
    def restart_browser(self):
        """Restart browser to free memory"""
        if self.driver:
            self.driver.quit()
        gc.collect()
        time.sleep(2)
        self.setup_browser()
    
    def scrape_page(self, url: str, page_num: int) -> List[Dict]:
        """Scrape a single page with memory management"""
        products = []
        
        try:
            # Check memory before loading page
            mem_usage = self.check_memory()
            logger.info(f"Page {page_num} - Memory: {mem_usage:.1f}MB")
            
            self.driver.get(url)
            time.sleep(2)  # Gentle delay
            
            # Wait for listings to load
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, ".s-item__wrapper, li[data-viewport]"))
            )
            
            # Extract products using JavaScript (faster than Selenium methods)
            products = self.driver.execute_script("""
                const items = [];
                const listings = document.querySelectorAll('.s-item__wrapper, li[data-viewport]');
                
                for (const item of listings) {
                    // Skip sponsored items
                    if (item.textContent.includes('Shop on eBay')) continue;
                    
                    const title = item.querySelector('.s-item__title')?.textContent || '';
                    const price = item.querySelector('.s-item__price')?.textContent || '';
                    const link = item.querySelector('.s-item__link')?.href || '';
                    
                    if (title && price && link) {
                        const ebayIdMatch = link.match(/\\/(\\d+)\\?/);
                        items.push({
                            title: title.replace('New Listing', '').trim(),
                            price: price.trim(),
                            link: link,
                            ebay_id: ebayIdMatch ? ebayIdMatch[1] : '',
                            page: arguments[0]
                        });
                    }
                }
                
                return items;
            """, page_num)
            
            logger.info(f"Page {page_num}: Found {len(products)} products")
            
        except TimeoutException:
            logger.error(f"Page {page_num}: Timeout loading page")
        except Exception as e:
            logger.error(f"Page {page_num}: {str(e)}")
        
        return products
    
    def scrape_search(self, search_term: str, max_pages: int = 10, items_per_page: int = 200):
        """Main scraping method with automatic memory management"""
        self.setup_browser()
        self.products = []
        
        base_url = f"https://www.ebay.co.uk/sch/i.html?_nkw={search_term.replace(' ', '+')}&_ipg={items_per_page}"
        
        logger.info(f"Starting scrape: '{search_term}' for {max_pages} pages")
        
        for page in range(1, max_pages + 1):
            url = base_url if page == 1 else f"{base_url}&_pgn={page}"
            
            products = self.scrape_page(url, page)
            self.products.extend(products)
            
            # Stop if no products found
            if not products:
                logger.info(f"No products found on page {page}, stopping")
                break
            
            # Restart browser every 20 pages to prevent memory buildup
            if page % 20 == 0:
                logger.info("Restarting browser (scheduled)")
                self.restart_browser()
            
            # Be nice to eBay
            time.sleep(2)
        
        logger.info(f"Scraping complete: {len(self.products)} total products")
        
        # Clean up
        self.driver.quit()
        return self.products
    
    def extract_ean_lightweight(self, product_url: str) -> Optional[str]:
        """Extract EAN with minimal resource usage"""
        try:
            # Use a fresh page to avoid memory buildup
            self.driver.get(product_url)
            time.sleep(1)
            
            # Quick JavaScript extraction
            ean = self.driver.execute_script("""
                // Check item specifics
                const labels = document.querySelectorAll('.ux-labels-values__labels');
                for (const label of labels) {
                    if (label.textContent.match(/EAN|UPC|ISBN/i)) {
                        const value = label.nextElementSibling?.textContent;
                        if (value && /^\\d{8,13}$/.test(value.trim())) {
                            return value.trim();
                        }
                    }
                }
                return null;
            """)
            
            return ean
            
        except Exception as e:
            logger.debug(f"EAN extraction failed: {e}")
            return None
    
    def save_results(self, filename: str = None):
        """Save results to CSV and JSON"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_results_{timestamp}"
        
        # Save as CSV
        csv_file = f"{filename}.csv"
        with open(csv_file, 'w', newline='', encoding='utf-8') as f:
            if self.products:
                writer = csv.DictWriter(f, fieldnames=self.products[0].keys())
                writer.writeheader()
                writer.writerows(self.products)
        logger.info(f"Saved to CSV: {csv_file}")
        
        # Save as JSON
        json_file = f"{filename}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(self.products, f, indent=2, ensure_ascii=False)
        logger.info(f"Saved to JSON: {json_file}")
        
        return csv_file, json_file

def install_dependencies():
    """Install required packages on Ubuntu 24.04"""
    print("Installing dependencies for Ubuntu 24.04...")
    os.system("sudo apt-get update")
    os.system("sudo apt-get install -y python3-pip python3-venv chromium-browser chromium-chromedriver firefox-geckodriver")
    os.system("pip3 install --user selenium psutil")

def main():
    """CLI interface"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Lightweight eBay Scraper for Ubuntu')
    parser.add_argument('search', help='Search term (e.g., "blu ray")')
    parser.add_argument('--pages', type=int, default=10, help='Number of pages to scrape')
    parser.add_argument('--browser', choices=['chrome', 'firefox'], default='chrome', help='Browser to use')
    parser.add_argument('--ean', action='store_true', help='Extract EAN codes (slower)')
    parser.add_argument('--install', action='store_true', help='Install dependencies')
    
    args = parser.parse_args()
    
    if args.install:
        install_dependencies()
        return
    
    # Initialize scraper
    scraper = UbuntuEbayScraper(
        browser=args.browser,
        headless=True,
        max_memory_mb=512  # Limit to 512MB RAM
    )
    
    # Run scraping
    try:
        products = scraper.scrape_search(args.search, args.pages)
        
        # Optional: Extract EANs for first 20 products
        if args.ean and products:
            logger.info("Extracting EANs for first 20 products...")
            scraper.setup_browser()
            
            for i, product in enumerate(products[:20]):
                if i % 5 == 0:
                    scraper.check_memory()
                
                ean = scraper.extract_ean_lightweight(product['link'])
                if ean:
                    product['ean'] = ean
                    logger.info(f"Product {i+1}: EAN = {ean}")
            
            scraper.driver.quit()
        
        # Save results
        scraper.products = products
        scraper.save_results()
        
        print(f"\n✅ Success! Scraped {len(products)} products")
        
    except KeyboardInterrupt:
        logger.info("Scraping interrupted by user")
    except Exception as e:
        logger.error(f"Scraping failed: {e}")
    finally:
        if scraper.driver:
            scraper.driver.quit()

if __name__ == "__main__":
    main()