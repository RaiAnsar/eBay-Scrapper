#!/usr/bin/env python3
"""
Debug title extraction from eBay
"""

import requests
from bs4 import BeautifulSoup
import re

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
})

url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
print(f"Fetching: {url}")
response = session.get(url, timeout=15)
print(f"Status: {response.status_code}\n")

soup = BeautifulSoup(response.text, 'html.parser')

# Get all listings
all_listings = soup.find_all('li', {'data-viewport': True})
listings = all_listings[2:7] if len(all_listings) > 2 else all_listings  # Just check first 5 real items

print(f"Checking first 5 products (skipping first 2 placeholders):")
print("="*60)

for i, listing in enumerate(listings, 1):
    print(f"\nProduct {i}:")
    
    # Check structure
    classes = listing.get('class', [])
    print(f"  Classes: {' '.join(classes)}")
    
    # Find link
    link = listing.find('a', {'href': re.compile(r'/itm/\d+')})
    if link:
        href = link.get('href', '')
        item_match = re.search(r'/itm/(\d+)', href)
        if item_match:
            print(f"  Item #: {item_match.group(1)}")
    
    # Try all title strategies
    title = None
    
    # Method 1: h3.s-item__title
    elem = listing.find('h3', class_='s-item__title')
    if elem:
        title = elem.get_text(strip=True)
        print(f"  Title (h3.s-item__title): {title[:60]}")
    
    # Method 2: div.s-item__title
    if not title:
        elem = listing.find('div', class_='s-item__title')
        if elem:
            title = elem.get_text(strip=True)
            print(f"  Title (div.s-item__title): {title[:60]}")
    
    # Method 3: Any h3
    if not title:
        elem = listing.find('h3')
        if elem:
            title = elem.get_text(strip=True)
            print(f"  Title (h3): {title[:60]}")
    
    # Method 4: data-testid
    if not title:
        elem = listing.find('span', {'data-testid': 's-item__title'})
        if elem:
            title = elem.get_text(strip=True)
            print(f"  Title (span[data-testid]): {title[:60]}")
    
    # Method 5: Look for any span with role="heading"
    if not title:
        elem = listing.find('span', {'role': 'heading'})
        if elem:
            title = elem.get_text(strip=True)
            print(f"  Title (span[role=heading]): {title[:60]}")
    
    # Method 6: Check card title
    if not title:
        elem = listing.find('div', class_='su-card-header__title')
        if elem:
            title = elem.get_text(strip=True)
            print(f"  Title (card header): {title[:60]}")
    
    if not title:
        print(f"  ❌ NO TITLE FOUND")
        # Show some HTML to debug
        print(f"  HTML snippet: {str(listing)[:300]}...")