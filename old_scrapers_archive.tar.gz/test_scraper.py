#!/usr/bin/env python3
"""
Test script for eBay scraper
Tests basic functionality with a single product
"""

import asyncio
import logging
from ebay_scraper import eBayScraper

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def test_single_product():
    """Test scraping a single eBay product"""
    print("\n" + "="*60)
    print("eBay Scraper Test - Single Product")
    print("="*60 + "\n")
    
    # Test URL from the sample data
    test_url = "https://www.ebay.co.uk/itm/296667726490"
    
    print(f"🔍 Testing with URL: {test_url}")
    print("⏳ Initializing scraper...")
    
    scraper = eBayScraper(headless=True)
    
    print("🌐 Scraping product data...")
    product = await scraper.scrape_with_playwright(test_url)
    
    if product:
        print("\n✅ SUCCESS! Product data extracted:\n")
        print(f"📦 Title: {product.title[:50]}...")
        print(f"💰 Price: {product.price}")
        print(f"🔢 EAN: {product.ean}")
        print(f"📸 Main Image: {product.main_image[:50] if product.main_image else 'N/A'}...")
        print(f"👤 Seller: {product.seller}")
        print(f"📊 Condition: {product.condition}")
        print(f"🆔 Item Number: {product.item_number}")
        print(f"🏷️ Brand: {product.brand}")
        print(f"📝 MPN: {product.mpn}")
        print(f"📂 Category: {product.category}")
        
        # Save to Excel
        print("\n💾 Saving to Excel...")
        scraper.save_to_excel([product], "test_product.xlsx")
        
        print("\n🎉 Test completed successfully!")
        print(f"📁 Output saved to: test_product.xlsx")
    else:
        print("\n❌ Failed to scrape product")

async def test_search():
    """Test search functionality"""
    print("\n" + "="*60)
    print("eBay Scraper Test - Search Function")
    print("="*60 + "\n")
    
    scraper = eBayScraper(headless=True)
    
    print("🔍 Searching for 'blu ray musicmagpie'...")
    urls = await scraper.scrape_search_results("blu ray musicmagpie", max_pages=1)
    
    print(f"\n✅ Found {len(urls)} products")
    
    if urls:
        print("\nFirst 5 URLs found:")
        for i, url in enumerate(urls[:5], 1):
            print(f"{i}. {url}")

async def main():
    """Run all tests"""
    print("\n🚀 Starting eBay Scraper Tests\n")
    
    # Test 1: Single product
    await test_single_product()
    
    # Test 2: Search function
    await test_search()
    
    print("\n" + "="*60)
    print("✨ All tests completed!")
    print("="*60 + "\n")

if __name__ == "__main__":
    asyncio.run(main())