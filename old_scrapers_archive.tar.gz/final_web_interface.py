#!/usr/bin/env python3
"""
Final Web Interface for eBay Scraper - Uses Playwright for reliable scraping
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional
import asyncio
from datetime import datetime
import pandas as pd
import os
import uuid
from pathlib import Path
import re

# Import our working scraper
from robust_playwright_scraper import RobustPlaywrightScraper

# Create app
app = FastAPI(title="eBay Scraper Pro", version="2.0")

# Storage for tasks
tasks = {}
results_dir = Path("scraping_results")
results_dir.mkdir(exist_ok=True)

class ScrapeRequest(BaseModel):
    search_query: Optional[str] = None
    search_urls: Optional[List[str]] = None  
    max_pages: int = 1
    
class TaskStatus(BaseModel):
    task_id: str
    status: str  # pending, running, completed, failed
    started_at: datetime
    completed_at: Optional[datetime] = None
    total_products: int = 0
    unique_products: int = 0
    duplicates_removed: int = 0
    products_per_minute: float = 0
    current_page: int = 0
    total_pages: int = 0
    search_query: str = ""
    error_message: Optional[str] = None
    excel_file: Optional[str] = None
    sample_products: List[dict] = []

async def scrape_ebay_task(task_id: str, search_input: str, max_pages: int):
    """Background task to scrape eBay"""
    task = tasks[task_id]
    task['status'] = 'running'
    task['started_at'] = datetime.now()
    
    try:
        # Create scraper instance
        scraper = RobustPlaywrightScraper()
        
        # Process search input - detect if it's a URL or keywords
        if search_input.startswith('http'):
            # It's a URL
            url = search_input
            task['search_query'] = f"URL: {url[:50]}..."
        else:
            # It's keywords - build URL
            keywords = search_input.replace(' ', '+')
            url = f"https://www.ebay.co.uk/sch/i.html?_nkw={keywords}&_sacat=0"
            task['search_query'] = search_input
        
        task['total_pages'] = max_pages
        
        # Run the scraper
        products = await scraper.scrape_url(url, max_pages)
        
        # Calculate statistics
        elapsed = datetime.now() - task['started_at']
        minutes = elapsed.total_seconds() / 60
        
        task['total_products'] = len(products)
        task['unique_products'] = len(scraper.seen_items)
        task['duplicates_removed'] = scraper.products_scraped - len(products)
        task['products_per_minute'] = len(products) / minutes if minutes > 0 else 0
        
        # Save to Excel
        if products:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_{task_id}_{timestamp}.xlsx"
            filepath = results_dir / filename
            
            df = pd.DataFrame(products)
            df.to_excel(filepath, index=False)
            
            task['excel_file'] = filename
            task['sample_products'] = products[:5]
        
        task['status'] = 'completed'
        task['completed_at'] = datetime.now()
        
    except Exception as e:
        task['status'] = 'failed'
        task['error_message'] = str(e)
        task['completed_at'] = datetime.now()

@app.get("/", response_class=HTMLResponse)
async def home():
    """Serve the main page"""
    html = """
<!DOCTYPE html>
<html>
<head>
    <title>eBay Scraper Pro</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 48px;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .header p {
            font-size: 18px;
            opacity: 0.9;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: border 0.3s;
        }
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #667eea;
        }
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        .status {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            display: none;
        }
        .status.show { display: block; }
        .status.running {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        .status.completed {
            background: #d1f2eb;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .status.failed {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
            margin: 20px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 4px;
            transition: width 0.3s;
        }
        .download-btn {
            background: #28a745;
            display: inline-block;
            margin-top: 10px;
        }
        .download-btn:hover {
            background: #218838;
        }
        .sample-products {
            margin-top: 20px;
        }
        .product-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .product-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }
        .product-details {
            display: flex;
            gap: 20px;
            color: #666;
            font-size: 14px;
        }
        .loader {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛒 eBay Scraper Pro</h1>
            <p>High-performance scraping with real browser automation</p>
        </div>
        
        <div class="card">
            <h2>Start New Scraping Task</h2>
            
            <div class="form-group">
                <label>Search Method:</label>
                <select id="searchMethod" onchange="toggleSearchInput()">
                    <option value="url">Paste eBay URL</option>
                    <option value="keywords">Enter Keywords</option>
                    <option value="bulk">Bulk URLs (Multiple)</option>
                </select>
            </div>
            
            <div class="form-group" id="urlInput">
                <label>eBay Search URL:</label>
                <input type="text" id="searchUrl" placeholder="https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray">
            </div>
            
            <div class="form-group" id="keywordsInput" style="display:none;">
                <label>Search Keywords:</label>
                <input type="text" id="searchKeywords" placeholder="blu ray, PlayStation 5, iPhone">
            </div>
            
            <div class="form-group" id="bulkInput" style="display:none;">
                <label>Bulk URLs (one per line):</label>
                <textarea id="bulkUrls" placeholder="Paste multiple eBay search URLs, one per line"></textarea>
            </div>
            
            <div class="form-group">
                <label>Pages to Scrape:</label>
                <select id="maxPages">
                    <option value="1">1 page</option>
                    <option value="3">3 pages</option>
                    <option value="5">5 pages</option>
                    <option value="10">10 pages</option>
                    <option value="20">20 pages</option>
                </select>
            </div>
            
            <button class="btn" onclick="startScraping()">🚀 Start Scraping</button>
            
            <div id="status" class="status"></div>
        </div>
        
        <div class="card" id="resultsCard" style="display:none;">
            <h2>Scraping Results</h2>
            <div class="stats-grid" id="statsGrid"></div>
            <div class="progress-bar">
                <div class="progress-fill" id="progressBar"></div>
            </div>
            <div id="downloadSection"></div>
            <div class="sample-products" id="sampleProducts"></div>
        </div>
    </div>
    
    <script>
        let currentTaskId = null;
        let statusInterval = null;
        
        function toggleSearchInput() {
            const method = document.getElementById('searchMethod').value;
            document.getElementById('urlInput').style.display = method === 'url' ? 'block' : 'none';
            document.getElementById('keywordsInput').style.display = method === 'keywords' ? 'block' : 'none';
            document.getElementById('bulkInput').style.display = method === 'bulk' ? 'block' : 'none';
        }
        
        async function startScraping() {
            const method = document.getElementById('searchMethod').value;
            const maxPages = parseInt(document.getElementById('maxPages').value);
            let searchInputs = [];
            
            if (method === 'url') {
                const url = document.getElementById('searchUrl').value.trim();
                if (!url) {
                    alert('Please enter an eBay URL');
                    return;
                }
                searchInputs = [url];
            } else if (method === 'keywords') {
                const keywords = document.getElementById('searchKeywords').value.trim();
                if (!keywords) {
                    alert('Please enter search keywords');
                    return;
                }
                searchInputs = [keywords];
            } else if (method === 'bulk') {
                const bulkText = document.getElementById('bulkUrls').value.trim();
                if (!bulkText) {
                    alert('Please enter at least one URL');
                    return;
                }
                searchInputs = bulkText.split('\\n').filter(url => url.trim());
            }
            
            // Start tasks
            const statusDiv = document.getElementById('status');
            statusDiv.className = 'status running show';
            statusDiv.innerHTML = '<span class="loader"></span> Starting scraping tasks...';
            
            document.getElementById('resultsCard').style.display = 'block';
            
            // Process each input
            let completedTasks = 0;
            const totalTasks = searchInputs.length;
            
            for (const input of searchInputs) {
                const response = await fetch('/scrape', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        search_query: input,
                        max_pages: maxPages
                    })
                });
                
                const data = await response.json();
                currentTaskId = data.task_id;
                
                // Start monitoring this task
                monitorTask(currentTaskId);
                
                // Wait a bit between tasks to avoid overload
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            
            statusDiv.innerHTML = `✅ Started ${totalTasks} scraping task${totalTasks > 1 ? 's' : ''}`;
        }
        
        async function monitorTask(taskId) {
            const response = await fetch(`/status/${taskId}`);
            const task = await response.json();
            
            updateUI(task);
            
            if (task.status === 'running') {
                setTimeout(() => monitorTask(taskId), 2000);
            }
        }
        
        function updateUI(task) {
            const statusDiv = document.getElementById('status');
            const statsGrid = document.getElementById('statsGrid');
            const progressBar = document.getElementById('progressBar');
            const downloadSection = document.getElementById('downloadSection');
            const sampleProducts = document.getElementById('sampleProducts');
            
            // Update status
            statusDiv.className = `status ${task.status} show`;
            if (task.status === 'running') {
                statusDiv.innerHTML = `<span class="loader"></span> Scraping page ${task.current_page}/${task.total_pages}...`;
            } else if (task.status === 'completed') {
                statusDiv.innerHTML = `✅ Scraping completed successfully!`;
            } else if (task.status === 'failed') {
                statusDiv.innerHTML = `❌ Error: ${task.error_message}`;
            }
            
            // Update stats
            statsGrid.innerHTML = `
                <div class="stat-card">
                    <div class="stat-value">${task.total_products}</div>
                    <div class="stat-label">Total Products</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.unique_products}</div>
                    <div class="stat-label">Unique Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.duplicates_removed}</div>
                    <div class="stat-label">Duplicates Removed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${task.products_per_minute.toFixed(1)}</div>
                    <div class="stat-label">Products/Minute</div>
                </div>
            `;
            
            // Update progress bar
            if (task.total_pages > 0) {
                const progress = (task.current_page / task.total_pages) * 100;
                progressBar.style.width = progress + '%';
            }
            
            // Add download button if completed
            if (task.status === 'completed' && task.excel_file) {
                downloadSection.innerHTML = `
                    <a href="/download/${task.excel_file}" class="btn download-btn">
                        📥 Download Excel File
                    </a>
                `;
                
                // Show sample products
                if (task.sample_products.length > 0) {
                    let productsHtml = '<h3>Sample Products:</h3>';
                    task.sample_products.forEach((product, i) => {
                        productsHtml += `
                            <div class="product-item">
                                <div class="product-title">${i+1}. ${product.Title}</div>
                                <div class="product-details">
                                    <span>💰 ${product.Price}</span>
                                    <span>📦 ${product.Condition}</span>
                                    <span>🔢 #${product.Ebay_Item_Number}</span>
                                </div>
                            </div>
                        `;
                    });
                    sampleProducts.innerHTML = productsHtml;
                }
            }
        }
    </script>
</body>
</html>
"""
    return html

@app.post("/scrape")
async def create_scrape_task(request: ScrapeRequest, background_tasks: BackgroundTasks):
    """Create a new scraping task"""
    
    # Process search query - detect if it's a URL or keywords
    search_input = request.search_query or ""
    
    if not search_input and request.search_urls:
        # Bulk URLs provided
        search_input = request.search_urls[0] if request.search_urls else ""
    
    if not search_input:
        raise HTTPException(status_code=400, detail="No search input provided")
    
    # Create task
    task_id = str(uuid.uuid4())[:8]
    tasks[task_id] = {
        'task_id': task_id,
        'status': 'pending',
        'started_at': datetime.now(),
        'completed_at': None,
        'total_products': 0,
        'unique_products': 0,
        'duplicates_removed': 0,
        'products_per_minute': 0,
        'current_page': 0,
        'total_pages': request.max_pages,
        'search_query': search_input,
        'error_message': None,
        'excel_file': None,
        'sample_products': []
    }
    
    # Start background task
    background_tasks.add_task(
        scrape_ebay_task, 
        task_id,
        search_input,
        request.max_pages
    )
    
    return {"task_id": task_id, "message": "Scraping started"}

@app.get("/status/{task_id}")
async def get_task_status(task_id: str):
    """Get status of a scraping task"""
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return tasks[task_id]

@app.get("/download/{filename}")
async def download_file(filename: str):
    """Download Excel file"""
    filepath = results_dir / filename
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=filepath,
        filename=filename,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@app.get("/stats")
async def get_stats():
    """Get overall statistics"""
    total_tasks = len(tasks)
    completed_tasks = sum(1 for t in tasks.values() if t['status'] == 'completed')
    total_products = sum(t['total_products'] for t in tasks.values())
    
    return {
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "total_products_scraped": total_products,
        "active_tasks": [t for t in tasks.values() if t['status'] == 'running']
    }

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("🚀 eBay Scraper Pro - Web Interface")
    print("="*60)
    print("✅ Server starting at http://localhost:8002")
    print("📊 Using Playwright for reliable browser automation")
    print("⚡ High-speed scraping with duplicate detection")
    print("="*60 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8002)