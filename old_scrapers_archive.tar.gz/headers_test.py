#!/usr/bin/env python3
"""
Test different header combinations to bypass eBay's timeout/blocking
"""

import requests
from bs4 import BeautifulSoup
import time

def test_headers():
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    # Different header combinations to test
    headers_sets = [
        {
            "name": "Chrome on Mac (Complete)",
            "headers": {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Sec-Fetch-User': '?1',
                'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"macOS"',
                'Cache-Control': 'max-age=0',
            }
        },
        {
            "name": "Safari on Mac",
            "headers": {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-GB,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
        },
        {
            "name": "Firefox on Mac",
            "headers": {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-GB,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Sec-Fetch-User': '?1',
            }
        },
        {
            "name": "Mobile Chrome",
            "headers": {
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/120.0.0.0 Mobile/15E148 Safari/604.1',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-GB,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
            }
        }
    ]
    
    for header_set in headers_sets:
        print(f"\n{'='*60}")
        print(f"Testing: {header_set['name']}")
        print('='*60)
        
        session = requests.Session()
        session.headers.update(header_set['headers'])
        
        try:
            start = time.time()
            response = session.get(url, timeout=30, allow_redirects=True)
            elapsed = time.time() - start
            
            print(f"✅ Status: {response.status_code}")
            print(f"⏱️  Time: {elapsed:.2f}s")
            print(f"📄 Size: {len(response.text)} bytes")
            
            # Check if we got real content
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Check for challenge page
            if 'challenge' in response.url or '/splashui/' in response.url:
                print("❌ Got challenge page!")
            
            # Count products
            products = soup.find_all('li', {'data-viewport': True})
            print(f"📦 Products found: {len(products)}")
            
            # Check for specific indicators
            title = soup.find('title')
            if title:
                print(f"📑 Title: {title.get_text()[:60]}")
            
            # Try to find a product
            first_product = soup.find('h3', class_='s-item__title')
            if first_product:
                print(f"✅ First product: {first_product.get_text()[:50]}")
            else:
                print("❌ No products with standard selectors")
            
        except requests.Timeout:
            print(f"❌ TIMEOUT after 30s")
        except requests.RequestException as e:
            print(f"❌ Error: {e}")
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
        
        time.sleep(2)  # Be polite between attempts

if __name__ == "__main__":
    print("Testing different header combinations for eBay...")
    test_headers()