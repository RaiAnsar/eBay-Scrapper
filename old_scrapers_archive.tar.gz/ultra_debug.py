#!/usr/bin/env python3
"""
Ultra Debug - Find exactly what's in the eBay HTML
"""

import requests
from bs4 import BeautifulSoup
import re

def ultra_debug():
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("Fetching page...")
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find the first item with data-viewport
    items = soup.select('li[data-viewport]')
    
    if items:
        print(f"\nFound {len(items)} items with data-viewport")
        print("\n=== First Item Structure ===")
        
        first_item = items[0]
        
        # Check all links in the item
        links = first_item.find_all('a')
        print(f"Links found: {len(links)}")
        
        for link in links:
            href = link.get('href', '')
            if '/itm/' in href:
                print(f"\nItem link found: {href[:100]}")
                
                # Extract item number
                match = re.search(r'/itm/(\d+)', href)
                if match:
                    print(f"Item number: {match.group(1)}")
                
                # Get title
                h3 = first_item.find('h3')
                if h3:
                    print(f"Title (h3): {h3.get_text(strip=True)[:80]}")
                
                # Look for any span that might be title
                spans = first_item.find_all('span')
                for span in spans:
                    text = span.get_text(strip=True)
                    if len(text) > 20 and not text.startswith('£'):
                        print(f"Potential title span: {text[:80]}")
                        break
                
                # Look for price
                for elem in first_item.find_all(string=re.compile(r'£')):
                    print(f"Price found: {elem.strip()}")
                    break
                
                # Get all classes in the item
                print("\nAll classes in item:")
                for elem in first_item.find_all(class_=True):
                    classes = elem.get('class')
                    if classes:
                        print(f"  {' '.join(classes)}")
                
                break
        
        print("\n=== Raw HTML of First Item (first 2000 chars) ===")
        print(str(first_item)[:2000])
    
    else:
        print("No items found with data-viewport. Checking alternatives...")
        
        # Look for any links to items
        item_links = soup.find_all('a', href=re.compile(r'/itm/\d+'))
        if item_links:
            print(f"Found {len(item_links)} item links")
            first_link = item_links[0]
            print(f"First link: {first_link.get('href')[:100]}")
            
            # Find its container
            container = first_link.find_parent('li') or first_link.find_parent('div')
            if container:
                print("\nContainer HTML (first 2000 chars):")
                print(str(container)[:2000])

if __name__ == "__main__":
    ultra_debug()