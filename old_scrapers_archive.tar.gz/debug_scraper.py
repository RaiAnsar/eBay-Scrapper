#!/usr/bin/env python3
"""
Debug scraper to find the actual eBay HTML structure
"""

import requests
from bs4 import BeautifulSoup
import re

def debug_ebay_structure():
    """Debug eBay page structure"""
    
    url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-GB,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
    }
    
    print("Fetching eBay page...")
    response = requests.get(url, headers=headers)
    print(f"Status: {response.status_code}")
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Look for different possible item containers
    print("\n=== Searching for item containers ===")
    
    # Method 1: Find all links to /itm/
    item_links = soup.find_all('a', href=re.compile(r'/itm/\d+'))
    print(f"Found {len(item_links)} item links")
    
    if item_links:
        # Analyze the first item link's parent structure
        first_link = item_links[0]
        print(f"\nFirst item link: {first_link.get('href', '')[:100]}")
        
        # Find the container
        parent = first_link
        for _ in range(5):  # Go up 5 levels
            parent = parent.parent
            if parent:
                classes = parent.get('class', [])
                if classes:
                    print(f"Parent level {_+1} classes: {classes}")
    
    # Method 2: Look for price elements
    print("\n=== Looking for price elements ===")
    prices = soup.find_all(text=re.compile(r'£\d+'))[:5]
    print(f"Found {len(prices)} price texts")
    
    # Method 3: Find elements with specific patterns
    print("\n=== Looking for item containers by pattern ===")
    
    # Check for s-item
    s_items = soup.select('.s-item')
    print(f"Elements with class 's-item': {len(s_items)}")
    
    # Check for other patterns
    patterns = [
        'li[data-viewport]',
        'div[data-item-id]',
        'article',
        '[data-listing-id]',
        '.s-item__wrapper',
        'div[id*="item"]',
        'li[id*="item"]'
    ]
    
    for pattern in patterns:
        elements = soup.select(pattern)
        if elements:
            print(f"Pattern '{pattern}': {len(elements)} elements")
    
    # Method 4: Find by text content
    print("\n=== Sample item data ===")
    
    # Find all h3 tags (often used for titles)
    h3_tags = soup.find_all('h3')[:5]
    for i, h3 in enumerate(h3_tags, 1):
        text = h3.get_text(strip=True)[:80]
        if text and 'Shop on eBay' not in text:
            print(f"{i}. Title: {text}")
            
            # Find the parent container
            container = h3.find_parent('li') or h3.find_parent('div')
            if container:
                # Try to extract price from the same container
                price_elem = container.find(text=re.compile(r'£'))
                if price_elem:
                    print(f"   Price: {price_elem.strip()}")
                
                # Try to extract item number
                link = container.find('a', href=re.compile(r'/itm/(\d+)'))
                if link:
                    match = re.search(r'/itm/(\d+)', link.get('href', ''))
                    if match:
                        print(f"   Item #: {match.group(1)}")
    
    # Save sample HTML for analysis
    with open('ebay_sample.html', 'w', encoding='utf-8') as f:
        f.write(response.text[:50000])
    print("\nSaved first 50KB of HTML to ebay_sample.html for analysis")

if __name__ == "__main__":
    debug_ebay_structure()