#!/usr/bin/env python3
"""
Browser-like scraper using requests with complete browser behavior
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import time
import re
import json
from urllib.parse import urlencode

class BrowserLikeScraper:
    def __init__(self):
        # Create a session that acts like a browser
        self.session = requests.Session()
        
        # Complete browser headers from real Chrome
        self.base_headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'Cache-Control': 'max-age=0',
        }
        
        self.session.headers.update(self.base_headers)
        
        # Use common browser settings
        self.session.verify = True
        self.session.allow_redirects = True
        
        # Store cookies like a browser
        self.products = []
        self.seen_items = set()
        
    def establish_session(self):
        """First visit eBay homepage like a real user would"""
        print("🌐 Establishing browser session...")
        
        # Step 1: Visit homepage first (like opening a new browser)
        home_headers = self.base_headers.copy()
        home_headers['Sec-Fetch-Site'] = 'none'
        
        try:
            # Visit eBay UK homepage
            response = self.session.get(
                'https://www.ebay.co.uk',
                headers=home_headers,
                timeout=30
            )
            
            if response.status_code == 200:
                print(f"✅ Homepage loaded, cookies: {len(self.session.cookies)}")
                
                # Parse for any necessary tokens
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Look for CSRF tokens or session identifiers
                csrf = soup.find('input', {'name': '_csrf'})
                if csrf:
                    self.csrf_token = csrf.get('value')
                    print(f"   CSRF token found")
                
                # Small delay like a human reading the page
                time.sleep(2)
                
                # Step 2: Accept cookies if needed
                self.accept_cookies()
                
                return True
            else:
                print(f"❌ Homepage returned: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Failed to establish session: {e}")
            return False
    
    def accept_cookies(self):
        """Accept cookies like a real user"""
        print("🍪 Accepting cookies...")
        
        # eBay cookie acceptance endpoint
        cookie_headers = self.base_headers.copy()
        cookie_headers['Sec-Fetch-Site'] = 'same-origin'
        cookie_headers['Referer'] = 'https://www.ebay.co.uk/'
        
        # This would be the AJAX call to accept cookies
        try:
            response = self.session.post(
                'https://www.ebay.co.uk/gdpr/accept',
                headers=cookie_headers,
                json={'accept': True},
                timeout=10
            )
            print(f"   Cookie acceptance: {response.status_code}")
        except:
            # If the endpoint doesn't exist, that's fine
            pass
        
        time.sleep(1)
    
    def search_products(self, search_term, page=1):
        """Search for products like a browser would"""
        
        print(f"\n🔍 Searching for: {search_term}, Page {page}")
        
        # Build search URL with all parameters a browser would send
        params = {
            '_nkw': search_term,
            '_sacat': '0',
            '_from': 'R40',
            '_ipg': '200',  # 200 items per page
            'rt': 'nc',
            'LH_BIN': '1',  # Buy it now
        }
        
        if page > 1:
            params['_pgn'] = str(page)
        
        # Headers for search request
        search_headers = self.base_headers.copy()
        search_headers.update({
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-User': '?1',
            'Sec-Fetch-Dest': 'document',
            'Referer': 'https://www.ebay.co.uk/',
        })
        
        url = f"https://www.ebay.co.uk/sch/i.html?{urlencode(params)}"
        
        print(f"📍 URL: {url}")
        
        try:
            response = self.session.get(
                url,
                headers=search_headers,
                timeout=30
            )
            
            print(f"📊 Response: {response.status_code}, Size: {len(response.text)} bytes")
            
            if response.status_code == 200:
                # Check if we got real content
                if len(response.text) < 10000:
                    print("⚠️ Response too small, might be blocked")
                    print("First 500 chars:", response.text[:500])
                    return []
                
                return self.parse_search_results(response.text)
            else:
                print(f"❌ Search failed: {response.status_code}")
                return []
                
        except Exception as e:
            print(f"❌ Search error: {e}")
            return []
    
    def parse_search_results(self, html):
        """Parse search results from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        products = []
        
        # Check page title to verify we got real results
        title = soup.find('title')
        if title:
            print(f"📑 Page title: {title.get_text()[:50]}")
        
        # Try multiple selectors
        items = soup.find_all('li', {'data-viewport': True})
        if not items:
            items = soup.find_all('li', class_='s-item')
        if not items:
            items = soup.find_all('div', class_='s-item__wrapper')
        
        print(f"📦 Found {len(items)} items on page")
        
        # Skip first 2 if they're headers
        if len(items) > 2:
            items = items[2:]
        
        for item in items:
            try:
                # Extract product URL
                link = item.find('a', href=re.compile(r'/itm/\d+'))
                if not link:
                    continue
                
                href = link.get('href', '')
                if not href.startswith('http'):
                    href = 'https://www.ebay.co.uk' + href
                
                # Extract item number
                match = re.search(r'/itm/(\d+)', href)
                if not match:
                    continue
                
                item_number = match.group(1)
                
                # Skip if already seen
                if item_number in self.seen_items:
                    continue
                
                self.seen_items.add(item_number)
                
                # Extract title
                title_elem = item.find('h3', class_='s-item__title')
                if not title_elem:
                    title_elem = item.find('div', class_='s-item__title')
                
                title = title_elem.get_text(strip=True) if title_elem else ''
                
                if not title or 'Shop on eBay' in title:
                    continue
                
                # Extract price
                price_elem = item.find('span', class_='s-item__price')
                price = price_elem.get_text(strip=True) if price_elem else ''
                
                # Extract condition
                condition_elem = item.find('span', class_='SECONDARY_INFO')
                condition = condition_elem.get_text(strip=True) if condition_elem else ''
                
                product = {
                    'Item_Number': item_number,
                    'Title': title,
                    'Price': price,
                    'Condition': condition,
                    'URL': href,
                    'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                products.append(product)
                
            except Exception as e:
                continue
        
        print(f"✅ Extracted {len(products)} products")
        return products
    
    def scrape(self, search_term, max_pages=3):
        """Main scraping function"""
        
        print("\n" + "="*70)
        print("🌐 Browser-Like eBay Scraper")
        print("="*70)
        print(f"🔍 Search: {search_term}")
        print(f"📄 Max pages: {max_pages}")
        print("="*70)
        
        # Establish session first
        if not self.establish_session():
            print("❌ Failed to establish session")
            return None
        
        # Search pages
        for page in range(1, max_pages + 1):
            products = self.search_products(search_term, page)
            
            if products:
                self.products.extend(products)
            else:
                print(f"⚠️ No products found on page {page}")
                if page == 1:
                    print("🔍 Checking if we're being blocked...")
                    break
            
            # Human-like delay between pages
            if page < max_pages:
                delay = 3
                print(f"⏳ Waiting {delay} seconds...")
                time.sleep(delay)
        
        # Save results
        if self.products:
            df = pd.DataFrame(self.products)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            excel_file = f"ebay_browser_like_{timestamp}.xlsx"
            
            df.to_excel(excel_file, index=False)
            
            print(f"\n" + "="*70)
            print(f"✅ Scraped {len(self.products)} products")
            print(f"📁 Saved to: {excel_file}")
            print("="*70)
            
            return excel_file
        else:
            print("\n❌ No products scraped")
            return None

# Test the scraper
if __name__ == "__main__":
    scraper = BrowserLikeScraper()
    
    result = scraper.scrape(
        search_term="blu ray",
        max_pages=3
    )
    
    if result:
        print(f"\n✅ Success! Check: {result}")
    else:
        print("\n❌ Scraping failed")