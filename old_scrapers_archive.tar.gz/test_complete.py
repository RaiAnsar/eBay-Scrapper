#!/usr/bin/env python3
"""
Test complete functionality with EAN and Description extraction
"""

import asyncio
from enhanced_playwright_scraper import EnhancedEbayScraper

async def test_complete():
    """Test with all features enabled"""
    
    scraper = EnhancedEbayScraper()
    await scraper.initialize_browser()
    
    # Test URL - only scrape 1 page for quick test
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    print("Testing complete extraction (EAN + Description)...")
    print("=" * 70)
    
    # Scrape with both EAN and description
    products = await scraper.scrape_url(
        search_url, 
        max_pages=1,  # Only 1 page for test
        extract_ean=True,
        extract_description=True
    )
    
    if products:
        print(f"\n✅ Successfully scraped {len(products)} products")
        
        # Check first product for all fields
        first = products[0]
        print(f"\n📦 First Product Details:")
        print(f"Title: {first.get('Title', 'N/A')[:60]}...")
        print(f"Price: {first.get('Price', 'N/A')}")
        print(f"Item Number: {first.get('Ebay_Item_Number', 'N/A')}")
        print(f"EAN: {first.get('EAN', 'N/A') or 'Not found'}")
        
        desc = first.get('Description', '')
        if desc:
            print(f"Description: {desc[:200]}..." if len(desc) > 200 else f"Description: {desc}")
        else:
            print("Description: Not found")
        
        # Count how many have EAN and Description
        ean_count = sum(1 for p in products if p.get('EAN'))
        desc_count = sum(1 for p in products if p.get('Description'))
        
        print(f"\n📊 Statistics:")
        print(f"Products with EAN: {ean_count}/{len(products)}")
        print(f"Products with Description: {desc_count}/{len(products)}")
    
    await scraper.close_browser()

if __name__ == "__main__":
    asyncio.run(test_complete())