#!/usr/bin/env python3
"""
Turbo eBay Scraper - Super Fast Concurrent Processing
- Fetches all product details in parallel
- Uses multiple browser contexts for speed
- Processes 10-20x faster than sequential
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import re
from typing import List, Dict, Optional

class TurboEbayScraper:
    def __init__(self, max_workers=10):
        self.products_scraped = 0
        self.seen_items = set()
        self.start_time = None
        self.browser = None
        self.playwright = None
        self.max_workers = max_workers  # Number of concurrent pages
        self.context_pool = []
        
    async def initialize(self):
        """Initialize browser and context pool"""
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=True,
            args=['--disable-blink-features=AutomationControlled']
        )
        
        # Create a pool of browser contexts for parallel processing
        for _ in range(self.max_workers):
            context = await self.browser.new_context(
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            self.context_pool.append(context)
    
    async def close(self):
        """Close all contexts and browser"""
        for context in self.context_pool:
            await context.close()
        await self.browser.close()
        await self.playwright.stop()
    
    async def scrape_url(self, search_url: str, max_pages: int = 10, 
                        extract_ean: bool = False, extract_description: bool = False,
                        progress_callback=None):
        """Main scraping function with super fast concurrent processing"""
        self.start_time = datetime.now()
        await self.initialize()
        
        print("\n" + "="*70)
        print("🚀 TURBO eBay Scraper - Lightning Fast Mode")
        print("="*70)
        print(f"📍 URL: {search_url[:80]}...")
        print(f"📄 Pages to scrape: {max_pages}")
        print(f"⚡ Concurrent workers: {self.max_workers}")
        print(f"⏰ Started: {self.start_time.strftime('%H:%M:%S')}")
        print("="*70 + "\n")
        
        all_products = []
        
        # Use first context for search pages
        search_page = await self.context_pool[0].new_page()
        
        for page_num in range(1, max_pages + 1):
            print(f"\n📄 Processing Page {page_num}/{max_pages}")
            print("-" * 40)
            
            if progress_callback:
                await progress_callback(page_num, len(all_products))
            
            # Construct URL for page
            if page_num == 1:
                url = search_url
            else:
                url = f"{search_url}&_pgn={page_num}" if '?' in search_url else f"{search_url}?_pgn={page_num}"
            
            try:
                # Load search page
                print(f"   Loading: {url[:80]}...")
                await search_page.goto(url, wait_until='domcontentloaded', timeout=15000)
                await search_page.wait_for_timeout(2000)
                
                # Wait for products to load
                try:
                    await search_page.wait_for_selector('.s-item', timeout=5000)
                except:
                    pass  # Continue anyway
                
                # Extract all products from page
                products = await self.extract_products_from_page(search_page)
                
                # Filter duplicates
                new_products = []
                for product in products:
                    item_num = product.get('Ebay_Item_Number', '')
                    if item_num and item_num not in self.seen_items:
                        self.seen_items.add(item_num)
                        new_products.append(product)
                
                print(f"✅ Found: {len(products)} items ({len(new_products)} new)")
                
                # Process details in parallel if requested
                if (extract_ean or extract_description) and new_products:
                    print(f"⚡ Processing {len(new_products)} products in parallel...")
                    
                    # Create tasks for parallel processing
                    tasks = []
                    for i, product in enumerate(new_products):
                        item_num = product.get('Ebay_Item_Number', '')
                        if item_num:
                            # Use different contexts for parallel processing
                            context_idx = (i % (len(self.context_pool) - 1)) + 1
                            task = self.fetch_product_details(
                                item_num, 
                                self.context_pool[context_idx],
                                extract_ean,
                                extract_description
                            )
                            tasks.append(task)
                    
                    # Execute all tasks in parallel
                    if tasks:
                        results = await asyncio.gather(*tasks, return_exceptions=True)
                        
                        # Update products with fetched details
                        for i, result in enumerate(results):
                            if isinstance(result, dict):
                                new_products[i].update(result)
                        
                        print(f"   ✨ Processed {len(tasks)} products in parallel!")
                
                all_products.extend(new_products)
                self.products_scraped += len(new_products)
                
                # Update progress
                if progress_callback:
                    await progress_callback(page_num, len(all_products))
                
                # Show sample products
                for i, p in enumerate(new_products[:2], 1):
                    print(f"   {i}. {p['Title'][:60]}...")
                    if p.get('EAN'):
                        print(f"      EAN: {p['EAN']}")
                
                if len(products) == 0:
                    print("   ℹ️ No more products found, stopping early")
                    break
                    
            except Exception as e:
                print(f"❌ Error on page {page_num}: {e}")
        
        await search_page.close()
        await self.close()
        
        # Final report
        duration = (datetime.now() - self.start_time).total_seconds()
        rate = (self.products_scraped / duration * 60) if duration > 0 else 0
        
        print("\n" + "="*70)
        print("📊 FINAL REPORT")
        print("="*70)
        print(f"✅ Products scraped: {self.products_scraped}")
        print(f"🎯 Unique items: {len(self.seen_items)}")
        print(f"⏱️  Total time: {int(duration//60)}:{int(duration%60):02d}")
        print(f"⚡ Average rate: {rate:.1f} products/minute")
        print("="*70 + "\n")
        
        return all_products
    
    async def fetch_product_details(self, item_number: str, context, 
                                   extract_ean: bool, extract_description: bool):
        """Fetch EAN and/or description for a single product"""
        result = {}
        
        try:
            page = await context.new_page()
            product_url = f"https://www.ebay.co.uk/itm/{item_number}"
            
            # Navigate to product page
            await page.goto(product_url, wait_until='domcontentloaded', timeout=8000)
            
            # Extract both EAN and description in one go
            data = await page.evaluate('''(extractEan, extractDesc) => {
                const result = {};
                
                if (extractEan) {
                    // Extract EAN
                    let ean = '';
                    
                    // Method 1: Item specifics
                    const specifics = document.querySelectorAll('.ux-layout-section__item');
                    for (let spec of specifics) {
                        const text = spec.innerText || '';
                        if (text.includes('EAN') || text.includes('UPC') || text.includes('ISBN')) {
                            const match = text.match(/\\d{8,13}/);
                            if (match) {
                                ean = match[0];
                                break;
                            }
                        }
                    }
                    
                    // Method 2: Description
                    if (!ean) {
                        const desc = document.querySelector('.vim-description-content');
                        if (desc) {
                            const eanMatch = desc.innerText.match(/EAN[:\\s]*(\\d{8,13})/i);
                            if (eanMatch) ean = eanMatch[1];
                        }
                    }
                    
                    result.ean = ean;
                }
                
                if (extractDesc) {
                    // Extract description
                    let descText = '';
                    
                    // Try iframe first
                    const iframe = document.querySelector('iframe#desc_ifr');
                    if (iframe) {
                        try {
                            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                            descText = iframeDoc.body.innerText || '';
                        } catch (e) {}
                    }
                    
                    // Try direct description
                    if (!descText) {
                        const descDiv = document.querySelector('.vim-description-content, .vim-d-description');
                        if (descDiv) descText = descDiv.innerText || '';
                    }
                    
                    // Clean description
                    if (descText) {
                        descText = descText
                            .replace(/\\[\\d{1,2}\\/\\d{1,2}\\/\\d{4},\\s*\\d{1,2}:\\d{2}:\\d{2}\\s*[AP]M\\]/gi, '')
                            .replace(/Shipping.*/gi, '')
                            .replace(/Returns?.*/gi, '')
                            .replace(/Payment.*/gi, '')
                            .replace(/\\n{3,}/g, '\\n\\n')
                            .trim();
                    }
                    
                    result.description = descText;
                }
                
                return result;
            }''', extract_ean, extract_description)
            
            if extract_ean:
                result['EAN'] = data.get('ean', '')
            if extract_description:
                result['Description'] = data.get('description', '')
            
            await page.close()
            
        except Exception as e:
            # Silent fail for individual products
            pass
        
        return result
    
    async def extract_products_from_page(self, page):
        """Extract products from search results page"""
        products = await page.evaluate('''() => {
            const items = [];
            
            // Try multiple selectors
            let productElements = document.querySelectorAll('li[data-viewport]');
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('.s-item');
            }
            if (productElements.length === 0) {
                productElements = document.querySelectorAll('li[id*="item"]');
            }
            
            productElements.forEach((item, index) => {
                try {
                    // Skip the first s-item as it's often a template/header
                    if (index === 0 && item.className.includes('s-item')) {
                        const hasLink = item.querySelector('a[href*="/itm/"]');
                        if (!hasLink) return;
                    }
                    
                    const itemText = item.innerText || '';
                    if (itemText.includes('SPONSORED') || itemText.includes('Shop on eBay')) {
                        return;
                    }
                    
                    const link = item.querySelector('a[href*="/itm/"]');
                    if (!link) return;
                    
                    const href = link.href;
                    const itemMatch = href.match(/\\/itm\\/(\\d+)/);
                    if (!itemMatch) return;
                    
                    const itemNumber = itemMatch[1];
                    
                    // Get title
                    let title = '';
                    const h3 = item.querySelector('h3');
                    if (h3) {
                        title = h3.innerText.trim();
                    } else {
                        const titleElem = item.querySelector('.s-item__title');
                        if (titleElem) {
                            title = titleElem.innerText.trim();
                        } else {
                            const spans = item.querySelectorAll('span');
                            for (let span of spans) {
                                const text = span.innerText.trim();
                                if (text.length > 20 && !text.startsWith('£')) {
                                    title = text;
                                    break;
                                }
                            }
                        }
                    }
                    
                    if (!title || title === 'Shop on eBay') return;
                    
                    // Get price
                    let price = '';
                    const priceElem = item.querySelector('.s-item__price');
                    if (priceElem) {
                        price = priceElem.innerText.trim();
                    } else {
                        const priceMatch = itemText.match(/£[\\d,]+\\.?\\d*/);
                        if (priceMatch) price = priceMatch[0];
                    }
                    
                    // Get image
                    let image = '';
                    const imgElem = item.querySelector('img');
                    if (imgElem) {
                        image = imgElem.src || imgElem.dataset.src || '';
                    }
                    
                    // Get condition
                    let condition = '';
                    const conditionElem = item.querySelector('.SECONDARY_INFO');
                    if (conditionElem) {
                        condition = conditionElem.innerText.trim();
                    }
                    
                    // Get shipping
                    let shipping = '';
                    const shippingElem = item.querySelector('.s-item__shipping');
                    if (shippingElem) {
                        shipping = shippingElem.innerText.trim();
                    }
                    
                    items.push({
                        title: title,
                        price: price,
                        item_number: itemNumber,
                        image: image,
                        condition: condition,
                        shipping: shipping
                    });
                } catch (e) {}
            });
            
            return items;
        }''')
        
        # Format products
        return [{
            'Title': p['title'],
            'Price': p['price'],
            'Ebay_Item_Number': p['item_number'],
            'EAN': '',
            'Description': '',
            'Image_URL_1': p['image'],
            'Image_URL_2': '',
            'Image_URL_3': '',
            'Image_URL_4': '',
            'Condition': p['condition'],
            'Shipping': p['shipping'],
            'URL': f"https://www.ebay.co.uk/itm/{p['item_number']}",
            'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        } for p in products]

# Test the turbo scraper
async def test_turbo():
    scraper = TurboEbayScraper(max_workers=10)
    
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    products = await scraper.scrape_url(
        search_url,
        max_pages=2,
        extract_ean=True,
        extract_description=True
    )
    
    print(f"\n✅ Total products scraped: {len(products)}")
    
    # Save to Excel
    if products:
        df = pd.DataFrame(products)
        filename = f"turbo_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        df.to_excel(filename, index=False)
        print(f"📁 Saved to: {filename}")

if __name__ == "__main__":
    asyncio.run(test_turbo())