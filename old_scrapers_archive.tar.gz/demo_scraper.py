#!/usr/bin/env python3
"""
Demo: Scraping eBay Search Results with Duplicate Detection
"""

from simple_ebay_scraper import SimpleEbayScraper
import pandas as pd
from datetime import datetime

def demo_scraping():
    print("\n" + "="*60)
    print("🛒 eBay Scraper Demo - Running Your Search")
    print("="*60 + "\n")
    
    scraper = SimpleEbayScraper()
    
    # Your exact URL
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray+&_sacat=0&_from=R40&_trksid=m570.l1313"
    
    print(f"🔗 URL: {search_url}")
    print("📄 Pages to scrape: 2")
    print("✅ Duplicate detection: Enabled\n")
    
    # Extract query from URL
    query = "blu ray"
    
    print("🔍 Searching eBay...")
    urls = scraper.search_products(query, max_pages=2)
    
    print(f"\n✅ Found {len(urls)} products")
    
    if urls:
        print("\n📦 Scraping product details...\n")
        
        # Scrape first 10 products as demo
        products = scraper.scrape_multiple(urls[:10], delay=1)
        
        # Remove duplicates
        if products:
            print("\n🔄 Checking for duplicates...")
            unique_products = []
            seen_items = set()
            seen_eans = set()
            duplicates = 0
            
            for product in products:
                item_num = product.get('item_number', '')
                ean = product.get('ean', '')
                
                # Check for duplicates
                is_duplicate = False
                
                if item_num and item_num in seen_items:
                    is_duplicate = True
                    duplicates += 1
                elif ean and ean in seen_eans:
                    is_duplicate = True
                    duplicates += 1
                
                if not is_duplicate:
                    if item_num:
                        seen_items.add(item_num)
                    if ean:
                        seen_eans.add(ean)
                    unique_products.append(product)
            
            print(f"  • Total products: {len(products)}")
            print(f"  • Duplicates found: {duplicates}")
            print(f"  • Unique products: {len(unique_products)}")
            
            # Save results
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_demo_results_{timestamp}.xlsx"
            
            df = pd.DataFrame(unique_products)
            df.to_excel(filename, index=False)
            
            print(f"\n💾 Saved to: {filename}")
            
            # Display sample results
            print("\n📊 Sample Results:")
            print("="*60)
            
            for i, product in enumerate(unique_products[:5], 1):
                print(f"\n{i}. {product.get('title', 'N/A')[:50]}...")
                print(f"   💰 Price: {product.get('price', 'N/A')}")
                print(f"   🔢 Item #: {product.get('item_number', 'N/A')}")
                print(f"   📊 EAN: {product.get('ean', 'Not found')}")
                print(f"   📸 Image: {product.get('main_image', 'N/A')[:50]}...")
            
            print("\n" + "="*60)
            print("✨ Demo Complete!")
            print(f"📁 Check {filename} for full results")
            print("🌐 Or use the web interface at http://localhost:8001")
            print("="*60 + "\n")
    else:
        print("❌ No products found - eBay might be blocking. Try the web interface instead.")

if __name__ == "__main__":
    demo_scraping()