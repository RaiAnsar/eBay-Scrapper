#!/usr/bin/env python3
"""
Final eBay Scraper - Production Ready
Extracts: Title, Price, Item Number, EAN, 4 Image URLs
Skips: Variations, Sponsored items, Promotional content
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from datetime import datetime
import re

class FinalEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-GB,en;q=0.9',
        })
        self.skipped_count = 0
    
    def search_and_scrape(self, search_query, num_pages=1):
        """
        Main function: Search eBay and scrape all products
        """
        print("\n" + "="*60)
        print(f"🔍 Starting eBay Scraper")
        print(f"📦 Search: {search_query}")
        print(f"📄 Pages to scrape: {num_pages}")
        print("="*60 + "\n")
        
        all_products = []
        
        for page in range(1, num_pages + 1):
            print(f"\n📄 Processing page {page}/{num_pages}...")
            
            # Get search results
            product_urls = self.get_search_results(search_query, page)
            
            if not product_urls:
                print(f"  ⚠️ No products found on page {page}")
                continue
            
            print(f"  ✅ Found {len(product_urls)} products")
            
            # Scrape each product
            for i, url in enumerate(product_urls, 1):
                print(f"  [{i}/{len(product_urls)}] Scraping product...")
                
                product_data = self.scrape_product(url)
                
                if product_data:
                    all_products.append(product_data)
                    print(f"    ✓ {product_data['title'][:40]}...")
                else:
                    self.skipped_count += 1
                
                # Rate limiting
                time.sleep(1)
        
        print(f"\n" + "="*60)
        print(f"✅ Scraping Complete!")
        print(f"📊 Products scraped: {len(all_products)}")
        print(f"⏭️ Products skipped: {self.skipped_count} (variations/sponsored)")
        print("="*60 + "\n")
        
        return all_products
    
    def get_search_results(self, query, page=1):
        """Get product URLs from search results page"""
        url = "https://www.ebay.co.uk/sch/i.html"
        params = {
            '_nkw': query,
            '_pgn': page,
            '_ipg': 240,  # Max items per page
            'LH_ItemCondition': '3000|4000|5000|6000'  # All conditions
        }
        
        try:
            response = self.session.get(url, params=params, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            product_urls = []
            
            # Find all product items
            items = soup.select('.srp-results .s-item')
            
            for item in items:
                # Skip sponsored/promotional items
                if any(text in item.get_text() for text in ['SPONSORED', 'Picked for you', 'Shop on eBay', 'Top selling']):
                    continue
                
                # Get product link
                link = item.select_one('.s-item__link')
                if not link or not link.get('href'):
                    continue
                
                href = link.get('href')
                
                # Skip if it's not a real product
                if '/itm/' not in href:
                    continue
                
                # Check for variations (skip if has variations)
                variation_text = item.get_text().lower()
                if 'variation' in variation_text or 'select' in variation_text or 'choose' in variation_text:
                    continue
                
                # Extract clean URL
                item_match = re.search(r'/itm/(\d+)', href)
                if item_match:
                    item_id = item_match.group(1)
                    clean_url = f"https://www.ebay.co.uk/itm/{item_id}"
                    product_urls.append(clean_url)
            
            return product_urls
            
        except Exception as e:
            print(f"  ❌ Error getting search results: {e}")
            return []
    
    def scrape_product(self, url):
        """Scrape individual product details"""
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Check for variations (skip if found)
            if soup.select('.msku-sel, .vi-vpqp-panel'):  # Variation selectors
                print(f"    ⏭️ Skipping - has variations")
                return None
            
            # Extract item number from URL
            item_match = re.search(r'/itm/(\d+)', url)
            item_number = item_match.group(1) if item_match else ""
            
            # Extract required fields
            data = {
                'Title': self.extract_title(soup),
                'Price': self.extract_price(soup),
                'Ebay_Item_Number': item_number,
                'EAN': self.extract_ean(soup),
                'Image_URL_1': self.extract_image(soup, 0),
                'Image_URL_2': self.extract_image(soup, 1),
                'Image_URL_3': self.extract_image(soup, 2),
                'Image_URL_4': self.extract_image(soup, 3),
                'URL': url,
                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            return data
            
        except Exception as e:
            print(f"    ❌ Error scraping product: {e}")
            return None
    
    def extract_title(self, soup):
        """Extract product title"""
        title = soup.select_one('h1.it-ttl, h1')
        if title:
            # Remove "Details about" prefix if present
            text = title.get_text(strip=True)
            text = re.sub(r'^Details about\s+', '', text)
            return text
        return ""
    
    def extract_price(self, soup):
        """Extract product price"""
        # Try multiple price selectors
        price_meta = soup.find('meta', {'itemprop': 'price'})
        if price_meta and price_meta.get('content'):
            return f"£{price_meta['content']}"
        
        price_elem = soup.select_one('.x-price-primary, .vi-VR-cvipPrice, span[itemprop="price"]')
        if price_elem:
            price_text = price_elem.get_text(strip=True)
            # Extract numeric price
            match = re.search(r'[\d,]+\.?\d*', price_text)
            if match:
                return f"£{match.group()}"
        
        return ""
    
    def extract_ean(self, soup):
        """Extract EAN/UPC"""
        # Look in item specifics
        specifics = soup.select('.ux-layout-section__row, .itemAttr tr, .vi-evo-row')
        
        for row in specifics:
            text = row.get_text()
            if any(code in text for code in ['EAN', 'UPC', 'ISBN']):
                # Try to extract the value
                if ':' in text:
                    value = text.split(':')[-1].strip()
                    # Validate it's a number
                    if re.match(r'^\d+$', value):
                        return value
                
                # Try finding in spans
                value_elem = row.select_one('.ux-textspans--BOLD, .ux-textspans')
                if value_elem:
                    value = value_elem.get_text(strip=True)
                    if re.match(r'^\d+$', value):
                        return value
        
        return ""
    
    def extract_image(self, soup, index):
        """Extract image URL by index (0-3)"""
        images = []
        
        # Main image
        main_img = soup.select_one('#icImg, .ux-image-magnify__container img, img[itemprop="image"]')
        if main_img and main_img.get('src'):
            # Get high-res version
            src = main_img['src']
            src = re.sub(r'/s-l\d+\.', '/s-l1600.', src)  # Convert to high-res
            images.append(src)
        
        # Gallery images
        gallery_imgs = soup.select('.ux-image-filmstrip img, .ux-image-carousel img, .tdThumb img')
        for img in gallery_imgs:
            if img.get('src'):
                src = img['src']
                # Skip duplicates and thumbnails
                if src not in images and 'thumbs' not in src:
                    # Convert to high-res
                    src = re.sub(r'/s-l\d+\.', '/s-l1600.', src)
                    images.append(src)
        
        # Return requested index or empty string
        if index < len(images):
            return images[index]
        return ""
    
    def save_to_excel(self, products, filename=None):
        """Save products to Excel file"""
        if not products:
            print("No products to save")
            return None
        
        df = pd.DataFrame(products)
        
        # Generate filename if not provided
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"ebay_products_{timestamp}.xlsx"
        elif not filename.endswith('.xlsx'):
            filename += '.xlsx'
        
        # Save to Excel
        df.to_excel(filename, index=False)
        print(f"💾 Saved to: {filename}")
        
        # Display summary
        print(f"\n📊 Data Summary:")
        print(f"  • Total products: {len(df)}")
        print(f"  • Products with EAN: {df['EAN'].notna().sum()}")
        print(f"  • Products with all 4 images: {(df['Image_URL_4'] != '').sum()}")
        print(f"  • Average price: {df['Price'].str.replace('£', '').str.replace(',', '').astype(float, errors='ignore').mean():.2f}")
        
        return filename


def main():
    """Main execution"""
    scraper = FinalEbayScraper()
    
    # Your search query
    search_query = "blu ray"  # You can change this
    num_pages = 2  # Number of pages to scrape
    
    # Scrape products
    products = scraper.search_and_scrape(search_query, num_pages)
    
    # Save to Excel
    if products:
        filename = scraper.save_to_excel(products)
        
        # Show sample results
        print("\n📋 Sample Results (First 3 products):")
        print("="*60)
        for i, product in enumerate(products[:3], 1):
            print(f"\n{i}. {product['Title'][:60]}...")
            print(f"   💰 Price: {product['Price']}")
            print(f"   🔢 Item #: {product['Ebay_Item_Number']}")
            print(f"   📊 EAN: {product['EAN'] or 'Not found'}")
            print(f"   📸 Images: {sum(1 for k in ['Image_URL_1', 'Image_URL_2', 'Image_URL_3', 'Image_URL_4'] if product[k])} found")


if __name__ == "__main__":
    main()