#!/usr/bin/env python3
"""
Test real eBay search to verify URLs are being extracted correctly
"""

import requests
from bs4 import BeautifulSoup

def test_ebay_search():
    url = "https://www.ebay.co.uk/sch/i.html"
    params = {
        '_nkw': 'blu ray',
        '_sacat': '0',
        'LH_ItemCondition': '4'  # Used items
    }
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    }
    
    print("🔍 Searching eBay for 'blu ray'...")
    response = requests.get(url, params=params, headers=headers)
    
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find product links
        products = []
        for item in soup.select('.s-item'):
            link = item.select_one('.s-item__link')
            title = item.select_one('.s-item__title')
            price = item.select_one('.s-item__price')
            
            if link and link.get('href'):
                href = link.get('href')
                if '/itm/' in href:
                    products.append({
                        'url': href.split('?')[0],
                        'title': title.text if title else 'No title',
                        'price': price.text if price else 'No price'
                    })
        
        print(f"\n✅ Found {len(products)} products\n")
        
        # Show first 5
        for i, product in enumerate(products[:5], 1):
            print(f"{i}. {product['title'][:50]}...")
            print(f"   Price: {product['price']}")
            print(f"   URL: {product['url']}\n")
        
        return products
    else:
        print(f"❌ Error: Status code {response.status_code}")
        return []

if __name__ == "__main__":
    products = test_ebay_search()