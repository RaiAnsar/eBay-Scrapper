#!/usr/bin/env python3
"""
eBay Scraper with 2Captcha/CapSolver Integration
Bypasses "Pardon our interruption" with CAPTCHA solving service
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import time
import re
import json

class CaptchaSolverScraper:
    def __init__(self, captcha_api_key=None):
        """
        Initialize scraper with CAPTCHA solver
        
        Args:
            captcha_api_key: Your 2captcha.com API key
        """
        self.captcha_api_key = captcha_api_key
        self.session = requests.Session()
        
        # Browser-like headers
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
        })
        
        self.products = []
        self.seen_items = set()
    
    def solve_recaptcha_v2(self, site_key, page_url):
        """
        Solve reCAPTCHA v2 using 2captcha
        
        Args:
            site_key: The reCAPTCHA site key from the page
            page_url: The URL where the captcha appears
            
        Returns:
            The g-recaptcha-response token
        """
        if not self.captcha_api_key:
            print("❌ No CAPTCHA API key provided")
            return None
        
        print("🔄 Sending CAPTCHA to 2captcha...")
        
        # Step 1: Send captcha to 2captcha
        submit_url = "http://2captcha.com/in.php"
        submit_data = {
            'key': self.captcha_api_key,
            'method': 'userrecaptcha',
            'googlekey': site_key,
            'pageurl': page_url,
            'json': 1
        }
        
        response = requests.post(submit_url, data=submit_data)
        result = response.json()
        
        if result.get('status') != 1:
            print(f"❌ Failed to submit CAPTCHA: {result}")
            return None
        
        captcha_id = result.get('request')
        print(f"   CAPTCHA ID: {captcha_id}")
        
        # Step 2: Wait for solution
        result_url = "http://2captcha.com/res.php"
        result_params = {
            'key': self.captcha_api_key,
            'action': 'get',
            'id': captcha_id,
            'json': 1
        }
        
        # Poll for result (usually takes 15-60 seconds)
        for attempt in range(30):
            time.sleep(5)
            response = requests.get(result_url, params=result_params)
            result = response.json()
            
            if result.get('status') == 1:
                print("✅ CAPTCHA solved!")
                return result.get('request')
            elif result.get('request') == 'CAPCHA_NOT_READY':
                print(f"   Waiting... ({attempt*5}s)")
                continue
            else:
                print(f"❌ Error solving CAPTCHA: {result}")
                return None
        
        print("❌ CAPTCHA solving timeout")
        return None
    
    def solve_cloudflare_turnstile(self, site_key, page_url):
        """
        Solve Cloudflare Turnstile using 2captcha
        """
        if not self.captcha_api_key:
            print("❌ No CAPTCHA API key provided")
            return None
        
        print("🔄 Solving Cloudflare Turnstile...")
        
        submit_url = "http://2captcha.com/in.php"
        submit_data = {
            'key': self.captcha_api_key,
            'method': 'turnstile',
            'sitekey': site_key,
            'pageurl': page_url,
            'json': 1
        }
        
        response = requests.post(submit_url, data=submit_data)
        result = response.json()
        
        if result.get('status') != 1:
            print(f"❌ Failed to submit Turnstile: {result}")
            return None
        
        captcha_id = result.get('request')
        
        # Wait for solution
        result_url = "http://2captcha.com/res.php"
        result_params = {
            'key': self.captcha_api_key,
            'action': 'get',
            'id': captcha_id,
            'json': 1
        }
        
        for attempt in range(30):
            time.sleep(5)
            response = requests.get(result_url, params=result_params)
            result = response.json()
            
            if result.get('status') == 1:
                print("✅ Turnstile solved!")
                return result.get('request')
            elif result.get('request') == 'CAPCHA_NOT_READY':
                continue
        
        return None
    
    def handle_challenge_page(self, response):
        """
        Handle eBay's challenge page
        """
        print("⚠️ Challenge page detected")
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Check for different CAPTCHA types
        
        # 1. Check for reCAPTCHA
        recaptcha = soup.find('div', {'class': 'g-recaptcha'})
        if recaptcha:
            site_key = recaptcha.get('data-sitekey')
            if site_key:
                print(f"🔍 Found reCAPTCHA with site key: {site_key}")
                
                solution = self.solve_recaptcha_v2(site_key, response.url)
                if solution:
                    # Submit the solution
                    form = soup.find('form')
                    if form:
                        action = form.get('action')
                        if not action.startswith('http'):
                            action = 'https://www.ebay.co.uk' + action
                        
                        # Find all form inputs
                        form_data = {}
                        for inp in form.find_all('input'):
                            name = inp.get('name')
                            value = inp.get('value', '')
                            if name:
                                form_data[name] = value
                        
                        # Add CAPTCHA solution
                        form_data['g-recaptcha-response'] = solution
                        
                        print("📤 Submitting CAPTCHA solution...")
                        response = self.session.post(action, data=form_data)
                        return response
        
        # 2. Check for Cloudflare Turnstile
        turnstile = soup.find('div', {'class': 'cf-turnstile'})
        if turnstile:
            site_key = turnstile.get('data-sitekey')
            if site_key:
                print(f"🔍 Found Cloudflare Turnstile with site key: {site_key}")
                
                solution = self.solve_cloudflare_turnstile(site_key, response.url)
                if solution:
                    # Submit solution (implementation depends on the specific page)
                    pass
        
        # 3. Check for custom eBay challenge
        # This might require custom implementation based on what eBay uses
        
        return response
    
    def get_page_with_retry(self, url, max_retries=3):
        """
        Get page with automatic CAPTCHA solving on challenges
        """
        for attempt in range(max_retries):
            print(f"\n🌐 Fetching: {url}")
            
            response = self.session.get(url, timeout=30)
            print(f"   Status: {response.status_code}")
            print(f"   Size: {len(response.text)} bytes")
            
            # Check if we got a challenge
            if 'Pardon our interruption' in response.text or len(response.text) < 50000:
                print("⚠️ Challenge detected!")
                
                if self.captcha_api_key:
                    response = self.handle_challenge_page(response)
                    # Check if challenge was solved
                    if 'Pardon our interruption' not in response.text:
                        print("✅ Challenge solved!")
                        return response
                else:
                    print("❌ No CAPTCHA API key provided. Cannot bypass challenge.")
                    print("\n" + "="*70)
                    print("TO USE THIS SCRAPER, YOU NEED:")
                    print("1. Sign up at https://2captcha.com")
                    print("2. Add funds to your account ($3 minimum)")
                    print("3. Get your API key from the dashboard")
                    print("4. Run: scraper = CaptchaSolverScraper('YOUR_API_KEY')")
                    print("="*70)
                    return None
            else:
                # Page loaded successfully
                return response
        
        print(f"❌ Failed after {max_retries} attempts")
        return None
    
    def parse_products(self, html):
        """
        Parse products from HTML
        """
        soup = BeautifulSoup(html, 'html.parser')
        products = []
        
        # Find all product items
        items = soup.find_all('li', {'data-viewport': True})
        if not items:
            items = soup.find_all('li', class_='s-item')
        
        # Skip first 2 items (usually "Shop on eBay" placeholders)
        items = items[2:] if len(items) > 2 else items
        
        for item in items:
            try:
                # Extract product link
                link = item.find('a', href=re.compile(r'/itm/\d+'))
                if not link:
                    continue
                
                href = link.get('href', '')
                if not href.startswith('http'):
                    href = 'https://www.ebay.co.uk' + href
                
                # Extract item number
                match = re.search(r'/itm/(\d+)', href)
                if not match:
                    continue
                
                item_number = match.group(1)
                
                # Skip if already seen
                if item_number in self.seen_items:
                    continue
                
                self.seen_items.add(item_number)
                
                # Extract title
                title_elem = item.find('h3') or item.find('[role="heading"]')
                title = title_elem.get_text(strip=True) if title_elem else ''
                
                if not title or 'Shop on eBay' in title:
                    continue
                
                # Extract price
                price_elem = item.find('span', class_='s-item__price')
                price = price_elem.get_text(strip=True) if price_elem else ''
                
                # Extract condition
                condition_elem = item.find('span', class_='SECONDARY_INFO')
                condition = condition_elem.get_text(strip=True) if condition_elem else ''
                
                product = {
                    'Item_Number': item_number,
                    'Title': title,
                    'Price': price,
                    'Condition': condition,
                    'URL': href,
                    'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                products.append(product)
                
            except Exception as e:
                continue
        
        return products
    
    def scrape(self, search_term, max_pages=3):
        """
        Main scraping function
        """
        print("\n" + "="*70)
        print("🤖 eBay Scraper with CAPTCHA Solver")
        print("="*70)
        print(f"🔍 Search: {search_term}")
        print(f"📄 Max pages: {max_pages}")
        print(f"🔑 API Key: {'Configured' if self.captcha_api_key else 'Not configured'}")
        print("="*70)
        
        for page_num in range(1, max_pages + 1):
            print(f"\n📄 Page {page_num}")
            print("-" * 40)
            
            # Build URL
            url = f"https://www.ebay.co.uk/sch/i.html?_nkw={search_term.replace(' ', '+')}"
            if page_num > 1:
                url += f"&_pgn={page_num}"
            url += "&_ipg=200"  # 200 items per page
            
            # Get page with automatic CAPTCHA solving
            response = self.get_page_with_retry(url)
            
            if response:
                # Parse products
                products = self.parse_products(response.text)
                print(f"✅ Found {len(products)} products")
                
                if products:
                    self.products.extend(products)
                    
                    # Show sample products
                    print("📋 Sample products:")
                    for i, p in enumerate(products[:3], 1):
                        print(f"   {i}. {p['Title'][:50]}...")
            else:
                print("❌ Failed to load page")
                break
            
            # Delay between pages
            if page_num < max_pages:
                delay = 3
                print(f"⏳ Waiting {delay} seconds...")
                time.sleep(delay)
        
        # Save results
        if self.products:
            df = pd.DataFrame(self.products)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            excel_file = f"ebay_captcha_{timestamp}.xlsx"
            df.to_excel(excel_file, index=False)
            
            print(f"\n" + "="*70)
            print(f"✅ Scraped {len(self.products)} products")
            print(f"📁 Saved to: {excel_file}")
            print("="*70)
            
            return excel_file
        else:
            print("\n❌ No products scraped")
            return None

# Example usage
if __name__ == "__main__":
    # TO USE THIS:
    # 1. Sign up at https://2captcha.com
    # 2. Add funds ($3 minimum, ~$1 per 1000 CAPTCHAs)
    # 3. Get your API key from dashboard
    
    # Replace with your actual API key
    API_KEY = "YOUR_2CAPTCHA_API_KEY_HERE"
    
    if API_KEY == "YOUR_2CAPTCHA_API_KEY_HERE":
        print("\n" + "="*70)
        print("⚠️ CAPTCHA SOLVER SETUP REQUIRED")
        print("="*70)
        print("\nTo use this scraper, you need a 2captcha.com account:")
        print("1. Sign up at: https://2captcha.com/register")
        print("2. Add funds: $3 minimum (costs ~$1 per 1000 CAPTCHAs)")
        print("3. Get API key from: https://2captcha.com/enterpage")
        print("4. Replace API_KEY in this script")
        print("\nAlternatively, use CapSolver.com which has similar pricing")
        print("="*70)
        
        # Run without CAPTCHA solving (will fail on challenges)
        scraper = CaptchaSolverScraper()
    else:
        # Run with CAPTCHA solving
        scraper = CaptchaSolverScraper(API_KEY)
    
    result = scraper.scrape(
        search_term="blu ray",
        max_pages=3
    )
    
    if result:
        print(f"\n✅ Success! Check: {result}")
    else:
        print("\n❌ Scraping failed - likely due to CAPTCHA challenges")