#!/usr/bin/env python3
"""
Simplified eBay Scraper Test - Uses only standard library + requests
This version avoids compilation issues with aiohttp/pandas on Python 3.13
"""

import requests
import json
import time
import re
from urllib.parse import urlencode, urlparse, parse_qs
from bs4 import BeautifulSoup
from typing import List, Dict, Optional
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SimpleEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
    
    def get_total_pages(self, url: str) -> int:
        """Get total number of pages from search results"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for pagination info
            pagination_selectors = [
                '.pagination__items .pagination__item:last-child a',
                '.pages a:last-child',
                '.pagination a:last-child',
                '[data-testid="pagination"] a:last-child'
            ]
            
            for selector in pagination_selectors:
                element = soup.select_one(selector)
                if element and element.get_text().strip().isdigit():
                    return int(element.get_text().strip())
            
            # Look for "X of Y" pattern
            result_text = soup.get_text()
            page_match = re.search(r'(\d+)\s*of\s*(\d+)\s*pages?', result_text, re.IGNORECASE)
            if page_match:
                return int(page_match.group(2))
            
            return 1
            
        except Exception as e:
            logger.error(f"Error getting total pages: {e}")
            return 1
    
    def extract_products(self, html: str) -> List[Dict]:
        """Extract product information from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        products = []
        
        # Multiple selectors for different eBay layouts
        product_selectors = [
            '.s-item',
            '.srp-results .s-item',
            '[data-testid="item-card"]',
            '.item',
            '.lvresult'
        ]
        
        items = []
        for selector in product_selectors:
            items = soup.select(selector)
            if items:
                logger.info(f"Found {len(items)} items using selector: {selector}")
                break
        
        for item in items:
            try:
                product = {}
                
                # Title
                title_selectors = [
                    '.s-item__title',
                    '.it-ttl a',
                    '[data-testid="item-title"]',
                    '.lvtitle a',
                    'h3 a'
                ]
                
                for selector in title_selectors:
                    title_elem = item.select_one(selector)
                    if title_elem:
                        product['title'] = title_elem.get_text().strip()
                        break
                
                # Price
                price_selectors = [
                    '.s-item__price',
                    '.notranslate',
                    '[data-testid="item-price"]',
                    '.lvprice .prc',
                    '.price'
                ]
                
                for selector in price_selectors:
                    price_elem = item.select_one(selector)
                    if price_elem:
                        price_text = price_elem.get_text().strip()
                        # Extract numeric price
                        price_match = re.search(r'[\d,]+\.?\d*', price_text.replace(',', ''))
                        if price_match:
                            product['price'] = price_match.group()
                        product['price_raw'] = price_text
                        break
                
                # URL
                url_selectors = [
                    '.s-item__link',
                    '.it-ttl a',
                    '[data-testid="item-title"] a',
                    '.lvtitle a',
                    'h3 a'
                ]
                
                for selector in url_selectors:
                    url_elem = item.select_one(selector)
                    if url_elem and url_elem.get('href'):
                        product['url'] = url_elem.get('href')
                        break
                
                # Image
                img_selectors = [
                    '.s-item__image img',
                    '.img img',
                    '[data-testid="item-image"] img',
                    '.lvpic img'
                ]
                
                for selector in img_selectors:
                    img_elem = item.select_one(selector)
                    if img_elem and img_elem.get('src'):
                        product['image'] = img_elem.get('src')
                        break
                
                # Only add if we have at least title
                if product.get('title'):
                    products.append(product)
                    
            except Exception as e:
                logger.error(f"Error extracting product: {e}")
                continue
        
        return products
    
    def scrape_page(self, url: str, page: int = 1) -> List[Dict]:
        """Scrape a single page"""
        try:
            # Add page parameter to URL
            if page > 1:
                separator = '&' if '?' in url else '?'
                url = f"{url}{separator}_pgn={page}"
            
            logger.info(f"Scraping page {page}: {url}")
            
            response = self.session.get(url, timeout=15)
            response.raise_for_status()
            
            products = self.extract_products(response.text)
            logger.info(f"Found {len(products)} products on page {page}")
            
            return products
            
        except Exception as e:
            logger.error(f"Error scraping page {page}: {e}")
            return []
    
    def scrape_url(self, url: str, max_pages: int = 5) -> Dict:
        """Scrape multiple pages from a URL"""
        start_time = time.time()
        all_products = []
        
        try:
            # Get total pages
            total_pages = min(self.get_total_pages(url), max_pages)
            logger.info(f"Will scrape {total_pages} pages")
            
            # Scrape each page
            for page in range(1, total_pages + 1):
                products = self.scrape_page(url, page)
                all_products.extend(products)
                
                # Rate limiting
                if page < total_pages:
                    time.sleep(1)
            
            elapsed = time.time() - start_time
            
            return {
                'url': url,
                'products': all_products,
                'total_products': len(all_products),
                'pages_scraped': total_pages,
                'time_elapsed': elapsed
            }
            
        except Exception as e:
            logger.error(f"Error scraping URL: {e}")
            return {
                'url': url,
                'products': [],
                'total_products': 0,
                'pages_scraped': 0,
                'time_elapsed': time.time() - start_time,
                'error': str(e)
            }

def main():
    """Test the scraper with the provided eBay URL"""
    # Test URL from user
    test_url = "https://www.ebay.com/sch/i.html?_from=R40&_trksid=p4432023.m570.l1313&_nkw=iphone+15+pro+max&_sacat=0"
    
    scraper = SimpleEbayScraper()
    
    logger.info("Starting eBay scraper test...")
    logger.info(f"Test URL: {test_url}")
    
    # Scrape the URL
    result = scraper.scrape_url(test_url, max_pages=3)
    
    # Print results
    print("\n" + "="*50)
    print("SCRAPING RESULTS")
    print("="*50)
    print(f"URL: {result['url']}")
    print(f"Total Products: {result['total_products']}")
    print(f"Pages Scraped: {result['pages_scraped']}")
    print(f"Time Elapsed: {result['time_elapsed']:.2f}s")
    
    if result.get('error'):
        print(f"Error: {result['error']}")
    
    # Show first few products
    if result['products']:
        print("\nFirst 3 products:")
        for i, product in enumerate(result['products'][:3], 1):
            print(f"\n{i}. {product.get('title', 'No title')}")
            print(f"   Price: {product.get('price_raw', 'No price')}")
            print(f"   URL: {product.get('url', 'No URL')[:80]}...")
    
    # Save results
    output_file = 'simple_test_results.json'
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2)
    
    print(f"\nResults saved to: {output_file}")
    print("\nTest completed!")

if __name__ == "__main__":
    main()