#!/usr/bin/env python3
"""
Improved Web Interface for eBay Scraper
- Accepts both keywords AND full eBay search URLs
- Handles duplicate detection by Item Number and EAN
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional
import asyncio
import pandas as pd
from datetime import datetime
import re
import os
from simple_ebay_scraper import SimpleEbayScraper

app = FastAPI(title="eBay Scraper Dashboard")

# Store scraping tasks and results
tasks = {}
task_counter = 0
all_scraped_items = {}  # Store all items for duplicate detection

class ScrapeRequest(BaseModel):
    urls: Optional[List[str]] = None
    search_query: Optional[str] = None
    max_pages: int = 1
    use_playwright: bool = False
    output_format: str = "excel"
    remove_duplicates: bool = True

@app.get("/", response_class=HTMLResponse)
async def home():
    """Serve the improved dashboard"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>eBay Scraper Dashboard</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                padding: 30px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            h1 {
                color: #333;
                margin-bottom: 10px;
                font-size: 2.5em;
            }
            .subtitle {
                color: #666;
                margin-bottom: 30px;
                font-size: 1.1em;
            }
            .tabs {
                display: flex;
                gap: 10px;
                margin-bottom: 30px;
                border-bottom: 2px solid #e0e0e0;
            }
            .tab {
                padding: 12px 24px;
                background: none;
                border: none;
                cursor: pointer;
                font-size: 16px;
                color: #666;
                transition: all 0.3s;
            }
            .tab.active {
                color: #667eea;
                border-bottom: 3px solid #667eea;
                margin-bottom: -2px;
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                color: #555;
                font-weight: 500;
            }
            input, textarea, select {
                width: 100%;
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            input:focus, textarea:focus, select:focus {
                outline: none;
                border-color: #667eea;
            }
            textarea {
                min-height: 120px;
                resize: vertical;
            }
            button {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                padding: 14px 28px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: transform 0.2s;
            }
            button:hover {
                transform: translateY(-2px);
            }
            .alert {
                background: #fff3cd;
                border: 2px solid #ffc107;
                color: #856404;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
            }
            .success {
                background: #d4edda;
                border: 2px solid #28a745;
                color: #155724;
            }
            .info-box {
                background: #e8f4ff;
                border: 2px solid #b8e0ff;
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 20px;
            }
            .info-box h3 {
                color: #0066cc;
                margin-bottom: 10px;
            }
            .checkbox-group {
                display: flex;
                align-items: center;
                gap: 10px;
                margin: 15px 0;
            }
            .example-urls {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 8px;
                margin-top: 10px;
                font-size: 14px;
                color: #666;
            }
            .example-urls h4 {
                color: #333;
                margin-bottom: 8px;
            }
            .stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }
            .stat-card {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 12px;
                text-align: center;
                border: 2px solid #e0e0e0;
            }
            .stat-value {
                font-size: 2em;
                font-weight: bold;
                color: #667eea;
            }
            .stat-label {
                color: #666;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🛒 eBay Scraper Dashboard</h1>
            <p class="subtitle">Professional eBay data extraction - Handles search URLs & duplicate detection!</p>
            
            <div class="stats" id="stats">
                <div class="stat-card">
                    <div class="stat-value" id="total-scraped">0</div>
                    <div class="stat-label">Total Products Scraped</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="unique-items">0</div>
                    <div class="stat-label">Unique Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="duplicates">0</div>
                    <div class="stat-label">Duplicates Removed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="tasks-completed">0</div>
                    <div class="stat-label">Tasks Completed</div>
                </div>
            </div>
            
            <div class="info-box">
                <h3>✨ Enhanced Features</h3>
                <ul>
                    <li>✅ Accepts full eBay search URLs (just paste them in!)</li>
                    <li>✅ Automatic duplicate detection by Item Number & EAN</li>
                    <li>✅ Skips variations and sponsored content</li>
                    <li>✅ Handles pagination automatically</li>
                    <li>✅ Extracts: Title, Price, Item #, EAN, 4 Image URLs</li>
                </ul>
            </div>
            
            <div class="tabs">
                <button class="tab active" onclick="showTab('search-scrape')">Scrape Search Results</button>
                <button class="tab" onclick="showTab('url-scrape')">Scrape Individual Products</button>
                <button class="tab" onclick="showTab('bulk-search')">Bulk Search URLs</button>
            </div>
            
            <div id="search-scrape" class="tab-content active">
                <form onsubmit="submitSearchScrape(event)">
                    <div class="form-group">
                        <label>🔗 eBay Search URL or Keywords</label>
                        <input type="text" name="query" 
                               placeholder="Paste URL: https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray OR Keywords: blu ray" 
                               required>
                        
                        <div class="example-urls">
                            <h4>Examples:</h4>
                            • Full URL: https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_sacat=0<br>
                            • Keywords: blu ray musicmagpie<br>
                            • Category URL: https://www.ebay.co.uk/sch/617/i.html?_nkw=4k
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>📄 Number of Pages to Scrape</label>
                        <input type="number" name="pages" min="1" max="50" value="1">
                    </div>
                    
                    <div class="form-group">
                        <label>📊 Output Format</label>
                        <select name="format">
                            <option value="excel">Excel (.xlsx)</option>
                            <option value="csv">CSV</option>
                            <option value="json">JSON</option>
                        </select>
                    </div>
                    
                    <div class="checkbox-group">
                        <input type="checkbox" id="duplicates" name="duplicates" checked>
                        <label for="duplicates">Remove duplicates (by Item # and EAN)</label>
                    </div>
                    
                    <button type="submit">🚀 Start Scraping</button>
                </form>
            </div>
            
            <div id="url-scrape" class="tab-content">
                <form onsubmit="submitUrlScrape(event)">
                    <div class="form-group">
                        <label>📦 Individual Product URLs (one per line)</label>
                        <textarea name="urls" 
                                  placeholder="https://www.ebay.co.uk/itm/123456789
https://www.ebay.co.uk/itm/987654321" 
                                  required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Output Format</label>
                        <select name="format">
                            <option value="excel">Excel (.xlsx)</option>
                            <option value="csv">CSV</option>
                            <option value="json">JSON</option>
                        </select>
                    </div>
                    <button type="submit">Start Scraping</button>
                </form>
            </div>
            
            <div id="bulk-search" class="tab-content">
                <form onsubmit="submitBulkSearch(event)">
                    <div class="form-group">
                        <label>🔗 Multiple Search URLs (one per line)</label>
                        <textarea name="searches" 
                                  placeholder="https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray
https://www.ebay.co.uk/sch/i.html?_nkw=4k+ultra+hd
https://www.ebay.co.uk/sch/i.html?_nkw=dvd+box+set" 
                                  required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Pages per Search</label>
                        <input type="number" name="pages" min="1" max="10" value="2">
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" id="bulk-duplicates" name="duplicates" checked>
                        <label for="bulk-duplicates">Remove duplicates across all searches</label>
                    </div>
                    <button type="submit">🚀 Start Bulk Scraping</button>
                </form>
            </div>
            
            <div id="results" style="margin-top: 30px;"></div>
        </div>
        
        <script>
            function showTab(tabName) {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                event.target.classList.add('active');
                document.getElementById(tabName).classList.add('active');
            }
            
            async function submitSearchScrape(event) {
                event.preventDefault();
                const formData = new FormData(event.target);
                
                const query = formData.get('query').trim();
                
                // Detect if it's a URL or keywords
                const isUrl = query.startsWith('http');
                
                const response = await fetch('/scrape', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        search_query: query,
                        max_pages: parseInt(formData.get('pages')),
                        output_format: formData.get('format'),
                        remove_duplicates: formData.get('duplicates') === 'on'
                    })
                });
                
                const result = await response.json();
                showResult(result);
                updateStats();
            }
            
            async function submitUrlScrape(event) {
                event.preventDefault();
                const formData = new FormData(event.target);
                const urls = formData.get('urls').split('\\n').filter(u => u.trim());
                
                const response = await fetch('/scrape', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        urls: urls,
                        output_format: formData.get('format')
                    })
                });
                
                const result = await response.json();
                showResult(result);
            }
            
            async function submitBulkSearch(event) {
                event.preventDefault();
                const formData = new FormData(event.target);
                const searches = formData.get('searches').split('\\n').filter(s => s.trim());
                
                for (let search of searches) {
                    await fetch('/scrape', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            search_query: search,
                            max_pages: parseInt(formData.get('pages')),
                            remove_duplicates: formData.get('duplicates') === 'on'
                        })
                    });
                }
                
                showResult({message: 'Bulk scraping started for ' + searches.length + ' searches'});
                updateStats();
            }
            
            function showResult(result) {
                const resultDiv = document.getElementById('results');
                resultDiv.innerHTML = `
                    <div class="alert success">
                        ✅ ${result.message || 'Task started successfully'}
                        ${result.task_id ? '<br>Task ID: ' + result.task_id : ''}
                        ${result.download_link ? '<br><a href="' + result.download_link + '">Download Results</a>' : ''}
                    </div>
                `;
            }
            
            async function updateStats() {
                const response = await fetch('/stats');
                const stats = await response.json();
                document.getElementById('total-scraped').textContent = stats.total_scraped || 0;
                document.getElementById('unique-items').textContent = stats.unique_items || 0;
                document.getElementById('duplicates').textContent = stats.duplicates_removed || 0;
                document.getElementById('tasks-completed').textContent = stats.tasks_completed || 0;
            }
            
            // Update stats on load
            updateStats();
            setInterval(updateStats, 5000);  // Update every 5 seconds
        </script>
    </body>
    </html>
    """

@app.post("/scrape")
async def create_scrape_task(request: ScrapeRequest, background_tasks: BackgroundTasks):
    """Create a new scraping task - handles both URLs and keywords"""
    global task_counter
    task_counter += 1
    
    # Process search query - detect if it's a URL or keywords
    search_input = request.search_query or ""
    
    # Clean and process the input
    if search_input.startswith('http'):
        # It's a full URL - use it directly
        message = f"Scraping eBay URL: {search_input[:50]}..."
    else:
        # It's keywords
        message = f"Searching for: {search_input}"
    
    background_tasks.add_task(
        run_scraping_task, 
        task_counter, 
        search_input,
        request.max_pages,
        request.output_format,
        request.remove_duplicates
    )
    
    return {
        "task_id": task_counter,
        "message": message
    }

async def run_scraping_task(task_id: int, search_input: str, max_pages: int, output_format: str, remove_duplicates: bool):
    """Run the actual scraping task"""
    global all_scraped_items
    
    scraper = SimpleEbayScraper()
    
    # Handle both URLs and keywords
    if search_input.startswith('http'):
        # Extract search query from URL
        if '_nkw=' in search_input:
            query = search_input.split('_nkw=')[1].split('&')[0]
            query = query.replace('+', ' ').replace('%20', ' ')
        else:
            query = "search"
    else:
        query = search_input
    
    # Search and get products
    urls = scraper.search_products(query, max_pages)
    
    if urls:
        products = scraper.scrape_multiple(urls)
        
        # Remove duplicates if requested
        if remove_duplicates and products:
            unique_products = []
            seen_items = set()
            seen_eans = set()
            
            for product in products:
                item_num = product.get('item_number', '')
                ean = product.get('ean', '')
                
                # Check for duplicates
                if item_num and item_num not in seen_items:
                    seen_items.add(item_num)
                    if ean:
                        seen_eans.add(ean)
                    unique_products.append(product)
                elif ean and ean not in seen_eans:
                    seen_eans.add(ean)
                    unique_products.append(product)
                elif not item_num and not ean:
                    # No identifiers, include it
                    unique_products.append(product)
            
            products = unique_products
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if output_format == "excel":
            filename = f"ebay_results_{task_id}_{timestamp}.xlsx"
            scraper.save_to_excel(products, filename)
        elif output_format == "csv":
            filename = f"ebay_results_{task_id}_{timestamp}.csv"
            scraper.save_to_csv(products, filename)
        else:
            filename = f"ebay_results_{task_id}_{timestamp}.json"
            import json
            with open(filename, 'w') as f:
                json.dump(products, f, indent=2, default=str)
        
        # Update global tracking
        for product in products:
            item_num = product.get('item_number', '')
            if item_num:
                all_scraped_items[item_num] = product
        
        return {"success": True, "products": len(products), "file": filename}

@app.get("/stats")
async def get_stats():
    """Get scraping statistics"""
    global all_scraped_items, task_counter
    
    unique_eans = set()
    for item in all_scraped_items.values():
        if item.get('ean'):
            unique_eans.add(item['ean'])
    
    return {
        "total_scraped": len(all_scraped_items),
        "unique_items": len(all_scraped_items),
        "unique_eans": len(unique_eans),
        "tasks_completed": task_counter,
        "duplicates_removed": 0  # Track this separately if needed
    }

@app.get("/download/{filename}")
async def download_file(filename: str):
    """Download result file"""
    if os.path.exists(filename):
        return FileResponse(filename, media_type="application/octet-stream", filename=filename)
    raise HTTPException(status_code=404, detail="File not found")

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Improved eBay Scraper Dashboard...")
    print("📍 Open http://localhost:8001 in your browser")
    uvicorn.run(app, host="0.0.0.0", port=8001)