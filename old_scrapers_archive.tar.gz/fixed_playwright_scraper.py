#!/usr/bin/env python3
"""
FIXED Playwright eBay Scraper - Properly skips placeholders
"""

import asyncio
from playwright.async_api import async_playwright
import pandas as pd
from datetime import datetime
import random
import json
import os

class FixedEbayScraper:
    def __init__(self):
        self.products_scraped = 0
        self.seen_items = set()
        self.all_products = []
        
    async def scrape_ebay(self, search_url: str, max_pages: int = 5):
        """Main scraping function - FIXED version"""
        
        print("\n" + "="*70)
        print("🎯 FIXED eBay Scraper - Working Version")
        print("="*70)
        print(f"📍 URL: {search_url}")
        print(f"📄 Max pages: {max_pages}")
        print(f"🖥️  Browser: Visible (avoids detection)")
        print("="*70 + "\n")
        
        async with async_playwright() as p:
            # Launch VISIBLE browser
            browser = await p.chromium.launch(
                headless=False,  # VISIBLE BROWSER
                args=['--disable-blink-features=AutomationControlled']
            )
            
            context = await browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
            # Anti-detection script
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            """)
            
            page = await context.new_page()
            
            # Start with eBay homepage
            print("🌐 Establishing session...")
            await page.goto('https://www.ebay.co.uk')
            await page.wait_for_timeout(2000)
            
            # Accept cookies if present
            try:
                await page.click('#gdpr-banner-accept', timeout=2000)
                print("🍪 Cookies accepted")
            except:
                pass
            
            # Main scraping loop
            for page_num in range(1, max_pages + 1):
                print(f"\n📄 Page {page_num}")
                print("-" * 40)
                
                # Build URL with pagination
                if page_num == 1:
                    url = search_url
                else:
                    separator = '&' if '?' in search_url else '?'
                    url = f"{search_url}{separator}_pgn={page_num}"
                
                try:
                    # Navigate to page
                    await page.goto(url, wait_until='networkidle', timeout=30000)
                    await page.wait_for_timeout(random.randint(2000, 3000))
                    
                    # Scroll to load lazy images
                    await page.evaluate('window.scrollTo(0, document.body.scrollHeight/2)')
                    await page.wait_for_timeout(1000)
                    
                    # Extract products - FIXED to skip "Shop on eBay" items
                    products = await page.evaluate('''() => {
                        const items = [];
                        const elements = document.querySelectorAll('li[data-viewport]');
                        
                        console.log('Found', elements.length, 'total elements');
                        
                        // Skip first 2 "Shop on eBay" placeholders
                        for(let i = 2; i < elements.length; i++) {
                            const item = elements[i];
                            
                            // Find the product link
                            const link = item.querySelector('a[href*="/itm/"]');
                            if (!link) continue;
                            
                            const href = link.href;
                            const match = href.match(/\\/itm\\/(\\d+)/);
                            if (!match) continue;
                            
                            // Extract title - try multiple selectors
                            let title = '';
                            
                            // Method 1: h3 tag
                            let titleElem = item.querySelector('h3');
                            if (!titleElem) {
                                // Method 2: role="heading"
                                titleElem = item.querySelector('[role="heading"]');
                            }
                            if (!titleElem) {
                                // Method 3: s-item__title class
                                titleElem = item.querySelector('.s-item__title');
                            }
                            
                            if (titleElem) {
                                title = titleElem.innerText || titleElem.textContent || '';
                                title = title.trim();
                            }
                            
                            // Skip if title is still "Shop on eBay" or empty
                            if (!title || title === 'Shop on eBay' || title === 'New Listing') {
                                continue;
                            }
                            
                            // Extract price
                            const priceElem = item.querySelector('.s-item__price');
                            const price = priceElem ? priceElem.innerText.trim() : '';
                            
                            // Extract condition
                            const condElem = item.querySelector('.SECONDARY_INFO');
                            const condition = condElem ? condElem.innerText.trim() : '';
                            
                            // Extract shipping
                            const shipElem = item.querySelector('.s-item__shipping');
                            const shipping = shipElem ? shipElem.innerText.trim() : '';
                            
                            // Extract image
                            const imgElem = item.querySelector('img');
                            let image = '';
                            if (imgElem) {
                                image = imgElem.src || imgElem.dataset.src || '';
                                // Get larger image
                                if (image.includes('s-l140')) {
                                    image = image.replace('s-l140', 's-l500');
                                }
                            }
                            
                            items.push({
                                item_number: match[1],
                                title: title,
                                price: price,
                                condition: condition,
                                shipping: shipping,
                                image: image,
                                url: href
                            });
                        }
                        
                        return items;
                    }''')
                    
                    print(f"📦 Found {len(products)} products on page")
                    
                    # Process new products only
                    new_products = []
                    for p in products:
                        if p['item_number'] not in self.seen_items:
                            self.seen_items.add(p['item_number'])
                            
                            product = {
                                'Ebay_Item_Number': p['item_number'],
                                'Title': p['title'],
                                'Price': p['price'],
                                'Condition': p['condition'],
                                'Shipping': p['shipping'],
                                'Image_URL': p['image'],
                                'URL': p['url'],
                                'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            }
                            new_products.append(product)
                            
                    print(f"✅ {len(new_products)} new products (skipped {len(products)-len(new_products)} duplicates)")
                    
                    self.all_products.extend(new_products)
                    self.products_scraped += len(new_products)
                    
                    # Show some product titles as proof
                    if new_products:
                        print("📋 Sample products:")
                        for i, prod in enumerate(new_products[:3], 1):
                            print(f"   {i}. {prod['Title'][:60]}...")
                    
                    if len(products) == 0:
                        print("📭 No more products found")
                        break
                    
                except Exception as e:
                    print(f"❌ Error on page {page_num}: {str(e)}")
                
                # Human-like delay between pages
                if page_num < max_pages:
                    delay = random.randint(3000, 5000)
                    print(f"⏳ Waiting {delay/1000}s before next page...")
                    await page.wait_for_timeout(delay)
            
            print("\n🏁 Scraping complete, closing browser...")
            await browser.close()
        
        # Save results
        if self.all_products:
            df = pd.DataFrame(self.all_products)
            filename = f"ebay_fixed_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(filename, index=False)
            
            # Also save CSV
            csv_file = filename.replace('.xlsx', '.csv')
            df.to_csv(csv_file, index=False)
            
            print(f"\n" + "="*70)
            print("📊 FINAL RESULTS")
            print("="*70)
            print(f"✅ Total products: {len(self.all_products)}")
            print(f"📁 Excel saved: {filename}")
            print(f"📁 CSV saved: {csv_file}")
            print("="*70)
        else:
            print("\n❌ No products scraped")
        
        return self.all_products

# Main execution
async def main():
    scraper = FixedEbayScraper()
    
    search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray"
    
    # Scrape 3 pages as a test
    products = await scraper.scrape_ebay(
        search_url,
        max_pages=3
    )
    
    print(f"\n✅ Scraped {len(products)} products total")

if __name__ == "__main__":
    print("\n🚀 Starting FIXED eBay Scraper...")
    print("📌 This will open a visible browser window")
    print("📌 Please don't close it while scraping\n")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️ Scraping interrupted by user")
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")