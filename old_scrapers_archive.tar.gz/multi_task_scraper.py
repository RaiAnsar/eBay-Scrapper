#!/usr/bin/env python3
"""
Multi-Task eBay Scraper
Handle multiple search URLs with task queue system
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from datetime import datetime
import re
import json
import threading
from queue import Queue
import os

class MultiTaskEbayScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.task_queue = Queue()
        self.results = {}
        self.task_status = {}
        self.task_counter = 0
    
    def add_task(self, search_url_or_query, num_pages=1, task_name=None):
        """Add a scraping task to the queue"""
        self.task_counter += 1
        task_id = f"task_{self.task_counter}"
        
        if not task_name:
            task_name = f"Task {self.task_counter}"
        
        task = {
            'id': task_id,
            'name': task_name,
            'search': search_url_or_query,
            'pages': num_pages,
            'status': 'pending',
            'progress': 0,
            'total': 0,
            'created': datetime.now().isoformat()
        }
        
        self.task_status[task_id] = task
        self.task_queue.put(task)
        
        print(f"✅ Added {task_name} (ID: {task_id})")
        return task_id
    
    def process_task(self, task):
        """Process a single scraping task"""
        task_id = task['id']
        self.task_status[task_id]['status'] = 'running'
        self.task_status[task_id]['started'] = datetime.now().isoformat()
        
        print(f"\n🚀 Starting {task['name']}")
        print(f"   Search: {task['search']}")
        print(f"   Pages: {task['pages']}")
        
        all_products = []
        
        for page in range(1, task['pages'] + 1):
            print(f"\n   📄 Page {page}/{task['pages']}...")
            
            # Get search results
            products_on_page = self.scrape_search_page(task['search'], page)
            
            if products_on_page:
                all_products.extend(products_on_page)
                self.task_status[task_id]['progress'] = page
                self.task_status[task_id]['total'] = len(all_products)
                print(f"      Found {len(products_on_page)} products")
            
            time.sleep(1)  # Rate limiting between pages
        
        # Update task status
        self.task_status[task_id]['status'] = 'completed'
        self.task_status[task_id]['completed'] = datetime.now().isoformat()
        self.task_status[task_id]['total'] = len(all_products)
        
        # Store results
        self.results[task_id] = all_products
        
        print(f"\n✅ Completed {task['name']}: {len(all_products)} products")
        return all_products
    
    def scrape_search_page(self, search_query, page=1):
        """Scrape a single search results page"""
        # Handle both URLs and search queries
        if search_query.startswith('http'):
            # Parse existing URL
            base_url = search_query.split('?')[0]
            if '_nkw=' in search_query:
                query = search_query.split('_nkw=')[1].split('&')[0].replace('+', ' ')
            else:
                query = "blu ray"
        else:
            base_url = "https://www.ebay.co.uk/sch/i.html"
            query = search_query
        
        params = {
            '_nkw': query,
            '_pgn': page,
            '_ipg': 240
        }
        
        try:
            response = self.session.get(base_url, params=params, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            products = []
            items = soup.select('.srp-results .s-item')
            
            for item in items:
                # Skip sponsored/variations
                text = item.get_text()
                if any(skip in text for skip in ['SPONSORED', 'Picked for you', 'variation', 'choose']):
                    continue
                
                # Get link
                link = item.select_one('.s-item__link')
                if not link or '/itm/' not in link.get('href', ''):
                    continue
                
                # Extract item ID
                href = link.get('href')
                item_match = re.search(r'/itm/(\d+)', href)
                if not item_match:
                    continue
                
                item_id = item_match.group(1)
                
                # Get title
                title_elem = item.select_one('.s-item__title')
                title = title_elem.get_text(strip=True) if title_elem else ""
                
                # Skip if no real title
                if not title or 'Shop on eBay' in title:
                    continue
                
                # Get price
                price_elem = item.select_one('.s-item__price')
                price = price_elem.get_text(strip=True) if price_elem else ""
                
                # Get images
                img_elem = item.select_one('.s-item__image-wrapper img')
                main_image = img_elem.get('src', '') if img_elem else ""
                
                # Get condition
                condition_elem = item.select_one('.SECONDARY_INFO')
                condition = condition_elem.get_text(strip=True) if condition_elem else ""
                
                # Get seller
                seller_elem = item.select_one('.s-item__seller-info-text')
                seller = seller_elem.get_text(strip=True) if seller_elem else ""
                
                products.append({
                    'Title': title,
                    'Price': price,
                    'Ebay_Item_Number': item_id,
                    'EAN': '',  # Will need product page for this
                    'Image_URL_1': main_image,
                    'Image_URL_2': '',
                    'Image_URL_3': '',
                    'Image_URL_4': '',
                    'Condition': condition,
                    'Seller': seller,
                    'URL': f"https://www.ebay.co.uk/itm/{item_id}",
                    'Scraped_At': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
            
            return products
            
        except Exception as e:
            print(f"      ❌ Error: {e}")
            return []
    
    def run_all_tasks(self):
        """Process all queued tasks"""
        print(f"\n{'='*60}")
        print(f"🔄 Processing {self.task_queue.qsize()} tasks...")
        print(f"{'='*60}")
        
        while not self.task_queue.empty():
            task = self.task_queue.get()
            self.process_task(task)
            time.sleep(2)  # Delay between tasks
    
    def save_all_results(self, base_filename="ebay_results"):
        """Save all task results to separate Excel files"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        for task_id, products in self.results.items():
            if products:
                task_info = self.task_status[task_id]
                # Clean task name for filename
                clean_name = re.sub(r'[^a-zA-Z0-9_-]', '_', task_info['name'])
                filename = f"{base_filename}_{clean_name}_{timestamp}.xlsx"
                
                df = pd.DataFrame(products)
                df.to_excel(filename, index=False)
                
                print(f"💾 Saved {task_info['name']}: {filename} ({len(products)} products)")
    
    def get_status(self):
        """Get status of all tasks"""
        print(f"\n📊 Task Status Report")
        print(f"{'='*60}")
        
        for task_id, status in self.task_status.items():
            print(f"\n{status['name']} ({task_id}):")
            print(f"  Status: {status['status']}")
            print(f"  Progress: {status['progress']}/{status['pages']} pages")
            print(f"  Products found: {status['total']}")
            
            if status['status'] == 'completed':
                print(f"  Completed: {status.get('completed', 'N/A')}")


def main():
    """Example: Running multiple search tasks"""
    print("\n" + "="*60)
    print("🛒 Multi-Task eBay Scraper")
    print("="*60 + "\n")
    
    scraper = MultiTaskEbayScraper()
    
    # Add multiple search tasks
    print("📝 Adding multiple search tasks...\n")
    
    # Task 1: Your URL
    scraper.add_task(
        "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray+&_sacat=0",
        num_pages=2,
        task_name="Blu-ray Movies"
    )
    
    # Task 2: Different search
    scraper.add_task(
        "4K ultra HD",
        num_pages=1,
        task_name="4K Movies"
    )
    
    # Task 3: Another category
    scraper.add_task(
        "DVD box set",
        num_pages=1,
        task_name="DVD Box Sets"
    )
    
    # You can add as many tasks as needed...
    
    # Process all tasks
    scraper.run_all_tasks()
    
    # Get final status
    scraper.get_status()
    
    # Save all results
    print(f"\n💾 Saving all results...")
    scraper.save_all_results()
    
    print(f"\n✨ All tasks completed!")


if __name__ == "__main__":
    main()