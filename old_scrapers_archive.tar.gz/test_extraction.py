#!/usr/bin/env python3
"""
Test eBay data extraction to verify it's actually working
"""

import asyncio
from playwright.async_api import async_playwright
import json

async def test_extraction():
    print("🔍 Testing eBay data extraction...")
    
    async with async_playwright() as p:
        # Launch visible browser to see what's happening
        browser = await p.chromium.launch(
            headless=False,
            args=['--disable-blink-features=AutomationControlled']
        )
        
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        
        # Anti-detection
        await context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
        """)
        
        page = await context.new_page()
        
        # Go to eBay UK
        print("1️⃣ Loading eBay UK...")
        await page.goto('https://www.ebay.co.uk')
        await page.wait_for_timeout(2000)
        
        # Accept cookies if present
        try:
            await page.click('#gdpr-banner-accept', timeout=2000)
            print("   ✅ Cookies accepted")
        except:
            print("   ℹ️ No cookie banner")
        
        # Search for blu ray
        print("2️⃣ Searching for 'blu ray'...")
        search_url = "https://www.ebay.co.uk/sch/i.html?_nkw=blu+ray&_ipg=200"
        await page.goto(search_url, wait_until='domcontentloaded', timeout=60000)
        await page.wait_for_timeout(3000)
        
        # Check page status
        page_title = await page.title()
        print(f"   📄 Page title: {page_title}")
        
        # Method 1: Check what's visible
        print("\n3️⃣ Checking what selectors exist...")
        selector_check = await page.evaluate('''() => {
            return {
                dataViewport: document.querySelectorAll('li[data-viewport]').length,
                sItem: document.querySelectorAll('.s-item').length,
                productLinks: document.querySelectorAll('a[href*="/itm/"]').length,
                h3Titles: document.querySelectorAll('h3.s-item__title').length,
                priceElements: document.querySelectorAll('.s-item__price').length
            };
        }''')
        
        print(f"   📊 Found elements:")
        for key, count in selector_check.items():
            print(f"      {key}: {count}")
        
        # Method 2: Extract actual products
        print("\n4️⃣ Extracting products...")
        products = await page.evaluate('''() => {
            const items = [];
            const elements = document.querySelectorAll('li[data-viewport]');
            
            console.log(`Found ${elements.length} li[data-viewport] elements`);
            
            // Process ALL items first to see what we get
            for(let i = 0; i < elements.length && i < 10; i++) {
                const item = elements[i];
                
                // Get title
                let title = 'NO TITLE';
                const titleElem = item.querySelector('h3.s-item__title') || 
                                 item.querySelector('.s-item__title') ||
                                 item.querySelector('[role="heading"]');
                if(titleElem) {
                    title = titleElem.innerText || titleElem.textContent || 'EMPTY';
                }
                
                // Get link
                const link = item.querySelector('a[href*="/itm/"]');
                const href = link ? link.href : 'NO LINK';
                
                // Get price
                const priceElem = item.querySelector('.s-item__price');
                const price = priceElem ? priceElem.innerText : 'NO PRICE';
                
                items.push({
                    index: i,
                    title: title.substring(0, 100),
                    hasLink: !!link,
                    price: price,
                    url: href
                });
            }
            
            return items;
        }''')
        
        print(f"   ✅ Extracted {len(products)} items:")
        for p in products:
            print(f"      [{p['index']}] {p['title'][:50]}...")
            print(f"          Price: {p['price']}, Has Link: {p['hasLink']}")
        
        # Method 3: Try alternative selector
        print("\n5️⃣ Trying .s-item selector...")
        alt_products = await page.evaluate('''() => {
            const items = [];
            const elements = document.querySelectorAll('.s-item');
            
            for(let i = 0; i < Math.min(5, elements.length); i++) {
                const item = elements[i];
                const titleElem = item.querySelector('.s-item__title');
                const title = titleElem ? titleElem.innerText : 'NO TITLE';
                items.push({index: i, title: title.substring(0, 100)});
            }
            
            return items;
        }''')
        
        print(f"   ✅ Found {len(alt_products)} items with .s-item:")
        for p in alt_products:
            print(f"      [{p['index']}] {p['title'][:50]}...")
        
        # Check for blocking
        print("\n6️⃣ Checking for blocking...")
        page_content = await page.content()
        
        if 'Pardon our interruption' in page_content:
            print("   ⚠️ BLOCKED: 'Pardon our interruption' detected")
        elif 'Access Denied' in page_content:
            print("   ⚠️ BLOCKED: Access Denied")
        elif len(page_content) < 50000:
            print(f"   ⚠️ Page suspiciously small: {len(page_content)} bytes")
        else:
            print(f"   ✅ Page loaded normally: {len(page_content)} bytes")
        
        # Save screenshot for verification
        await page.screenshot(path='test_extraction.png')
        print("\n📸 Screenshot saved as test_extraction.png")
        
        print("\n" + "="*60)
        print("TEST RESULTS:")
        print("="*60)
        
        if len(products) > 0:
            # Filter out "Shop on eBay" items
            real_products = [p for p in products if 'Shop on eBay' not in p['title'] and p['title'] != 'NO TITLE']
            print(f"✅ Extraction WORKING: Found {len(real_products)} real products")
            print(f"   (Filtered out {len(products) - len(real_products)} placeholder items)")
        else:
            print("❌ Extraction FAILED: No products found")
        
        print("\nPress Enter to close browser...")
        input()
        
        await browser.close()

if __name__ == "__main__":
    print("\n🚀 Starting eBay Extraction Test...")
    print("This will open a browser window - DO NOT CLOSE IT\n")
    asyncio.run(test_extraction())